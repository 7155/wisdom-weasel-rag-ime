import type {
  AgentEvent,
  ConversationTransport,
  SendPayload,
} from "../src/index.js";

/**
 * Replace HostEvent and openHostEventStream with the consuming application's
 * own transport. Keep this file outside the UI package in real integration.
 */
type HostEvent =
  | { kind: "start"; responseId: string }
  | { kind: "token"; responseId: string; text: string }
  | { kind: "tool-start"; responseId: string; callId: string; name: string; input?: string }
  | { kind: "tool-end"; responseId: string; callId: string; output?: string; failed?: boolean }
  | { kind: "steer-consumed"; messageId: string }
  | { kind: "done"; responseId: string }
  | { kind: "failure"; message: string };

declare function openHostEventStream(
  payload: SendPayload,
  signal: AbortSignal,
): AsyncIterable<HostEvent>;

function mapHostEvent(event: HostEvent): AgentEvent[] {
  switch (event.kind) {
    case "start":
      return [{ type: "assistant-start", messageId: event.responseId }];
    case "token":
      return [{
        type: "text-delta",
        messageId: event.responseId,
        blockId: `${event.responseId}:text`,
        delta: event.text,
      }];
    case "tool-start":
      return [{
        type: "tool",
        messageId: event.responseId,
        blockId: event.callId,
        name: event.name,
        input: event.input,
        status: "running",
      }];
    case "tool-end":
      return [{
        type: "tool",
        messageId: event.responseId,
        blockId: event.callId,
        name: "tool",
        output: event.output,
        status: event.failed ? "error" : "success",
      }];
    case "steer-consumed":
      return [{ type: "steer-read", userMessageId: event.messageId }];
    case "done":
      return [
        {
          type: "text-done",
          messageId: event.responseId,
          blockId: `${event.responseId}:text`,
        },
        {
          type: "assistant-end",
          messageId: event.responseId,
          stopReason: "end_turn",
        },
      ];
    case "failure":
      return [{ type: "error", message: event.message }];
  }
}

export const transportAdapter: ConversationTransport = {
  async *send(payload, signal) {
    for await (const hostEvent of openHostEventStream(payload, signal)) {
      yield* mapHostEvent(hostEvent);
    }
  },
};
