import React from "react";
import { createRoot } from "react-dom/client";
import { DemoApp } from "./DemoApp.js";
import "./demo.css";

const root = document.getElementById("root");
if (!root) throw new Error("Missing #root");
createRoot(root).render(<DemoApp />);
