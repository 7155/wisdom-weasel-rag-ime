import React, { useMemo } from "react";
import { ConversationProvider } from "../src/context/ConversationProvider.js";
import { ConversationSurface } from "../src/components/ConversationSurface.js";
import type { TranscriptMessage } from "../src/model/types.js";
import { createMockTransport } from "./mockTransport.js";
import "../src/styles.css";

const initialMessages: TranscriptMessage[] = [
  {
    id: "welcome-user",
    role: "user",
    text: "把这个对话界面优化成适合长时间 Agent 工作的交互。",
    timestamp: Date.now() - 70_000,
  },
  {
    id: "welcome-assistant",
    role: "assistant",
    timestamp: Date.now() - 65_000,
    blocks: [{
      id: "welcome-text",
      kind: "text",
      text: "可以。核心不是复制普通聊天，而是把 transcript、运行状态和用户中途介入拆成独立交互层。\n\n你可以先发送一条消息，然后在我工作时继续 **Queue** 或 **Steer**。",
      streaming: false,
    }],
  },
];

export function DemoApp() {
  const transport = useMemo(() => createMockTransport(), []);
  return (
    <main className="ccui-demo-page">
      <ConversationProvider
        conversationId="agent-session-demo"
        initialMessages={initialMessages}
        transport={transport}
        onForkCreated={(id) => console.info("fork created", id)}
      >
        <ConversationSurface title="Claude Conversation UI · Clean-room" subtitle="Standalone agent-session prototype" />
      </ConversationProvider>
    </main>
  );
}
