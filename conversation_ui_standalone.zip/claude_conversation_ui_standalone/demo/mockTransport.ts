import type { AgentEvent, ConversationTransport, SendPayload } from "../src/transport.js";

const sleep = (ms: number, signal?: AbortSignal) => new Promise<void>((resolve, reject) => {
  const timer = window.setTimeout(resolve, ms);
  signal?.addEventListener("abort", () => {
    clearTimeout(timer);
    reject(new DOMException("Aborted", "AbortError"));
  }, { once: true });
});

const words = (text: string) => text.split(/(?<=\s)|(?=[，。！？：；])/g).filter(Boolean);

export function createMockTransport(): ConversationTransport {
  let activeSteers: Array<{ id: string; text: string }> = [];

  return {
    async *send(payload: SendPayload, signal: AbortSignal): AsyncIterable<AgentEvent> {
      const assistantId = `assistant-${payload.messageId}`;
      yield { type: "assistant-start", messageId: assistantId };
      yield {
        type: "thinking",
        messageId: assistantId,
        blockId: `${assistantId}:thinking`,
        summary: "Planning the next step",
        detail: "This demo simulates a long-running agent turn, tool activity, streaming text, queued follow-ups, and steering receipts.",
        status: "running",
      };
      await sleep(380, signal);
      yield {
        type: "thinking",
        messageId: assistantId,
        blockId: `${assistantId}:thinking`,
        summary: "Plan ready",
        detail: "The transcript keeps old rows stable while only the active tail changes.",
        status: "done",
      };
      yield {
        type: "tool",
        messageId: assistantId,
        blockId: `${assistantId}:tool`,
        name: "session.inspect",
        summary: "Inspecting the current session",
        input: JSON.stringify({ session: payload.conversationId }, null, 2),
        status: "running",
      };
      await sleep(520, signal);
      yield {
        type: "tool",
        messageId: assistantId,
        blockId: `${assistantId}:tool`,
        name: "session.inspect",
        summary: "Session context loaded",
        input: JSON.stringify({ session: payload.conversationId }, null, 2),
        output: "3 relevant files · 1 active implementation task",
        status: "success",
      };

      const blockId = `${assistantId}:text`;
      const response = `I’m working from “${payload.text}”.\n\nThe important interaction rule is: **the composer stays usable while work is running**. A normal follow-up can wait in the queue, while a correction can steer the active session.\n\n- completed transcript blocks stay stable\n- active text streams incrementally\n- tool and thinking blocks update independently\n\n\`\`\`ts\nconst next = busy ? queue(message) : send(message);\n\`\`\`\n\nThis is a mock transport; replace it with your application transport adapter.`;
      for (const token of words(response)) {
        await sleep(26, signal);
        yield { type: "text-delta", messageId: assistantId, blockId, delta: token };
        const steer = activeSteers.shift();
        if (steer) {
          yield { type: "steer-read", userMessageId: steer.id };
        }
      }
      yield { type: "text-done", messageId: assistantId, blockId };
      yield { type: "assistant-end", messageId: assistantId, stopReason: "end_turn" };
    },

    async stop() {
      await Promise.resolve();
    },

    async steer(payload) {
      activeSteers.push({ id: payload.messageId, text: payload.text });
      return true;
    },

    async interruptForSteer() {
      return true;
    },

    async cancelSteer(_conversationId, userMessageId) {
      activeSteers = activeSteers.filter(item => item.id !== userMessageId);
      return true;
    },

    async fork(_conversationId, fromMessageId) {
      return `fork-${fromMessageId}`;
    },

    async rewind() {
      return true;
    },

    async *sideChatSend(_conversationId, text, signal) {
      yield { type: "tool", label: "Reading current session context" } as const;
      await sleep(260, signal);
      for (const token of words(`Side chat sees the current session but does not alter the main thread. You asked: “${text}”.`)) {
        await sleep(22, signal);
        yield { type: "delta", text: token } as const;
      }
      yield { type: "end" } as const;
    },
  };
}
