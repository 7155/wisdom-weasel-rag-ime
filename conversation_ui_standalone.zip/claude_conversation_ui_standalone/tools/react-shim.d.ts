declare namespace JSX {
  interface IntrinsicAttributes { key?: any }
  interface IntrinsicElements { [elemName: string]: any }
}

declare namespace React {
  type ReactNode = any;
  interface KeyboardEvent<T = Element> { key: string; shiftKey: boolean; metaKey: boolean; ctrlKey: boolean; target: EventTarget; currentTarget: T; nativeEvent: { isComposing?: boolean }; preventDefault(): void }
}

declare module "react" {
  export type ReactNode = any;
  export type Dispatch<A> = (value: A) => void;
  export interface RefObject<T> { current: T }
  export interface Context<T> { readonly __contextType?: T; Provider: any; Consumer: any }
  export type KeyboardEvent<T = Element> = React.KeyboardEvent<T>;
  export const Fragment: any;
  export function createContext<T>(value: T): Context<T>;
  export function useContext<T>(context: Context<T>): T;
  export function useState<T>(initial: T | (() => T)): [T, (value: T | ((previous: T) => T)) => void];
  export function useRef<T>(initial: T): { current: T };
  export function useMemo<T>(factory: () => T, deps: readonly unknown[]): T;
  export function useCallback<T extends (...args: any[]) => any>(callback: T, deps: readonly unknown[]): T;
  export function useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  export function useLayoutEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  export function useDeferredValue<T>(value: T): T;
  export function useReducer<R extends (state: any, action: any) => any, I>(reducer: R, initializerArg: I, initializer: (arg: I) => ReturnType<R>): [ReturnType<R>, (action: Parameters<R>[1]) => void];
  export function memo<T>(component: T, compare?: (a: any, b: any) => boolean): T;
  const React: { memo: typeof memo };
  export default React;
}

declare module "react-dom/client" {
  export function createRoot(element: Element | DocumentFragment): { render(node: any): void; unmount(): void };
}

declare module "react/jsx-runtime" {
  export const Fragment: any;
  export function jsx(type: any, props: any, key?: any): any;
  export function jsxs(type: any, props: any, key?: any): any;
}
