import fs from "node:fs";
import path from "node:path";

const required = [
  "src/context/ConversationProvider.tsx",
  "src/components/ConversationSurface.tsx",
  "src/components/VirtualTranscript.tsx",
  "src/components/Composer.tsx",
  "src/components/QueueTray.tsx",
  "src/components/SideChatPanel.tsx",
  "src/rendering/react/ProgressiveMarkdown.tsx",
  "src/hooks/usePinnedTranscript.ts",
  "src/hooks/useVirtualTranscript.ts",
  "demo/DemoApp.tsx",
  "demo/mockTransport.ts",
  "analysis/CLAUDE_APP_INTERACTION_FINDINGS.md",
];
for (const file of required) {
  if (!fs.existsSync(path.resolve(file))) {
    console.error(`missing: ${file}`);
    process.exitCode = 1;
  }
}
if (!process.exitCode) console.log(`structure ok · ${required.length} required artifacts`);
