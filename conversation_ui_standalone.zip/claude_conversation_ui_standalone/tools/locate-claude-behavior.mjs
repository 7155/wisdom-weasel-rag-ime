import fs from "node:fs";
import path from "node:path";

const root = path.resolve(process.argv[2] ?? "./ion-dist/assets/v1");
const markers = [
  "claude_ai_frontend_message_queue_main",
  "queuedWhileBusy",
  "restoreQueueOnStop",
  "data-rocksteady-sizer",
  "side_chat_ready",
  "Interrupts the current step so only this message is read now",
  "Reorder queued message",
];

if (!fs.existsSync(root)) {
  console.error(`Bundle directory not found: ${root}`);
  process.exit(1);
}

const files = fs.readdirSync(root).filter(name => name.endsWith(".js"));
for (const marker of markers) {
  const hits = [];
  for (const name of files) {
    const full = path.join(root, name);
    const text = fs.readFileSync(full, "utf8");
    if (text.includes(marker)) hits.push(name);
  }
  console.log(`${marker}\n  ${hits.length ? hits.join("\n  ") : "(not found)"}`);
}
