import type { SideChatState } from "./types.js";
export type SideChatAction = {
    type: "open";
} | {
    type: "close";
} | {
    type: "starting";
} | {
    type: "ready";
} | {
    type: "send";
    text: string;
    id: string;
    timestamp: number;
} | {
    type: "assistant-delta";
    text: string;
    id: string;
    timestamp: number;
} | {
    type: "turn-end";
} | {
    type: "consume-queued";
} | {
    type: "tool";
    label: string | null;
} | {
    type: "error";
    message: string;
} | {
    type: "clear";
};
export declare function reduceSideChat(state: SideChatState, action: SideChatAction): SideChatState;
