export const EMPTY_DRAFT = {
    text: "",
    attachments: [],
    editingMessageId: null,
};
export function createInitialConversationState(conversationId, messages = []) {
    return {
        conversationId,
        phase: "idle",
        messages,
        queue: [],
        draft: { ...EMPTY_DRAFT },
        activeAssistantId: null,
        sideChat: {
            open: false,
            status: "idle",
            messages: [],
            queued: null,
            error: null,
            toolActivity: null,
        },
        lastError: null,
    };
}
