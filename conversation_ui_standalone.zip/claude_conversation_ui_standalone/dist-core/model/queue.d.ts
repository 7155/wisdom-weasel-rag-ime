import type { AttachmentRef, QueuedDraft } from "./types.js";
export declare const FRONTEND_QUEUE_CAP = 8;
export interface QueueInput {
    id: string;
    text: string;
    attachments?: AttachmentRef[];
    conversationId: string;
    busy: boolean;
    existingDepth: number;
    now?: number;
}
export declare function createQueuedDraft(input: QueueInput): QueuedDraft;
export declare function reorderQueuedDrafts(queue: readonly QueuedDraft[], activeId: string, overId: string): QueuedDraft[];
export declare function mergeQueueBackToDraft(queue: readonly QueuedDraft[], currentText: string): string;
export declare function mergeQueueAttachments(queue: readonly QueuedDraft[], current: readonly AttachmentRef[]): AttachmentRef[];
