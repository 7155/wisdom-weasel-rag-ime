import { type SideChatAction } from "./sideChat.js";
import type { AssistantBlock, ConversationState, DraftState, QueuedDraft, TranscriptMessage, UserMessage } from "./types.js";
export type ConversationAction = {
    type: "conversation/reset";
    state: ConversationState;
} | {
    type: "draft/set-text";
    text: string;
} | {
    type: "draft/set";
    draft: DraftState;
} | {
    type: "draft/edit-message";
    messageId: string;
    text: string;
    attachments?: DraftState["attachments"];
} | {
    type: "draft/clear";
} | {
    type: "draft/cancel-edit";
} | {
    type: "run/phase";
    phase: ConversationState["phase"];
} | {
    type: "run/error";
    message: string;
} | {
    type: "run/clear-error";
} | {
    type: "message/append";
    message: TranscriptMessage;
} | {
    type: "message/replace";
    message: TranscriptMessage;
} | {
    type: "message/remove";
    messageId: string;
} | {
    type: "message/remove-after";
    messageId: string;
    includeSelf?: boolean;
} | {
    type: "message/mark-steer";
    messageId: string;
    receipt: "unread" | "read" | "settling" | "done";
} | {
    type: "message/update-assistant-block";
    messageId: string;
    block: AssistantBlock;
} | {
    type: "message/append-assistant-text";
    messageId: string;
    blockId: string;
    delta: string;
} | {
    type: "message/set-active-assistant";
    messageId: string | null;
} | {
    type: "queue/enqueue";
    item: QueuedDraft;
} | {
    type: "queue/remove";
    id: string;
} | {
    type: "queue/edit";
    id: string;
    text: string;
} | {
    type: "queue/reorder";
    activeId: string;
    overId: string;
} | {
    type: "queue/promote";
    id: string;
} | {
    type: "queue/clear";
} | {
    type: "queue/restore-to-draft";
} | {
    type: "queue/dequeue-head";
} | {
    type: "side-chat";
    action: SideChatAction;
};
export declare function conversationReducer(state: ConversationState, action: ConversationAction): ConversationState;
export declare function findMessage(state: ConversationState, id: string): TranscriptMessage | undefined;
export declare function findUserBefore(state: ConversationState, assistantId: string): UserMessage | undefined;
