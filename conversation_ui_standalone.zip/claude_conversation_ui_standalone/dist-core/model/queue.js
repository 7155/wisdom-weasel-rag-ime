export const FRONTEND_QUEUE_CAP = 8;
export function createQueuedDraft(input) {
    return {
        id: input.id,
        text: input.text,
        attachments: input.attachments ?? [],
        queuedAt: input.now ?? Date.now(),
        forConversationId: input.conversationId,
        queuedWhileBusy: input.busy,
        queuedBehindPending: input.existingDepth > 0,
    };
}
export function reorderQueuedDrafts(queue, activeId, overId) {
    if (activeId === overId)
        return [...queue];
    const from = queue.findIndex(item => item.id === activeId);
    const to = queue.findIndex(item => item.id === overId);
    if (from < 0 || to < 0)
        return [...queue];
    const next = [...queue];
    const [item] = next.splice(from, 1);
    if (!item)
        return [...queue];
    next.splice(to, 0, item);
    return next;
}
export function mergeQueueBackToDraft(queue, currentText) {
    const parts = [currentText.trim(), ...queue.map(item => item.text.trim())].filter(Boolean);
    return parts.join("\n\n");
}
export function mergeQueueAttachments(queue, current) {
    const seen = new Set();
    const merged = [];
    for (const attachment of [...current, ...queue.flatMap(item => item.attachments)]) {
        if (seen.has(attachment.id))
            continue;
        seen.add(attachment.id);
        merged.push(attachment);
    }
    return merged;
}
