import test from "node:test";
import assert from "node:assert/strict";
import {
  FRONTEND_QUEUE_CAP,
  createQueuedDraft,
  mergeQueueAttachments,
  mergeQueueBackToDraft,
  reorderQueuedDrafts,
} from "../dist-core/model/queue.js";

test("frontend queue cap matches reconstructed behavior", () => {
  assert.equal(FRONTEND_QUEUE_CAP, 8);
});

test("queued drafts preserve busy/depth semantics", () => {
  const first = createQueuedDraft({ id: "a", text: "first", conversationId: "c", busy: true, existingDepth: 0, now: 1 });
  const second = createQueuedDraft({ id: "b", text: "second", conversationId: "c", busy: true, existingDepth: 1, now: 2 });
  assert.equal(first.queuedWhileBusy, true);
  assert.equal(first.queuedBehindPending, false);
  assert.equal(second.queuedBehindPending, true);
});

test("queue can reorder and restore into the composer", () => {
  const queue = [
    createQueuedDraft({ id: "a", text: "A", conversationId: "c", busy: true, existingDepth: 0 }),
    createQueuedDraft({ id: "b", text: "B", conversationId: "c", busy: true, existingDepth: 1 }),
    createQueuedDraft({ id: "c", text: "C", conversationId: "c", busy: true, existingDepth: 2 }),
  ];
  assert.deepEqual(reorderQueuedDrafts(queue, "c", "a").map(x => x.id), ["c", "a", "b"]);
  assert.equal(mergeQueueBackToDraft(queue, "draft"), "draft\n\nA\n\nB\n\nC");
});


test("queue restoration preserves queued attachments without duplicates", () => {
  const a = { id: "file-a", name: "a.txt", kind: "file" };
  const b = { id: "file-b", name: "b.txt", kind: "file" };
  const queue = [
    createQueuedDraft({ id: "q", text: "with files", attachments: [a, b], conversationId: "c", busy: true, existingDepth: 0 }),
  ];
  assert.deepEqual(mergeQueueAttachments(queue, [a]).map(x => x.id), ["file-a", "file-b"]);
});
