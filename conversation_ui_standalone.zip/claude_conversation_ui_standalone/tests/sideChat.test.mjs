import test from "node:test";
import assert from "node:assert/strict";
import { reduceSideChat } from "../dist-core/model/sideChat.js";
import { createInitialConversationState } from "../dist-core/model/types.js";

const initial = () => createInitialConversationState("c").sideChat;

test("side chat keeps a follow-up outside the main transcript while thinking", () => {
  let state = reduceSideChat(initial(), { type: "open" });
  state = reduceSideChat(state, { type: "send", text: "first", id: "u1", timestamp: 1 });
  assert.equal(state.status, "thinking");
  state = reduceSideChat(state, { type: "send", text: "second", id: "u2", timestamp: 2 });
  assert.equal(state.queued, "second");
  assert.deepEqual(state.messages.map(m => m.text), ["first"]);
  state = reduceSideChat(state, { type: "turn-end" });
  assert.equal(state.status, "ready");
  assert.equal(state.queued, "second");
  state = reduceSideChat(state, { type: "consume-queued" });
  assert.equal(state.queued, null);
});
