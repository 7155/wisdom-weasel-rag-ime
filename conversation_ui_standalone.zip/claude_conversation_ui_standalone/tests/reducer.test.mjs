import test from "node:test";
import assert from "node:assert/strict";
import { conversationReducer } from "../dist-core/model/reducer.js";
import { createInitialConversationState } from "../dist-core/model/types.js";
import { createQueuedDraft } from "../dist-core/model/queue.js";

test("streaming assistant text appends into one block", () => {
  let state = createInitialConversationState("c");
  state = conversationReducer(state, { type: "message/append", message: { id: "a", role: "assistant", timestamp: 1, blocks: [] } });
  state = conversationReducer(state, { type: "message/append-assistant-text", messageId: "a", blockId: "t", delta: "hello " });
  state = conversationReducer(state, { type: "message/append-assistant-text", messageId: "a", blockId: "t", delta: "world" });
  const message = state.messages[0];
  assert.equal(message.role, "assistant");
  assert.equal(message.blocks[0].kind, "text");
  assert.equal(message.blocks[0].text, "hello world");
});

test("stop restoration clears queue and returns text to draft", () => {
  let state = createInitialConversationState("c");
  state = { ...state, draft: { ...state.draft, text: "unfinished" }, queue: [
    createQueuedDraft({ id: "q1", text: "follow one", conversationId: "c", busy: true, existingDepth: 0 }),
    createQueuedDraft({ id: "q2", text: "follow two", conversationId: "c", busy: true, existingDepth: 1 }),
  ] };
  state = conversationReducer(state, { type: "queue/restore-to-draft" });
  assert.equal(state.queue.length, 0);
  assert.equal(state.draft.text, "unfinished\n\nfollow one\n\nfollow two");
});

test("rewind keeps the selected message and removes later branch", () => {
  let state = createInitialConversationState("c", [
    { id: "u1", role: "user", text: "one", timestamp: 1 },
    { id: "a1", role: "assistant", blocks: [], timestamp: 2 },
    { id: "u2", role: "user", text: "two", timestamp: 3 },
  ]);
  state = conversationReducer(state, { type: "message/remove-after", messageId: "a1" });
  assert.deepEqual(state.messages.map(m => m.id), ["u1", "a1"]);
});

test("conversation reset swaps the complete independent session state", () => {
  let state = createInitialConversationState("old", [
    { id: "u1", role: "user", text: "old", timestamp: 1 },
  ]);
  const next = createInitialConversationState("new", [
    { id: "u2", role: "user", text: "new", timestamp: 2 },
  ]);
  state = conversationReducer(state, { type: "conversation/reset", state: next });
  assert.equal(state.conversationId, "new");
  assert.deepEqual(state.messages.map(message => message.id), ["u2"]);
  assert.equal(state.queue.length, 0);
});
