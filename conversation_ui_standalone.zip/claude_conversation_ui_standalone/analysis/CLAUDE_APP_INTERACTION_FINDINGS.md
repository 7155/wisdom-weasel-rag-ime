# Claude App Conversation Interaction Findings

This document records the behaviors used to design this clean-room implementation. It is **not** Anthropic source code and does not reproduce minified implementation bodies. The reference build was the user-provided Claude Desktop/Web SPA archive:

- archive: `c679f1d1-081c-4c40-b1f8-6046cb0f1753.zip`
- SHA-256: `d3ef57aad1acd7aa399b758fa2acc40cf46531e136da9499589be50a0a3d045a`
- inspected tree: `ion-dist/assets/v1/`
- source maps: not present in the inspected build

## Evidence-backed behavior

### 1. Frontend follow-up queue

Observed primarily in `shared-6-0CzudjBX.js`, with UI in `c11959232-C6pCsmyv.js`.

Verified behaviors:

- Feature flag name includes `claude_ai_frontend_message_queue_main`.
- The frontend queue has a hard cap of **8** (`O.length>=8` in the build).
- Queue snapshots carry fields corresponding to prompt/editor state, attachments/files, queue time, conversation identity, and whether the message was queued while busy / behind another pending message.
- The queue API exposes behavior named like `restoreQueueOnStop` and `returnQueueBehindReturnedHead`.
- The queue UI has single-message and multiple-message presentations.
- Multiple queued messages can be expanded, reordered, sent immediately, edited/returned to composer, removed, or cleared.
- Visible strings include “message(s) queued”, “Send now”, “Clear all”, and “Reorder queued message”.

Clean-room implementation:

- `src/model/queue.ts`
- `src/components/QueueTray.tsx`
- queue drain orchestration in `src/context/ConversationProvider.tsx`

### 2. Queue vs mid-turn steering are distinct

Observed in `shared-6-0CzudjBX.js`.

A decision helper in the build distinguishes frontend queuing from Session/Agent/external transports capable of mid-turn sends. The important product implication is that **“send while busy” is not one universal operation**:

- normal busy chat → frontend queued follow-up;
- capable long-running session/agent transport → mid-turn steering can be accepted by the active run;
- stronger user intervention → interrupt current step so the steering message becomes the next thing consumed.

Clean-room implementation models these separately through `submit("queue")`, `submit("steer")`, and `interruptSteer()` transport capabilities.

### 3. Steering receipt lifecycle

Observed in `c360a9e1c-BhqEnXIC.js`.

Verified:

- an awaiting message is shown as `unread`;
- after pickup it transitions to `read`;
- UI timer transitions `read → settling` after roughly **1400 ms** and then removes the temporary receipt after roughly **400 ms**;
- unread UI exposes an `Interrupt` escape hatch when supported;
- tooltip text states that interrupting ends the current step so only this message is read now;
- a cancel/edit action is exposed for the unread steering message.

Clean-room implementation:

- `src/components/SteerReceipt.tsx`
- lifecycle orchestration in `ConversationProvider.tsx`

### 4. Transcript virtualization and scroll stability

Observed in `c360a9e1c-BhqEnXIC.js` and generalized virtualization code in `cd7076639-DfshlBvA.js`.

Verified DOM/implementation signals:

- `data-autoscroll-container`
- `data-rocksteady-sizer`
- `data-rs-index`
- strict containment and disabled browser overflow anchoring
- measured row sizes stored in a map
- only a window of transcript rows is mounted
- the system distinguishes following/pinned behavior from user-controlled history scrolling

Clean-room implementation:

- `src/hooks/useVirtualTranscript.ts`
- `src/hooks/usePinnedTranscript.ts`
- `src/hooks/useSessionScrollMemory.ts`
- `src/components/VirtualTranscript.tsx`

Our overscan constants are implementation choices, not copied constants from the build.

### 5. Side chat

Observed in `c360a9e1c-BhqEnXIC.js` and product strings/changelog chunks.

Verified event vocabulary includes:

- `side_chat_ready`
- `side_chat_assistant`
- `side_chat_tool_use`
- `side_chat_turn_end`
- `side_chat_error`
- `side_chat_closed`

The build maintains per-session queued side-chat input, and a queued follow-up can be sent after the active side-chat turn ends. The side chat is productized as a way to discuss the session without injecting the discussion into the main thread.

Clean-room implementation:

- `src/model/sideChat.ts`
- `src/components/SideChatPanel.tsx`
- `ConversationProvider.sendSideChat()`

### 6. Stop restores queued user intent

Observed queue APIs include `restoreQueueOnStop`, and call sites distinguish stop/failure/blocked paths from successful post-turn queue draining.

The clean-room implementation treats queued user text as user-owned data: stopping an active run restores queued messages back into the composer rather than silently discarding them.

### 7. Edit / retry / rewind / fork

The inspected build contains separate UI/action paths for editing/retrying messages and branching/rewind-style navigation. The clean-room package exposes these as transport capabilities instead of assuming a specific backend persistence model.

### 8. Streaming renderer

The package integrates the prior clean-room renderer reconstructed from this same uploaded application build:

- stable completed Markdown chunks;
- mutable streaming tail;
- safe text release to avoid exposing unstable Markdown suffixes;
- open fenced-code tail fast path;
- memoized completed chunks.

The included `BasicMarkdownChunk` parser is intentionally small and dependency-free. In the consuming application, swap that rendering function for the project's existing Markdown/remark/rehype stack while retaining the chunking and memoization boundaries.

## Clean-room additions / design choices

The following are not claimed to be exact Claude implementation details:

- component names and TypeScript data model in this package;
- CSS styling and product-neutral visual hierarchy;
- exact virtualizer overscan values;
- transport interface shape;
- mock transport and demo data;
- localStorage format for floating side-chat geometry;
- reducer/action names;
- basic Markdown parser used by the demo.

They are independent implementation choices designed to preserve the verified interaction semantics while making the code easy to graft onto any host application.
