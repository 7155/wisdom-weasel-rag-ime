# Source scope and non-coupling guarantee

## Sole behavioral reference

This clean-room package was produced from observable behavior and identifiers in:

- archive: `c679f1d1-081c-4c40-b1f8-6046cb0f1753.zip`
- SHA-256: `d3ef57aad1acd7aa399b758fa2acc40cf46531e136da9499589be50a0a3d045a`
- inspected path: `ion-dist/assets/v1/`
- source maps: absent

## Explicitly out of scope

The implementation does not inspect, import, patch, or encode assumptions about any host application repository. It contains no host-specific backend adapter and no host-specific domain entities.

The stable boundary is `src/transport.ts`:

```text
host runtime events
        ↓
ConversationTransport
        ↓
generic AgentEvent stream
        ↓
ConversationProvider + UI
```

This lets the host code change independently. Integration happens later in a small adapter owned by the host application.

## Clean-room status

The inspected production JavaScript bundle is not redistributed. Component names, reducers, types, CSS, transport interfaces, demo code, and tests are independent implementations. See `CLAUDE_APP_INTERACTION_FINDINGS.md` for the distinction between evidence-backed behavior and implementation choices.
