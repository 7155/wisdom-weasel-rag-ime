# Feature matrix

| Area | Delivered | Basis |
|---|---:|---|
| Stable streaming Markdown chunks | ✅ | behavior reconstructed from supplied app build |
| Open fenced-code streaming fast path | ✅ | behavior reconstructed from supplied app build |
| Variable-height virtual transcript | ✅ | app build exposes measured virtual rows / sizer semantics |
| Pinned-to-bottom / release on history scroll | ✅ | observed interaction + clean-room implementation |
| Upstream row resize scroll compensation | ✅ | clean-room hardening for the same stability goal |
| Per-conversation anchor restore | ✅ | observed session scroll-memory behavior + clean-room format |
| Composer usable while run is busy | ✅ | observed product behavior |
| Frontend follow-up queue | ✅ | directly evidenced |
| Queue cap = 8 | ✅ | directly evidenced |
| Queue reorder / send now / edit / remove / clear | ✅ | directly evidenced UI actions |
| Stop restores queued text + attachment refs | ✅ | restore-on-stop evidenced; attachment merging is clean-room hardening |
| Mid-turn steer | ✅ | distinct frontend queue vs capable-session behavior evidenced |
| Steer unread/read/settling receipt | ✅ | directly evidenced including 1400 ms + 400 ms transition |
| Interrupt unread steer | ✅ | directly evidenced |
| Cancel and edit unread steer | ✅ | directly evidenced |
| Thinking block | ✅ | clean-room component around streamed agent events |
| Tool call card | ✅ | clean-room component around streamed agent events |
| Edit earlier user message | ✅ | observed product action, clean-room branch semantics |
| Retry assistant turn | ✅ | observed action, clean-room transport boundary |
| Fork | ✅ | observed action, transport capability |
| Rewind | ✅ | observed action, transport capability |
| Side Chat `/btw` | ✅ | directly evidenced product/event semantics |
| Side Chat busy follow-up queue | ✅ | per-session queued side-chat behavior evidenced |
| Floating side-chat drag/resize memory | ✅ | clean-room UI choice |
| Transcript keyboard navigation | ✅ | product behavior evidenced; clean-room keys |
| Runnable mock transport demo | ✅ | independent demo |
| Host backend adapter | intentionally excluded | host implements the generic `ConversationTransport` boundary |
| Full production GFM/math/citation renderer | adapter point provided | demo parser intentionally dependency-free |
| Host repository imports or assumptions | none | standalone by design |
