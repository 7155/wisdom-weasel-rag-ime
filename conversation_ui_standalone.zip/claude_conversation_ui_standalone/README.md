# Claude Conversation UI · Clean-room

一套独立的 React + TypeScript 长任务对话界面。它只依据用户提供的 Claude Desktop / Web SPA 构建中**可观察到的交互行为**重新实现，不读取、不导入、也不假设任何宿主项目源码。

> 这不是 Anthropic 官方源码，也不包含 Claude 的专有 bundle。没有 sourcemap 的情况下，本仓库采用 clean-room 方式复现行为与架构边界。

## 源码边界

唯一参考基线：

- `c679f1d1-081c-4c40-b1f8-6046cb0f1753.zip`
- SHA-256：`d3ef57aad1acd7aa399b758fa2acc40cf46531e136da9499589be50a0a3d045a`
- 检查目录：`ion-dist/assets/v1/`
- sourcemap：未发现

本包刻意不包含：

- 任何宿主应用的状态机、数据库或运行时代码；
- 任何特定后端协议；
- 针对某个仓库目录结构的 import；
- 对任何宿主业务实体或运行时内核语义的硬编码。

以后接入任意应用时，只需要实现 `ConversationTransport`，UI 代码本身无需跟随宿主仓库重构。

## 已完成交互

```text
ConversationSurface
├── VirtualTranscript
│   ├── variable-height virtualization
│   ├── pinned-to-latest / release-on-scroll
│   ├── stable anchor restoration
│   ├── UserTurn
│   └── AssistantTurn
│       ├── Progressive Markdown
│       ├── ThinkingBlock
│       └── ToolCard
├── QueueTray
│   ├── queue cap = 8
│   ├── reorder
│   ├── send now
│   ├── inline edit
│   ├── remove
│   └── clear all
├── Composer
│   ├── stays usable while busy
│   ├── Queue
│   ├── Steer
│   └── Stop
└── SideChatPanel
    ├── /btw entry
    ├── independent transcript
    ├── one queued follow-up while busy
    └── movable / resizable geometry memory
```

还包括：

- `unread → read → settling → done` 的 steer receipt；
- `Interrupt` 与 `Cancel & edit`；
- edit-and-retry、retry、fork、rewind 的通用能力边界；
-停止当前输出时，将未消费队列恢复到 composer；
-流式 Markdown 的 stable chunks + mutable tail；
-未闭合 fenced code 的流式快路径；
-旧消息高度变化时对 `scrollTop` 做补偿，避免阅读位置跳动。

## 目录

```text
src/
├── components/             完整 UI 组件
├── context/                orchestration 与异步事件消费
├── hooks/                  virtual list、scroll、anchor、textarea
├── model/                  纯 reducer、queue、side-chat 状态
├── rendering/              增量 Markdown clean-room renderer
├── transport.ts            唯一宿主接入边界
├── index.ts                包导出
└── styles.css              独立 ccui-* 样式命名空间

examples/
└── transportAdapter.template.ts

demo/
├── DemoApp.tsx
├── mockTransport.ts
├── main.tsx
└── index.html

analysis/
├── CLAUDE_APP_INTERACTION_FINDINGS.md
├── FEATURE_MATRIX.md
└── SOURCE_SCOPE.md
```

## 运行 Demo

需要 Node.js 与 npm：

```bash
npm install
npm run dev
```

构建 Demo：

```bash
npm run build:demo
```

核心模型测试与静态验证：

```bash
npm test
npm run verify
```

## 最小使用方式

```tsx
import {
  ConversationProvider,
  ConversationSurface,
  type ConversationTransport,
} from "claude-conversation-ui-cleanroom";
import "claude-conversation-ui-cleanroom/styles.css";

const transport: ConversationTransport = {
  async *send(payload, signal) {
    const assistantId = `assistant:${payload.messageId}`;

    yield {
      type: "assistant-start",
      messageId: assistantId,
    };

    yield {
      type: "text-delta",
      messageId: assistantId,
      blockId: `${assistantId}:text`,
      delta: "Hello from the host transport.",
    };

    yield {
      type: "text-done",
      messageId: assistantId,
      blockId: `${assistantId}:text`,
    };

    yield {
      type: "assistant-end",
      messageId: assistantId,
      stopReason: "end_turn",
    };
  },
};

export function ConversationPage() {
  return (
    <ConversationProvider
      conversationId="conversation:demo"
      transport={transport}
    >
      <ConversationSurface
        title="Agent session"
        subtitle="Standalone conversation surface"
      />
    </ConversationProvider>
  );
}
```

## Transport 协议

宿主只需把自己的事件映射到以下通用事件：

```ts
type AgentEvent =
  | { type: "assistant-start"; messageId: string; timestamp?: number }
  | {
      type: "thinking";
      messageId: string;
      blockId: string;
      summary: string;
      detail?: string;
      status: "running" | "done";
    }
  | {
      type: "text-delta";
      messageId: string;
      blockId: string;
      delta: string;
    }
  | { type: "text-done"; messageId: string; blockId: string }
  | {
      type: "tool";
      messageId: string;
      blockId: string;
      name: string;
      summary?: string;
      input?: string;
      output?: string;
      status:
        | "pending"
        | "running"
        | "success"
        | "error"
        | "cancelled";
    }
  | { type: "steer-read"; userMessageId: string }
  | { type: "assistant-end"; messageId: string; stopReason?: string }
  | { type: "error"; message: string };
```

完整接口位于 [`src/transport.ts`](src/transport.ts)。可选能力分别是：

- `stop`
- `steer`
- `interruptForSteer`
- `cancelSteer`
- `fork`
- `rewind`
- `sideChatSend`

组件会根据 transport 是否实现某项方法自动决定是否展示对应交互，不要求宿主一次接完所有能力。

## Streaming renderer

`ProgressiveMarkdown` 不是每次 delta 都 parse 整条回答。流式阶段维护：

```text
completed chunks  → memoized / stable
active tail       → mutable
open code fence   → dedicated fast path
settled document  → final reconciliation
```

Demo 内置的是小型、无依赖 Markdown renderer。正式产品可以替换 chunk 的最终渲染函数，但应保留增量 scanner、稳定 chunk key 和 memo 边界。

## CSS 隔离

所有公开 class 与变量都使用 `ccui-` / `--ccui-` 前缀，不依赖宿主全局主题。可在容器上覆盖变量：

```css
.my-conversation-theme {
  --ccui-bg: #f7f7f5;
  --ccui-surface: #ffffff;
  --ccui-text: #171717;
  --ccui-accent: #315f4c;
}
```

## 验证边界

当前验证覆盖：

- queue cap、busy/depth 元数据、重排与恢复；
- attachment 去重恢复；
- streaming text block 合并；
- rewind 分支裁剪；
- side chat busy follow-up；
- conversationId 切换时完整重置独立会话状态；
- TypeScript core build；
- 全部 TS/TSX 静态类型检查；
- 必要目录与公开入口检查。

真实后端接入、账号鉴权、持久化、服务端重连和业务实体映射被有意留在包外。这不是缺失 UI，而是为了避免把正在变化的宿主实现固化进组件库。

## 证据与实现区分

详见：

- [`analysis/CLAUDE_APP_INTERACTION_FINDINGS.md`](analysis/CLAUDE_APP_INTERACTION_FINDINGS.md)
- [`analysis/FEATURE_MATRIX.md`](analysis/FEATURE_MATRIX.md)
- [`analysis/SOURCE_SCOPE.md`](analysis/SOURCE_SCOPE.md)
