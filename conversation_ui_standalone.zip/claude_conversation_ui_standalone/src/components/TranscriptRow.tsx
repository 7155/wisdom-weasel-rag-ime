import React from "react";
import type { TranscriptMessage } from "../model/types.js";
import { UserTurn } from "./UserTurn.js";
import { AssistantTurn } from "./AssistantTurn.js";

export function TranscriptRow({ message }: { message: TranscriptMessage }) {
  return message.role === "user" ? <UserTurn message={message} /> : <AssistantTurn message={message} />;
}
