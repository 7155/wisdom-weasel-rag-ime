# 荒野方境（Wildcube Survival）

原创的浏览器 3D 方块生存游戏。代码、配色、程序化纹理与音效均为本项目原创实现，不包含 Minecraft/Mojang 素材。

## 运行

```bash
npm install
npm run dev
```

然后打开终端显示的本地地址。生产构建：`npm run build`；逻辑测试：`npm test`。

## 操作

- 点击开始并锁定鼠标；WASD 移动，空格跳跃，Shift 奔跑。
- 鼠标左键破坏、右键放置；滚轮或数字键 1–9 切换快捷栏。
- H 或 E 查看帮助，F 食用收集到的阳叶，P 存档，L 读档，Esc 暂停。

## 当前验收

- `npm test`：10/10 通过。
- `npm run build`：通过。
- 真实 Chromium smoke 已验证 WebGL2、Pointer Lock、移动、采集/放置和 P/L 存读档。

完整功能与已知缺口见 `docs/agent/FINAL.md`。
