import { cp, mkdir, rm, stat } from 'node:fs/promises';

await rm('dist', { recursive: true, force: true });
await mkdir('dist', { recursive: true });
for (const path of ['index.html', 'src']) {
  await stat(path);
  await cp(path, `dist/${path}`, { recursive: true });
}
console.log('构建完成：dist/（零外部运行依赖）');
