import test from 'node:test';
import assert from 'node:assert/strict';

import {
  BLOCKS,
  Inventory,
  SurvivalState,
  World,
  deserializeGame,
  generateWorld,
  serializeGame,
} from '../src/core/index.js';

test('block catalog exposes original, immutable definitions', () => {
  assert.equal(BLOCKS.ember_ore.collectible, true);
  assert.equal(BLOCKS.air.solid, false);
  assert.equal(Object.isFrozen(BLOCKS), true);
});

test('world generation is deterministic and includes terrain, ore, and trees', () => {
  const options = { seed: 'quiet-comet', width: 18, height: 20, depth: 18 };
  const first = generateWorld(options);
  const repeat = generateWorld(options);
  const other = generateWorld({ ...options, seed: 'bright-comet' });

  assert.deepEqual(first.toJSON(), repeat.toJSON());
  assert.notDeepEqual(first.toJSON().runs, other.toJSON().runs);
  assert.ok(first.count('meadow') > 0);
  assert.ok(first.count('ember_ore') > 0);
  assert.ok(first.count('sunwood') > 0);
});

test('finite World supports bounded get, set, and remove edits', () => {
  const world = new World({ width: 4, height: 4, depth: 4 });
  assert.equal(world.get(1, 2, 3), 'air');
  assert.equal(world.set(1, 2, 3, 'timber_tile'), true);
  assert.equal(world.get(1, 2, 3), 'timber_tile');
  assert.equal(world.remove(1, 2, 3), 'timber_tile');
  assert.equal(world.get(1, 2, 3), 'air');
  assert.equal(world.get(-1, 0, 0), null);
  assert.equal(world.set(9, 0, 0, 'loam'), false);
  assert.equal(world.remove(9, 0, 0), null);
  assert.throws(() => world.set(0, 0, 0, 'missing_block'), /Unknown block/);
});

test('nine-slot inventory stacks, selects, removes, and reports full capacity', () => {
  const inventory = new Inventory({ stackLimit: 3 });
  assert.equal(inventory.getSlots().length, 9);
  assert.equal(inventory.add('loam', 5), 5);
  assert.equal(inventory.count('loam'), 5);
  assert.deepEqual(inventory.getSlot(0), { blockId: 'loam', count: 3 });
  assert.deepEqual(inventory.getSlot(1), { blockId: 'loam', count: 2 });
  assert.equal(inventory.remove('loam', 4), 4);
  assert.equal(inventory.count('loam'), 1);
  inventory.select(8);
  assert.equal(inventory.selectedIndex, 8);

  for (const id of ['meadow', 'bedrock', 'sunwood', 'sunleaf', 'ember_ore', 'timber_tile', 'loam']) {
    inventory.add(id, 3);
  }
  assert.equal(inventory.add('meadow', 30), 3);
  assert.throws(() => inventory.add('air'), /not an inventory item/);
});

test('survival advancement drains hunger, wraps day time, heals, and starves', () => {
  const state = new SurvivalState({
    health: 10,
    hunger: 20,
    timeOfDay: 0.9,
    dayLengthSeconds: 10,
    hungerDrainPerSecond: 0.1,
  });
  state.tick(2);
  assert.equal(state.elapsedDays, 1);
  assert.ok(Math.abs(state.timeOfDay - 0.1) < 1e-12);
  assert.ok(state.hunger < 20);
  assert.ok(state.health > 10);

  const starving = new SurvivalState({ health: 5, hunger: 0, hungerDrainPerSecond: 0 });
  starving.tick(4);
  assert.equal(starving.health, 3);
  starving.damage(10);
  assert.equal(starving.isAlive, false);
  starving.consume(100);
  assert.equal(starving.hunger, 20);
});

test('JSON save round-trip restores core class instances and edited state', () => {
  const world = generateWorld({ seed: 42, width: 12, height: 16, depth: 12 });
  world.set(2, 10, 2, 'timber_tile');
  const inventory = new Inventory();
  inventory.add('sunwood', 7);
  inventory.select(3);
  const survival = new SurvivalState({ health: 13, hunger: 9, timeOfDay: 0.75 });
  survival.tick(3, { effort: 0.5 });

  const serialized = serializeGame({ world, inventory, survival, metadata: { label: 'slot-a' } });
  assert.doesNotThrow(() => JSON.parse(serialized));
  const restored = deserializeGame(serialized);

  assert.ok(restored.world instanceof World);
  assert.ok(restored.inventory instanceof Inventory);
  assert.ok(restored.survival instanceof SurvivalState);
  assert.deepEqual(restored.world.toJSON(), world.toJSON());
  assert.deepEqual(restored.inventory.toJSON(), inventory.toJSON());
  assert.deepEqual(restored.survival.toJSON(), survival.toJSON());
  assert.deepEqual(restored.metadata, { label: 'slot-a' });
});

test('world data rejects truncated runs instead of silently corrupting a save', () => {
  const data = new World({ width: 2, height: 2, depth: 2 }).toJSON();
  data.runs[0][1] -= 1;
  assert.throws(() => World.fromJSON(data), /do not fill/);
});
