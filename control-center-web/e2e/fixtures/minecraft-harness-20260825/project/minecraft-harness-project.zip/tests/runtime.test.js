import assert from 'node:assert/strict';
import test from 'node:test';

import { OVERLAY_MODES } from '../src/ui/index.js';
import { WildcubeGame } from '../src/game/runtime.js';

test('pointer-lock rejection keeps gameplay paused and leaves a usable overlay', async () => {
  let status = '';
  const game = {
    audio: { unlock: async () => {} },
    renderer: { canvas: { requestPointerLock: () => Promise.reject(new Error('denied')) } },
    paused: false,
    overlay: OVERLAY_MODES.START,
    setStatus(message) { status = message; },
  };

  WildcubeGame.prototype.enterGame.call(game);
  assert.equal(game.paused, true);
  assert.equal(game.overlay, OVERLAY_MODES.START);
  await Promise.resolve();
  assert.equal(game.paused, true);
  assert.match(status, /锁定失败/);
});

test('landing resets the fall origin so later small drops do not repeat old damage', () => {
  let damage = 0;
  const game = {
    keys: new Set(),
    player: { x: 2, y: 4, z: 2, yaw: 0, vy: -1, grounded: false, fallStart: 10 },
    survival: {
      health: 20,
      timeOfDay: 0.5,
      isAlive: true,
      tick() {},
      damage(amount) { damage += amount; },
    },
    audio: { play: async () => {} },
    nightDamageClock: 0,
    overlay: OVERLAY_MODES.NONE,
    paused: false,
    moveAxis(axis) { return axis !== 'y'; },
    hasRoof() { return true; },
    setStatus() {},
  };

  WildcubeGame.prototype.step.call(game, 0.016);
  assert.ok(damage > 0);
  assert.equal(game.player.fallStart, game.player.y);
  const damageAfterLargeFall = damage;

  game.player.y = 3.8;
  game.player.vy = -1;
  game.player.grounded = false;
  WildcubeGame.prototype.step.call(game, 0.016);
  assert.equal(damage, damageAfterLargeFall);
});
