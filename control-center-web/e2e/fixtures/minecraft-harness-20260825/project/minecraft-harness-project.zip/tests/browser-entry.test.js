import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

test('zero-dependency browser entry loads CSS with a link, not a JavaScript CSS import', async () => {
  const [html, main] = await Promise.all([
    readFile(new URL('../index.html', import.meta.url), 'utf8'),
    readFile(new URL('../src/main.js', import.meta.url), 'utf8'),
  ]);

  assert.match(html, /<link\s+rel="stylesheet"\s+href="\/src\/style\.css"\s*\/>/);
  assert.doesNotMatch(main, /import\s+['"]\.\/style\.css['"]/);
});
