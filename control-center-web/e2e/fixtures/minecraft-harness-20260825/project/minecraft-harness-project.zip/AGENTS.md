# AGENTS.md

## 项目入口
这是一个原创的浏览器 3D 方块生存游戏。当前交付目标是可试玩的单人核心生存循环；不复制 Minecraft/Mojang 的代码、商标或素材，也不把完整商业游戏内容作为已完成范围。

## 权威区域
- `src/core/`：纯逻辑世界、库存、生存与存档。
- `src/game/`：3D 运行时、输入、物理与交互。
- `src/ui/`：HUD、菜单和程序化音频。
- `tests/`：关键纯逻辑测试。
- `docs/agent/requirements.md`：已接受需求历史。
- `docs/agent/ROOT.md`：当前根工作文档入口；动态关系须从 WorkDocument registry 查询。

## 已验证命令
- `npm install`：安装（当前零外部依赖）。
- `npm run dev`：启动本机试玩服务器。
- `npm test`：运行 Node 核心逻辑测试。
- `npm run build`：生成零依赖 `dist/`。

## 边界与文档规则
仅修改当前授权工作区；不提交、不推送、不引入受版权保护的素材。浏览器本地存档属于用户本机数据。

`AGENTS.md` = 稳定项目入口和路由规则  
持久需求文档 = 已接受需求历史  
WorkDocument registry = 活跃文档/WorkItem/Session 关系  
Runtime 与 Git = 当前执行和工作区事实
