import { Inventory } from './inventory.js';
import { SurvivalState } from './survival.js';
import { World } from './world.js';

export const SAVE_FORMAT = 'skyfield-survival';
export const SAVE_VERSION = 1;

/** Returns a localStorage-ready JSON string without touching browser APIs. */
export function serializeGame({ world, inventory, survival, metadata = {} }) {
  if (!(world instanceof World)) throw new TypeError('world must be a World');
  if (!(inventory instanceof Inventory)) throw new TypeError('inventory must be an Inventory');
  if (!(survival instanceof SurvivalState)) throw new TypeError('survival must be a SurvivalState');
  return JSON.stringify({
    format: SAVE_FORMAT,
    version: SAVE_VERSION,
    world: world.toJSON(),
    inventory: inventory.toJSON(),
    survival: survival.toJSON(),
    metadata,
  });
}

/** Restores class instances from a string previously produced by serializeGame. */
export function deserializeGame(serialized) {
  if (typeof serialized !== 'string') throw new TypeError('serialized save must be a string');
  let data;
  try {
    data = JSON.parse(serialized);
  } catch (error) {
    throw new TypeError(`Save is not valid JSON: ${error.message}`);
  }
  if (data?.format !== SAVE_FORMAT || data?.version !== SAVE_VERSION) {
    throw new RangeError('Unsupported save format or version');
  }
  return {
    world: World.fromJSON(data.world),
    inventory: Inventory.fromJSON(data.inventory),
    survival: SurvivalState.fromJSON(data.survival),
    metadata: data.metadata && typeof data.metadata === 'object' ? data.metadata : {},
  };
}
