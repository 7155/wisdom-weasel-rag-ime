import { getBlockDefinition, isBlockId } from './blocks.js';

export const INVENTORY_SLOT_COUNT = 9;
export const DEFAULT_STACK_LIMIT = 99;

function positiveInteger(value, name) {
  if (!Number.isInteger(value) || value <= 0) throw new RangeError(`${name} must be a positive integer`);
}

function validateItem(blockId) {
  const block = getBlockDefinition(blockId);
  if (!block || !block.collectible || blockId === 'air') {
    throw new TypeError(`Block is not an inventory item: ${String(blockId)}`);
  }
}

/** A fixed nine-slot resource inventory with predictable stack behavior. */
export class Inventory {
  #slots;
  #selectedIndex;
  #stackLimit;

  constructor({ slots, selectedIndex = 0, stackLimit = DEFAULT_STACK_LIMIT } = {}) {
    positiveInteger(stackLimit, 'stackLimit');
    this.#stackLimit = stackLimit;
    this.#slots = Array.from({ length: INVENTORY_SLOT_COUNT }, () => null);
    this.select(selectedIndex);

    if (slots !== undefined) {
      if (!Array.isArray(slots) || slots.length > INVENTORY_SLOT_COUNT) {
        throw new TypeError(`slots must be an array of at most ${INVENTORY_SLOT_COUNT} entries`);
      }
      slots.forEach((slot, index) => {
        if (slot == null) return;
        validateItem(slot.blockId);
        positiveInteger(slot.count, 'slot.count');
        if (slot.count > this.#stackLimit) throw new RangeError('slot.count exceeds stackLimit');
        this.#slots[index] = { blockId: slot.blockId, count: slot.count };
      });
    }
  }

  get selectedIndex() {
    return this.#selectedIndex;
  }

  get stackLimit() {
    return this.#stackLimit;
  }

  getSlot(index) {
    if (!Number.isInteger(index) || index < 0 || index >= INVENTORY_SLOT_COUNT) return null;
    const slot = this.#slots[index];
    return slot ? { ...slot } : null;
  }

  getSlots() {
    return this.#slots.map((slot) => (slot ? { ...slot } : null));
  }

  select(index) {
    if (!Number.isInteger(index) || index < 0 || index >= INVENTORY_SLOT_COUNT) {
      throw new RangeError(`selected index must be between 0 and ${INVENTORY_SLOT_COUNT - 1}`);
    }
    this.#selectedIndex = index;
    return this.getSlot(index);
  }

  /** Adds as many items as possible and returns the accepted quantity. */
  add(blockId, count = 1) {
    validateItem(blockId);
    positiveInteger(count, 'count');
    let remaining = count;

    for (const slot of this.#slots) {
      if (slot?.blockId !== blockId || slot.count >= this.#stackLimit) continue;
      const moved = Math.min(remaining, this.#stackLimit - slot.count);
      slot.count += moved;
      remaining -= moved;
      if (remaining === 0) return count;
    }

    for (let index = 0; index < this.#slots.length && remaining > 0; index += 1) {
      if (this.#slots[index] !== null) continue;
      const moved = Math.min(remaining, this.#stackLimit);
      this.#slots[index] = { blockId, count: moved };
      remaining -= moved;
    }
    return count - remaining;
  }

  /** Removes items across slots and returns the removed quantity. */
  remove(blockId, count = 1) {
    if (!isBlockId(blockId) || blockId === 'air') return 0;
    positiveInteger(count, 'count');
    let remaining = count;

    for (let index = this.#slots.length - 1; index >= 0 && remaining > 0; index -= 1) {
      const slot = this.#slots[index];
      if (slot?.blockId !== blockId) continue;
      const moved = Math.min(remaining, slot.count);
      slot.count -= moved;
      remaining -= moved;
      if (slot.count === 0) this.#slots[index] = null;
    }
    return count - remaining;
  }

  count(blockId) {
    return this.#slots.reduce((sum, slot) => sum + (slot?.blockId === blockId ? slot.count : 0), 0);
  }

  toJSON() {
    return {
      slots: this.getSlots(),
      selectedIndex: this.#selectedIndex,
      stackLimit: this.#stackLimit,
    };
  }

  static fromJSON(data) {
    if (!data || typeof data !== 'object') throw new TypeError('Invalid inventory data');
    return new Inventory(data);
  }
}
