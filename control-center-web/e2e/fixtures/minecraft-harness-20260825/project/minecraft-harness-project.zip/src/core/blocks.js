// Original, data-only block catalog shared by generation, inventory, and rendering.
const definitions = {
  air: { id: 'air', label: 'Air', solid: false, collectible: false, color: 0x9bd8ff },
  meadow: { id: 'meadow', label: 'Meadow Block', solid: true, collectible: true, color: 0x69a84f },
  loam: { id: 'loam', label: 'Loam', solid: true, collectible: true, color: 0x8b6043 },
  bedrock: { id: 'bedrock', label: 'Deepstone', solid: true, collectible: true, color: 0x596168 },
  sunwood: { id: 'sunwood', label: 'Sunwood', solid: true, collectible: true, color: 0x9b6b39 },
  sunleaf: { id: 'sunleaf', label: 'Sunleaf', solid: true, collectible: true, color: 0x4f8f48 },
  ember_ore: { id: 'ember_ore', label: 'Ember Ore', solid: true, collectible: true, color: 0xb66b45 },
  timber_tile: { id: 'timber_tile', label: 'Timber Tile', solid: true, collectible: true, color: 0xc18b50 },
};

export const BLOCKS = Object.freeze(
  Object.fromEntries(Object.entries(definitions).map(([id, block]) => [id, Object.freeze(block)])),
);

export const BLOCK_IDS = Object.freeze(Object.keys(BLOCKS));
const codeById = new Map(BLOCK_IDS.map((id, index) => [id, index]));

export function isBlockId(id) {
  return typeof id === 'string' && codeById.has(id);
}

export function getBlockDefinition(id) {
  return BLOCKS[id] ?? null;
}

export function getBlockCode(id) {
  const code = codeById.get(id);
  if (code === undefined) throw new TypeError(`Unknown block id: ${String(id)}`);
  return code;
}

export function getBlockId(code) {
  return Number.isInteger(code) ? (BLOCK_IDS[code] ?? null) : null;
}
