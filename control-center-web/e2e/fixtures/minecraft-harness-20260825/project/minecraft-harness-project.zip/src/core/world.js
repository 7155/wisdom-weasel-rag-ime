import { BLOCK_IDS, getBlockCode, getBlockId, isBlockId } from './blocks.js';

const MAX_CELLS = 16_777_216;

function dimension(value, name) {
  if (!Number.isInteger(value) || value <= 0) throw new RangeError(`${name} must be a positive integer`);
  return value;
}

function fnv1a(text) {
  let hash = 0x811c9dc5;
  for (const character of String(text)) {
    hash ^= character.codePointAt(0);
    hash = Math.imul(hash, 0x01000193);
  }
  return hash >>> 0;
}

export function normalizeSeed(seed = 'new-horizon') {
  return typeof seed === 'number' && Number.isFinite(seed) ? (Math.trunc(seed) >>> 0) : fnv1a(seed);
}

function randomAt(seed, x, y, z, channel = 0) {
  let value = seed ^ Math.imul(x, 0x9e3779b1) ^ Math.imul(y, 0x85ebca77);
  value ^= Math.imul(z, 0xc2b2ae3d) ^ Math.imul(channel, 0x27d4eb2f);
  value ^= value >>> 16;
  value = Math.imul(value, 0x7feb352d);
  value ^= value >>> 15;
  value = Math.imul(value, 0x846ca68b);
  value ^= value >>> 16;
  return (value >>> 0) / 0x1_0000_0000;
}

const smooth = (value) => value * value * (3 - 2 * value);
const mix = (a, b, amount) => a + (b - a) * amount;

function valueNoise2(seed, x, z, scale) {
  const gx = Math.floor(x / scale);
  const gz = Math.floor(z / scale);
  const tx = smooth((x / scale) - gx);
  const tz = smooth((z / scale) - gz);
  const top = mix(randomAt(seed, gx, 0, gz, 1), randomAt(seed, gx + 1, 0, gz, 1), tx);
  const bottom = mix(randomAt(seed, gx, 0, gz + 1, 1), randomAt(seed, gx + 1, 0, gz + 1, 1), tx);
  return mix(top, bottom, tz);
}

/** Finite dense voxel storage. Coordinates are integer x/y/z with y pointing up. */
export class World {
  #cells;

  constructor({ width = 32, height = 24, depth = 32, fill = 'air', seed = 0 } = {}) {
    this.width = dimension(width, 'width');
    this.height = dimension(height, 'height');
    this.depth = dimension(depth, 'depth');
    const cellCount = this.width * this.height * this.depth;
    if (!Number.isSafeInteger(cellCount) || cellCount > MAX_CELLS) {
      throw new RangeError(`world may contain at most ${MAX_CELLS} cells`);
    }
    if (!isBlockId(fill)) throw new TypeError(`Unknown fill block: ${String(fill)}`);
    this.seed = normalizeSeed(seed);
    this.#cells = new Uint16Array(cellCount);
    this.#cells.fill(getBlockCode(fill));
  }

  contains(x, y, z) {
    return Number.isInteger(x) && Number.isInteger(y) && Number.isInteger(z)
      && x >= 0 && x < this.width && y >= 0 && y < this.height && z >= 0 && z < this.depth;
  }

  #index(x, y, z) {
    return x + this.width * (z + this.depth * y);
  }

  /** Returns a block id, or null when the coordinate is outside this finite world. */
  get(x, y, z) {
    return this.contains(x, y, z) ? getBlockId(this.#cells[this.#index(x, y, z)]) : null;
  }

  /** Returns false outside the world; invalid block ids throw. */
  set(x, y, z, blockId) {
    if (!isBlockId(blockId)) throw new TypeError(`Unknown block id: ${String(blockId)}`);
    if (!this.contains(x, y, z)) return false;
    this.#cells[this.#index(x, y, z)] = getBlockCode(blockId);
    return true;
  }

  /** Replaces a voxel with air and returns its previous id, or null out of bounds. */
  remove(x, y, z) {
    const previous = this.get(x, y, z);
    if (previous === null) return null;
    this.set(x, y, z, 'air');
    return previous;
  }

  count(blockId) {
    if (!isBlockId(blockId)) return 0;
    const code = getBlockCode(blockId);
    let total = 0;
    for (const cell of this.#cells) if (cell === code) total += 1;
    return total;
  }

  forEach(callback, { includeAir = false } = {}) {
    if (typeof callback !== 'function') throw new TypeError('callback must be a function');
    for (let y = 0; y < this.height; y += 1) {
      for (let z = 0; z < this.depth; z += 1) {
        for (let x = 0; x < this.width; x += 1) {
          const blockId = this.get(x, y, z);
          if (includeAir || blockId !== 'air') callback(blockId, x, y, z);
        }
      }
    }
  }

  toJSON() {
    const runs = [];
    let previous = this.#cells[0];
    let length = 0;
    for (const code of this.#cells) {
      if (code === previous) {
        length += 1;
      } else {
        runs.push([previous, length]);
        previous = code;
        length = 1;
      }
    }
    if (length > 0) runs.push([previous, length]);
    return {
      width: this.width,
      height: this.height,
      depth: this.depth,
      seed: this.seed,
      palette: [...BLOCK_IDS],
      runs,
    };
  }

  static fromJSON(data) {
    if (!data || typeof data !== 'object' || !Array.isArray(data.palette) || !Array.isArray(data.runs)) {
      throw new TypeError('Invalid world data');
    }
    if (!data.palette.every(isBlockId)) throw new TypeError('World palette contains an unknown block');
    const world = new World(data);
    let cursor = 0;
    for (const run of data.runs) {
      if (!Array.isArray(run) || run.length !== 2) throw new TypeError('Invalid world run');
      const [paletteCode, length] = run;
      if (!Number.isInteger(paletteCode) || !Number.isInteger(length) || length <= 0) {
        throw new TypeError('Invalid world run values');
      }
      const blockId = data.palette[paletteCode];
      if (!isBlockId(blockId) || cursor + length > world.#cells.length) {
        throw new RangeError('World run exceeds its palette or dimensions');
      }
      world.#cells.fill(getBlockCode(blockId), cursor, cursor + length);
      cursor += length;
    }
    if (cursor !== world.#cells.length) throw new RangeError('World runs do not fill its dimensions');
    return world;
  }
}

function plantTree(world, x, surfaceY, z) {
  if (surfaceY + 5 >= world.height || world.get(x, surfaceY, z) !== 'meadow') return false;
  for (let y = surfaceY + 1; y <= surfaceY + 3; y += 1) world.set(x, y, z, 'sunwood');
  for (let y = surfaceY + 3; y <= surfaceY + 4; y += 1) {
    const radius = y === surfaceY + 4 ? 1 : 2;
    for (let dz = -radius; dz <= radius; dz += 1) {
      for (let dx = -radius; dx <= radius; dx += 1) {
        if (Math.abs(dx) === radius && Math.abs(dz) === radius) continue;
        if (world.get(x + dx, y, z + dz) === 'air') world.set(x + dx, y, z + dz, 'sunleaf');
      }
    }
  }
  world.set(x, surfaceY + 5, z, 'sunleaf');
  return true;
}

/** Builds a deterministic, finite landscape containing soil layers, ore, and trees. */
export function generateWorld({ seed = 'new-horizon', width = 32, height = 24, depth = 32 } = {}) {
  const normalizedSeed = normalizeSeed(seed);
  const world = new World({ width, height, depth, seed: normalizedSeed });
  const surfaces = new Int16Array(width * depth);
  const base = Math.max(1, Math.floor(height * 0.38));
  const amplitude = Math.max(1, Math.floor(height * 0.18));

  for (let z = 0; z < depth; z += 1) {
    for (let x = 0; x < width; x += 1) {
      const noise = valueNoise2(normalizedSeed, x, z, 7);
      const maxSurface = Math.max(0, height - 2);
      const surface = Math.min(maxSurface, Math.max(0, Math.floor(base + (noise - 0.5) * 2 * amplitude)));
      surfaces[x + width * z] = surface;
      for (let y = 0; y <= surface; y += 1) {
        let blockId = 'bedrock';
        if (y === surface) blockId = 'meadow';
        else if (y >= surface - 2) blockId = 'loam';
        else if (randomAt(normalizedSeed, x, y, z, 3) < 0.045) blockId = 'ember_ore';
        world.set(x, y, z, blockId);
      }
    }
  }

  // Guarantee ore in worlds with a stone layer, while retaining seed-dependent placement.
  if (world.count('ember_ore') === 0) {
    let best = null;
    for (let z = 0; z < depth; z += 1) {
      for (let x = 0; x < width; x += 1) {
        const surface = surfaces[x + width * z];
        for (let y = 0; y < surface - 2; y += 1) {
          const score = randomAt(normalizedSeed, x, y, z, 4);
          if (world.get(x, y, z) === 'bedrock' && (!best || score < best.score)) best = { x, y, z, score };
        }
      }
    }
    if (best) world.set(best.x, best.y, best.z, 'ember_ore');
  }

  const treeCandidates = [];
  for (let z = 2; z < depth - 2; z += 1) {
    for (let x = 2; x < width - 2; x += 1) {
      const surface = surfaces[x + width * z];
      if (surface + 5 >= height) continue;
      const score = randomAt(normalizedSeed, x, surface, z, 5);
      treeCandidates.push({ x, z, surface, score });
      if (score < 0.025) plantTree(world, x, surface, z);
    }
  }
  if (world.count('sunwood') === 0 && treeCandidates.length > 0) {
    treeCandidates.sort((a, b) => a.score - b.score);
    const choice = treeCandidates[0];
    plantTree(world, choice.x, choice.surface, choice.z);
  }

  return world;
}
