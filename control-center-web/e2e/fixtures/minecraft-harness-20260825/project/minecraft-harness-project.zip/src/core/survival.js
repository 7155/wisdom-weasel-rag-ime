const clamp = (value, min, max) => Math.min(max, Math.max(min, value));

function finiteNonNegative(value, name) {
  if (!Number.isFinite(value) || value < 0) throw new RangeError(`${name} must be a finite non-negative number`);
}

/** Pure survival simulation. Starvation is the core-layer survival threat. */
export class SurvivalState {
  constructor({
    health = 20,
    hunger = 20,
    timeOfDay = 0.25,
    elapsedDays = 0,
    dayLengthSeconds = 600,
    hungerDrainPerSecond = 0.008,
  } = {}) {
    finiteNonNegative(health, 'health');
    finiteNonNegative(hunger, 'hunger');
    finiteNonNegative(elapsedDays, 'elapsedDays');
    if (!Number.isFinite(timeOfDay)) throw new RangeError('timeOfDay must be finite');
    if (!Number.isFinite(dayLengthSeconds) || dayLengthSeconds <= 0) {
      throw new RangeError('dayLengthSeconds must be positive');
    }
    finiteNonNegative(hungerDrainPerSecond, 'hungerDrainPerSecond');

    this.health = clamp(health, 0, 20);
    this.hunger = clamp(hunger, 0, 20);
    // Preserve already-normalized values exactly so JSON round-trips are lossless.
    this.timeOfDay = timeOfDay >= 0 && timeOfDay < 1
      ? timeOfDay
      : ((timeOfDay % 1) + 1) % 1;
    this.elapsedDays = Math.floor(elapsedDays);
    this.dayLengthSeconds = dayLengthSeconds;
    this.hungerDrainPerSecond = hungerDrainPerSecond;
  }

  get isAlive() {
    return this.health > 0;
  }

  get daylight() {
    // Smooth brightness: dawn near 0.25, noon near 0.5, night near 0/1.
    return clamp(0.15 + 0.85 * Math.sin(Math.PI * this.timeOfDay), 0.15, 1);
  }

  /** Advances all survival clocks. effort adds hunger drain for movement/mining. */
  tick(deltaSeconds, { effort = 0 } = {}) {
    finiteNonNegative(deltaSeconds, 'deltaSeconds');
    finiteNonNegative(effort, 'effort');
    if (deltaSeconds === 0) return this.snapshot();

    const totalTime = this.timeOfDay + deltaSeconds / this.dayLengthSeconds;
    const crossedDays = Math.floor(totalTime);
    this.elapsedDays += crossedDays;
    this.timeOfDay = totalTime - crossedDays;

    const drain = deltaSeconds * this.hungerDrainPerSecond * (1 + effort);
    this.hunger = clamp(this.hunger - drain, 0, 20);

    if (this.hunger === 0) {
      this.health = clamp(this.health - deltaSeconds * 0.5, 0, 20);
    } else if (this.hunger >= 18 && this.health > 0) {
      this.health = clamp(this.health + deltaSeconds * 0.08, 0, 20);
    }
    return this.snapshot();
  }

  consume(nutrition) {
    finiteNonNegative(nutrition, 'nutrition');
    this.hunger = clamp(this.hunger + nutrition, 0, 20);
    return this.hunger;
  }

  damage(amount) {
    finiteNonNegative(amount, 'amount');
    this.health = clamp(this.health - amount, 0, 20);
    return this.health;
  }

  snapshot() {
    return {
      health: this.health,
      hunger: this.hunger,
      timeOfDay: this.timeOfDay,
      elapsedDays: this.elapsedDays,
      dayLengthSeconds: this.dayLengthSeconds,
      hungerDrainPerSecond: this.hungerDrainPerSecond,
    };
  }

  toJSON() {
    return this.snapshot();
  }

  static fromJSON(data) {
    if (!data || typeof data !== 'object') throw new TypeError('Invalid survival data');
    return new SurvivalState(data);
  }
}
