import {
  BLOCKS,
  Inventory,
  SurvivalState,
  deserializeGame,
  generateWorld,
  serializeGame,
} from '../core/index.js';
import { createProceduralAudio, initUI, OVERLAY_MODES } from '../ui/index.js';

const SAVE_KEY = 'wildcube-survival-v1';
const PLAYER_HEIGHT = 1.8;
const PLAYER_RADIUS = 0.3;
const EYE_HEIGHT = 1.62;
const REACH = 6;
const FACE_VERTICES = [
  { n: [1, 0, 0], c: [[1, 0, 0], [1, 1, 0], [1, 1, 1], [1, 0, 1]], light: 0.82 },
  { n: [-1, 0, 0], c: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]], light: 0.68 },
  { n: [0, 1, 0], c: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], light: 1 },
  { n: [0, -1, 0], c: [[0, 0, 0], [1, 0, 0], [1, 0, 1], [0, 0, 1]], light: 0.48 },
  { n: [0, 0, 1], c: [[1, 0, 1], [1, 1, 1], [0, 1, 1], [0, 0, 1]], light: 0.76 },
  { n: [0, 0, -1], c: [[0, 0, 0], [0, 1, 0], [1, 1, 0], [1, 0, 0]], light: 0.61 },
];
const TRI = [0, 1, 2, 0, 2, 3];
const ICONS = { meadow: '▧', loam: '▤', bedrock: '◆', sunwood: '▥', sunleaf: '✤', ember_ore: '✦', timber_tile: '▦' };

function colorParts(hex) {
  return [((hex >> 16) & 255) / 255, ((hex >> 8) & 255) / 255, (hex & 255) / 255];
}
function clamp(value, min, max) { return Math.min(max, Math.max(min, value)); }
function direction(yaw, pitch) {
  const cp = Math.cos(pitch);
  return [Math.sin(yaw) * cp, Math.sin(pitch), -Math.cos(yaw) * cp];
}
function perspective(fov, aspect, near, far) {
  const f = 1 / Math.tan(fov / 2); const nf = 1 / (near - far);
  return new Float32Array([f / aspect, 0, 0, 0, 0, f, 0, 0, 0, 0, (far + near) * nf, -1, 0, 0, 2 * far * near * nf, 0]);
}
function lookAt(eye, target, up = [0, 1, 0]) {
  let zx = eye[0] - target[0], zy = eye[1] - target[1], zz = eye[2] - target[2];
  let len = Math.hypot(zx, zy, zz) || 1; zx /= len; zy /= len; zz /= len;
  let xx = up[1] * zz - up[2] * zy, xy = up[2] * zx - up[0] * zz, xz = up[0] * zy - up[1] * zx;
  len = Math.hypot(xx, xy, xz) || 1; xx /= len; xy /= len; xz /= len;
  const yx = zy * xz - zz * xy, yy = zz * xx - zx * xz, yz = zx * xy - zy * xx;
  return new Float32Array([xx, yx, zx, 0, xy, yy, zy, 0, xz, yz, zz, 0,
    -(xx * eye[0] + xy * eye[1] + xz * eye[2]), -(yx * eye[0] + yy * eye[1] + yz * eye[2]), -(zx * eye[0] + zy * eye[1] + zz * eye[2]), 1]);
}
function multiply(a, b) {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column += 1) for (let row = 0; row < 4; row += 1) {
    out[column * 4 + row] = a[row] * b[column * 4] + a[4 + row] * b[column * 4 + 1] + a[8 + row] * b[column * 4 + 2] + a[12 + row] * b[column * 4 + 3];
  }
  return out;
}
function shader(gl, type, source) {
  const value = gl.createShader(type); gl.shaderSource(value, source); gl.compileShader(value);
  if (!gl.getShaderParameter(value, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(value));
  return value;
}

class VoxelRenderer {
  constructor(root) {
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'game-canvas';
    this.canvas.tabIndex = 0;
    root.append(this.canvas);
    const gl = this.canvas.getContext('webgl2', { antialias: true });
    if (!gl) throw new Error('需要支持 WebGL 2 的现代桌面浏览器。');
    this.gl = gl;
    const vertex = shader(gl, gl.VERTEX_SHADER, `#version 300 es
      in vec3 aPosition; in vec3 aColor; uniform mat4 uViewProjection;
      out vec3 vColor; out vec3 vPosition;
      void main(){ vColor=aColor; vPosition=aPosition; gl_Position=uViewProjection*vec4(aPosition,1.0); }`);
    const fragment = shader(gl, gl.FRAGMENT_SHADER, `#version 300 es
      precision highp float; in vec3 vColor; in vec3 vPosition; uniform float uFog; out vec4 outColor;
      float hash(vec3 p){ return fract(sin(dot(floor(p*7.0),vec3(17.1,61.7,113.5)))*43758.5453); }
      void main(){ vec3 f=fract(vPosition+0.0007); float edge=min(min(min(f.x,1.0-f.x),min(f.y,1.0-f.y)),min(f.z,1.0-f.z));
        float mortar=smoothstep(0.018,0.055,edge); float grain=0.91+hash(vPosition)*0.12;
        vec3 color=vColor*mix(0.58,grain,mortar); float fog=clamp(gl_FragCoord.z*uFog,0.0,0.36); outColor=vec4(mix(color,vec3(0.55,0.72,0.78),fog),1.0); }`);
    const program = gl.createProgram(); gl.attachShader(program, vertex); gl.attachShader(program, fragment); gl.linkProgram(program);
    if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(program));
    this.program = program; this.position = gl.getAttribLocation(program, 'aPosition'); this.color = gl.getAttribLocation(program, 'aColor');
    this.vp = gl.getUniformLocation(program, 'uViewProjection'); this.fog = gl.getUniformLocation(program, 'uFog');
    this.buffer = gl.createBuffer(); this.vertexCount = 0;
    gl.enable(gl.DEPTH_TEST); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);
  }
  rebuild(world) {
    const data = [];
    world.forEach((blockId, x, y, z) => {
      const base = colorParts(BLOCKS[blockId].color);
      FACE_VERTICES.forEach((face) => {
        const neighbor = world.get(x + face.n[0], y + face.n[1], z + face.n[2]);
        if (neighbor && neighbor !== 'air') return;
        TRI.forEach((index) => {
          const corner = face.c[index];
          data.push(x + corner[0], y + corner[1], z + corner[2], base[0] * face.light, base[1] * face.light, base[2] * face.light);
        });
      });
    });
    const gl = this.gl; gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(data), gl.STATIC_DRAW);
    this.vertexCount = data.length / 6;
  }
  draw(camera, daylight) {
    const gl = this.gl; const dpr = Math.min(2, devicePixelRatio || 1); const width = Math.floor(innerWidth * dpr); const height = Math.floor(innerHeight * dpr);
    if (this.canvas.width !== width || this.canvas.height !== height) { this.canvas.width = width; this.canvas.height = height; }
    const sky = [0.025 + daylight * 0.5, 0.045 + daylight * 0.63, 0.09 + daylight * 0.78];
    gl.viewport(0, 0, width, height); gl.clearColor(...sky, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
    const dir = direction(camera.yaw, camera.pitch); const eye = [camera.x, camera.y + EYE_HEIGHT, camera.z];
    const vp = multiply(perspective(Math.PI / 3, width / height, 0.08, 90), lookAt(eye, [eye[0] + dir[0], eye[1] + dir[1], eye[2] + dir[2]]));
    gl.useProgram(this.program); gl.uniformMatrix4fv(this.vp, false, vp); gl.uniform1f(this.fog, 0.28);
    gl.bindBuffer(gl.ARRAY_BUFFER, this.buffer); gl.enableVertexAttribArray(this.position); gl.vertexAttribPointer(this.position, 3, gl.FLOAT, false, 24, 0);
    gl.enableVertexAttribArray(this.color); gl.vertexAttribPointer(this.color, 3, gl.FLOAT, false, 24, 12); gl.drawArrays(gl.TRIANGLES, 0, this.vertexCount);
  }
}

export class WildcubeGame {
  constructor(root) {
    this.root = root; this.renderer = new VoxelRenderer(root); this.audio = createProceduralAudio();
    this.keys = new Set(); this.paused = true; this.overlay = OVERLAY_MODES.START; this.status = '世界已生成 · 点击开始探索'; this.statusUntil = 0;
    this.seed = `horizon-${new Date().toISOString().slice(0, 10)}`; this.reset();
    this.ui = initUI({ root, callbacks: {
      onStart: () => this.enterGame(), onResume: () => this.enterGame(), onRestart: () => { this.reset(); this.enterGame(); },
      onHelp: () => { this.paused = true; this.overlay = OVERLAY_MODES.HELP; this.updateUI(); },
      onCloseHelp: () => { this.overlay = OVERLAY_MODES.PAUSE; this.updateUI(); },
    }, initialState: { overlay: OVERLAY_MODES.START } });
    this.bind(); this.updateUI(); this.last = performance.now(); requestAnimationFrame((time) => this.frame(time));
  }
  reset() {
    this.world = generateWorld({ seed: this.seed, width: 32, height: 24, depth: 32 });
    this.inventory = new Inventory(); this.inventory.add('timber_tile', 12); this.inventory.add('loam', 8);
    this.survival = new SurvivalState({ hungerDrainPerSecond: 0.025, dayLengthSeconds: 360 });
    const x = Math.floor(this.world.width / 2), z = Math.floor(this.world.depth / 2); let top = 1;
    for (let y = this.world.height - 1; y >= 0; y -= 1) if (this.world.get(x, y, z) !== 'air') { top = y + 1.02; break; }
    this.player = { x: x + 0.5, y: top, z: z + 0.5, yaw: 0, pitch: 0, vy: 0, grounded: false, fallStart: top };
    this.nightDamageClock = 0; this.renderer.rebuild(this.world); if (this.ui) this.updateUI();
  }
  bind() {
    addEventListener('keydown', (event) => {
      this.keys.add(event.code);
      if (/^Digit[1-9]$/.test(event.code)) { this.inventory.select(Number(event.code.slice(5)) - 1); this.updateUI(); }
      if (event.code === 'KeyH' || event.code === 'KeyE') { this.paused = true; document.exitPointerLock?.(); this.overlay = OVERLAY_MODES.HELP; this.updateUI(); }
      if (event.code === 'KeyP') this.save(); if (event.code === 'KeyL') this.load(); if (event.code === 'KeyF') this.eatLeaf();
    });
    addEventListener('keyup', (event) => this.keys.delete(event.code));
    addEventListener('mousemove', (event) => { if (document.pointerLockElement !== this.renderer.canvas || this.paused) return; this.player.yaw -= event.movementX * 0.0022; this.player.pitch = clamp(this.player.pitch - event.movementY * 0.0022, -1.52, 1.52); });
    this.renderer.canvas.addEventListener('mousedown', (event) => { if (document.pointerLockElement !== this.renderer.canvas || this.paused) return; if (event.button === 0) this.breakBlock(); if (event.button === 2) this.placeBlock(); });
    this.renderer.canvas.addEventListener('contextmenu', (event) => event.preventDefault());
    this.renderer.canvas.addEventListener('wheel', (event) => { const next = (this.inventory.selectedIndex + (event.deltaY > 0 ? 1 : 8)) % 9; this.inventory.select(next); this.updateUI(); }, { passive: true });
    document.addEventListener('pointerlockchange', () => {
      if (document.pointerLockElement === this.renderer.canvas) {
        this.paused = false;
        this.overlay = OVERLAY_MODES.NONE;
        this.setStatus('WASD 移动 · 左键采集 · 右键建造 · H 帮助', 4500);
      } else if (!this.paused) {
        this.paused = true;
        this.overlay = OVERLAY_MODES.PAUSE;
        this.updateUI();
      }
    });
    addEventListener('beforeunload', () => { try { this.save(false); } catch {} });
  }
  enterGame() {
    this.audio.unlock().catch(() => {});
    this.paused = true;
    const request = this.renderer.canvas.requestPointerLock();
    request?.catch?.(() => {
      this.paused = true;
      this.overlay = this.overlay === OVERLAY_MODES.START ? OVERLAY_MODES.START : OVERLAY_MODES.PAUSE;
      this.setStatus('鼠标锁定失败，请再次点击开始并允许浏览器锁定指针', 4500);
    });
  }
  setStatus(text, duration = 2200) { this.status = text; this.statusUntil = performance.now() + duration; this.updateUI(); }
  hotbar() { return this.inventory.getSlots().map((slot) => slot ? { name: BLOCKS[slot.blockId].label, count: slot.count, icon: ICONS[slot.blockId] } : null); }
  updateUI(hit = this.raycast()) {
    if (!this.ui) return;
    const chosen = this.inventory.getSlot(this.inventory.selectedIndex); const hint = hit?.block ? `${BLOCKS[hit.block].label} · 左键采集 / 右键放置` : chosen ? `已选择 ${BLOCKS[chosen.blockId].label}` : '采集方块来补充快捷栏';
    this.ui.update({ health: this.survival.health, hunger: this.survival.hunger, hotbar: this.hotbar(), selectedSlot: this.inventory.selectedIndex,
      dayTime: this.survival.timeOfDay, day: this.survival.elapsedDays + 1, status: performance.now() < this.statusUntil ? this.status : '', hint, overlay: this.overlay,
      overlayTitle: this.overlay === OVERLAY_MODES.DEATH ? '荒野带走了你' : undefined });
  }
  isSolid(x, y, z) {
    if (y < 0 || x < 0 || z < 0 || x >= this.world.width || z >= this.world.depth) return true;
    const id = this.world.get(x, y, z); return Boolean(id && BLOCKS[id].solid);
  }
  collides(x, y, z) {
    const minX = Math.floor(x - PLAYER_RADIUS), maxX = Math.floor(x + PLAYER_RADIUS - 0.001), minY = Math.floor(y), maxY = Math.floor(y + PLAYER_HEIGHT - 0.001), minZ = Math.floor(z - PLAYER_RADIUS), maxZ = Math.floor(z + PLAYER_RADIUS - 0.001);
    for (let ix = minX; ix <= maxX; ix += 1) for (let iy = minY; iy <= maxY; iy += 1) for (let iz = minZ; iz <= maxZ; iz += 1) if (this.isSolid(ix, iy, iz)) return true;
    return false;
  }
  moveAxis(axis, amount) { const before = this.player[axis]; this.player[axis] += amount; if (this.collides(this.player.x, this.player.y, this.player.z)) { this.player[axis] = before; return false; } return true; }
  step(dt) {
    const sprint = this.keys.has('ShiftLeft') || this.keys.has('ShiftRight'); const speed = sprint ? 6.2 : 4.2; let forward = 0, side = 0;
    if (this.keys.has('KeyW')) forward += 1; if (this.keys.has('KeyS')) forward -= 1; if (this.keys.has('KeyD')) side += 1; if (this.keys.has('KeyA')) side -= 1;
    const length = Math.hypot(forward, side) || 1; forward /= length; side /= length;
    const dx = (Math.sin(this.player.yaw) * forward + Math.cos(this.player.yaw) * side) * speed * dt;
    const dz = (-Math.cos(this.player.yaw) * forward + Math.sin(this.player.yaw) * side) * speed * dt;
    this.moveAxis('x', dx); this.moveAxis('z', dz);
    if (this.keys.has('Space') && this.player.grounded) { this.player.vy = 7.4; this.player.grounded = false; this.player.fallStart = this.player.y; }
    const wasGrounded = this.player.grounded;
    this.player.vy -= 20 * dt; const falling = this.player.vy < 0; const movedY = this.moveAxis('y', this.player.vy * dt);
    if (!movedY) {
      if (falling) {
        const distance = this.player.fallStart - this.player.y;
        if (distance > 4) { this.survival.damage((distance - 3) * 1.3); this.audio.play('hurt').catch(() => {}); }
        this.player.grounded = true;
        this.player.fallStart = this.player.y;
      }
      this.player.vy = 0;
    } else {
      if (wasGrounded && falling) this.player.fallStart = this.player.y;
      this.player.grounded = false;
      if (this.player.vy > 0) this.player.fallStart = this.player.y;
    }
    const moving = Math.abs(forward) + Math.abs(side) > 0; this.survival.tick(dt, { effort: moving ? (sprint ? 1.8 : 0.45) : 0 });
    const night = this.survival.timeOfDay < 0.19 || this.survival.timeOfDay > 0.81;
    if (night && !this.hasRoof()) { this.nightDamageClock += dt; if (this.nightDamageClock > 12) { this.nightDamageClock = 0; this.survival.damage(1); this.audio.play('hurt').catch(() => {}); this.setStatus('夜寒正在侵蚀生命 · 快搭建庇护所', 3500); } } else this.nightDamageClock = 0;
    if (!this.survival.isAlive) { this.paused = true; document.exitPointerLock?.(); this.overlay = OVERLAY_MODES.DEATH; }
  }
  hasRoof() { const x = Math.floor(this.player.x), z = Math.floor(this.player.z); for (let y = Math.floor(this.player.y + PLAYER_HEIGHT); y < this.world.height; y += 1) if (this.isSolid(x, y, z)) return true; return false; }
  raycast() {
    const dir = direction(this.player.yaw, this.player.pitch); const eye = [this.player.x, this.player.y + EYE_HEIGHT, this.player.z]; let previous = null; let lastKey = '';
    for (let distance = 0; distance <= REACH; distance += 0.045) {
      const cell = [Math.floor(eye[0] + dir[0] * distance), Math.floor(eye[1] + dir[1] * distance), Math.floor(eye[2] + dir[2] * distance)]; const key = cell.join(',');
      if (key === lastKey) continue; lastKey = key; const block = this.world.get(...cell); if (block && block !== 'air') return { cell, block, place: previous }; previous = cell;
    }
    return null;
  }
  breakBlock() { const hit = this.raycast(); if (!hit || hit.cell[1] === 0) return; const removed = this.world.remove(...hit.cell); if (removed && removed !== 'air') { const accepted = this.inventory.add(removed, 1); if (!accepted) this.world.set(...hit.cell, removed); else { this.renderer.rebuild(this.world); this.audio.play('break').catch(() => {}); this.setStatus(`获得 ${BLOCKS[removed].label}`); } } }
  placeBlock() {
    const hit = this.raycast(); const slot = this.inventory.getSlot(this.inventory.selectedIndex); if (!hit?.place || !slot) return;
    const [x, y, z] = hit.place; if (this.world.get(x, y, z) !== 'air') return; this.world.set(x, y, z, slot.blockId);
    if (this.collides(this.player.x, this.player.y, this.player.z)) { this.world.set(x, y, z, 'air'); return; }
    this.inventory.remove(slot.blockId, 1); this.renderer.rebuild(this.world); this.audio.play('place').catch(() => {}); this.setStatus(`放置 ${BLOCKS[slot.blockId].label}`);
  }
  eatLeaf() { if (this.inventory.remove('sunleaf', 1)) { this.survival.consume(3); this.setStatus('嚼食阳叶：饥饿恢复 3'); } else this.setStatus('背包中没有阳叶'); }
  save(notify = true) { const data = serializeGame({ world: this.world, inventory: this.inventory, survival: this.survival, metadata: { player: this.player, seed: this.seed } }); localStorage.setItem(SAVE_KEY, data); if (notify) this.setStatus('世界已保存到本机'); }
  load() {
    try { const raw = localStorage.getItem(SAVE_KEY); if (!raw) throw new Error('尚无存档'); const game = deserializeGame(raw); this.world = game.world; this.inventory = game.inventory; this.survival = game.survival; Object.assign(this.player, game.metadata.player || {}); this.seed = game.metadata.seed || this.seed; this.renderer.rebuild(this.world); this.setStatus('已读取本机存档'); }
    catch (error) { this.setStatus(`读档失败：${error.message}`, 3500); }
  }
  frame(time) {
    const dt = Math.min(0.05, Math.max(0, (time - this.last) / 1000)); this.last = time; if (!this.paused) this.step(dt);
    this.renderer.draw(this.player, this.survival.daylight); this.updateUI(); requestAnimationFrame((next) => this.frame(next));
  }
}
