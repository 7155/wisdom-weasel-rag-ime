export { WildcubeGame } from './runtime.js';
