import { WildcubeGame } from './game/runtime.js';

const root = document.querySelector('#app');
try {
  new WildcubeGame(root);
} catch (error) {
  console.error(error);
  root.innerHTML = `<section class="fatal-error"><h1>无法启动荒野方境</h1><p>${String(error.message)}</p><p>请使用支持 WebGL 2、ES Modules 和 Pointer Lock 的现代桌面浏览器。</p></section>`;
}
