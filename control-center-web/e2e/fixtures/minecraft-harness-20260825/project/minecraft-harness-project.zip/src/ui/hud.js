const HEART_COUNT = 10;
const HUNGER_COUNT = 10;
const HOTBAR_SIZE = 9;

export const OVERLAY_MODES = Object.freeze({
  NONE: 'none',
  START: 'start',
  PAUSE: 'pause',
  DEATH: 'death',
  HELP: 'help',
});

const OVERLAY_COPY = Object.freeze({
  start: {
    eyebrow: '原创方块生存',
    title: '荒野方格',
    body: '采集、建造，并在昼夜更替中活下去。',
    primary: '开始探索',
    primaryAction: 'start',
    secondary: '操作帮助',
    secondaryAction: 'help',
  },
  pause: {
    eyebrow: '游戏已暂停',
    title: '稍作休整',
    body: '世界会在你返回前保持安静。',
    primary: '继续游戏',
    primaryAction: 'resume',
    secondary: '操作帮助',
    secondaryAction: 'help',
  },
  death: {
    eyebrow: '旅程结束',
    title: '你倒下了',
    body: '整理装备，再次迎接荒野。',
    primary: '重新开始',
    primaryAction: 'restart',
    secondary: '操作帮助',
    secondaryAction: 'help',
  },
  help: {
    eyebrow: '操作帮助',
    title: '探索者手册',
    body: '',
    primary: '返回',
    primaryAction: 'closeHelp',
  },
});

function element(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

function clamp(value, min, max, fallback = min) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
}

function resolveRoot(root) {
  if (typeof document === 'undefined') {
    throw new Error('[荒野方格 UI] 无法初始化：当前环境没有 DOM document。');
  }

  const resolved = typeof root === 'string' ? document.querySelector(root) : root;
  if (!resolved || typeof resolved.append !== 'function') {
    const target = typeof root === 'string' ? `“${root}”` : '传入的 root';
    throw new Error(`[荒野方格 UI] 无法初始化：未找到可用的挂载节点 ${target}。`);
  }
  return resolved;
}

function normalizeOverlay(value) {
  if (value == null || value === false || value === '') return OVERLAY_MODES.NONE;
  const mode = String(value).toLowerCase();
  return Object.values(OVERLAY_MODES).includes(mode) ? mode : OVERLAY_MODES.NONE;
}

function formatClock(dayTime) {
  const totalMinutes = Math.floor(clamp(dayTime, 0, 0.999999, 0.25) * 24 * 60);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
}

function makeMeter(type, count, label) {
  const wrapper = element('div', `survival-meter survival-meter--${type}`);
  wrapper.setAttribute('role', 'meter');
  wrapper.setAttribute('aria-label', label);
  const items = [];
  for (let index = 0; index < count; index += 1) {
    const item = element('span', `survival-pip survival-pip--${type}`);
    item.setAttribute('aria-hidden', 'true');
    item.textContent = type === 'health' ? '♥' : '◆';
    wrapper.append(item);
    items.push(item);
  }
  return { wrapper, items };
}

function makeHotbar() {
  const wrapper = element('ol', 'hotbar');
  wrapper.id = 'ui-hotbar';
  wrapper.setAttribute('aria-label', '九格快捷栏');
  const slots = [];

  for (let index = 0; index < HOTBAR_SIZE; index += 1) {
    const slot = element('li', 'hotbar__slot');
    slot.dataset.slot = String(index);
    const key = element('span', 'hotbar__key', String(index + 1));
    const icon = element('span', 'hotbar__icon');
    const name = element('span', 'hotbar__name');
    const count = element('span', 'hotbar__count');
    slot.append(key, icon, name, count);
    wrapper.append(slot);
    slots.push({ slot, icon, name, count });
  }

  return { wrapper, slots };
}

function makeOverlay() {
  const wrapper = element('section', 'game-overlay is-hidden');
  wrapper.id = 'ui-overlay';
  wrapper.setAttribute('aria-live', 'polite');
  wrapper.setAttribute('aria-modal', 'true');
  wrapper.setAttribute('role', 'dialog');

  const panel = element('div', 'game-overlay__panel');
  const eyebrow = element('p', 'game-overlay__eyebrow');
  const title = element('h1', 'game-overlay__title');
  const body = element('p', 'game-overlay__body');
  const help = element('dl', 'help-grid is-hidden');
  const controls = [
    ['W A S D', '移动'],
    ['Shift', '奔跑'],
    ['鼠标', '观察'],
    ['空格', '跳跃'],
    ['左键', '破坏方块'],
    ['右键', '放置方块'],
    ['1–9 / 滚轮', '选择快捷栏'],
    ['F', '食用背包中的阳叶'],
    ['P / L', '保存 / 读取本机世界'],
    ['Esc', '暂停'],
    ['H / E', '帮助'],
  ];
  for (const [key, description] of controls) {
    help.append(element('dt', '', key), element('dd', '', description));
  }
  const actions = element('div', 'game-overlay__actions');
  const primary = element('button', 'menu-button menu-button--primary');
  primary.type = 'button';
  const secondary = element('button', 'menu-button menu-button--secondary');
  secondary.type = 'button';
  actions.append(primary, secondary);
  panel.append(eyebrow, title, body, help, actions);
  wrapper.append(panel);

  return { wrapper, eyebrow, title, body, help, primary, secondary };
}

function setMeter(meter, current, maximum) {
  const safeMax = Math.max(1, Number(maximum) || 20);
  const safeCurrent = clamp(current, 0, safeMax, safeMax);
  const unitsPerPip = safeMax / meter.items.length;

  meter.items.forEach((item, index) => {
    const remaining = safeCurrent - index * unitsPerPip;
    item.classList.toggle('is-full', remaining >= unitsPerPip);
    item.classList.toggle('is-half', remaining > 0 && remaining < unitsPerPip);
    item.classList.toggle('is-empty', remaining <= 0);
  });
  meter.wrapper.setAttribute('aria-valuemin', '0');
  meter.wrapper.setAttribute('aria-valuemax', String(safeMax));
  meter.wrapper.setAttribute('aria-valuenow', String(safeCurrent));
}

/**
 * Mounts the complete game HUD into a caller-owned DOM node.
 * The caller only passes serializable state and callbacks; no game modules are imported here.
 */
export function initUI({ root = '#game-root', callbacks = {}, initialState = {} } = {}) {
  const mount = resolveRoot(root);
  if (mount.querySelector?.(':scope > #game-ui')) {
    throw new Error('[荒野方格 UI] 无法初始化：挂载节点中已经存在 #game-ui。请先调用 destroy()。');
  }

  const host = element('div', 'game-ui');
  host.id = 'game-ui';
  const hud = element('section', 'game-hud');
  hud.id = 'game-hud';
  hud.setAttribute('aria-label', '生存状态');

  const topBar = element('div', 'hud-topbar');
  const status = element('div', 'hud-status');
  status.id = 'ui-status';
  status.setAttribute('role', 'status');
  const clock = element('div', 'day-clock');
  clock.id = 'ui-clock';
  const clockPhase = element('span', 'day-clock__phase');
  const clockTime = element('strong', 'day-clock__time');
  const clockDay = element('span', 'day-clock__day');
  clock.append(clockPhase, clockTime, clockDay);
  topBar.append(status, clock);

  const crosshair = element('div', 'crosshair');
  crosshair.id = 'ui-crosshair';
  crosshair.setAttribute('aria-hidden', 'true');
  const hint = element('p', 'hud-hint');
  hint.id = 'ui-hint';
  hint.setAttribute('aria-live', 'polite');

  const bottom = element('div', 'hud-bottom');
  const health = makeMeter('health', HEART_COUNT, '生命值');
  health.wrapper.id = 'ui-hearts';
  const hunger = makeMeter('hunger', HUNGER_COUNT, '饥饿值');
  hunger.wrapper.id = 'ui-hunger';
  const hotbar = makeHotbar();
  const meters = element('div', 'survival-meters');
  meters.append(health.wrapper, hunger.wrapper);
  bottom.append(meters, hotbar.wrapper);

  const overlay = makeOverlay();
  hud.append(topBar, crosshair, hint, bottom);
  host.append(hud, overlay.wrapper);
  mount.append(host);

  let currentCallbacks = { ...callbacks };
  let previousOverlay = OVERLAY_MODES.NONE;

  const invoke = (action) => {
    const callbackName = {
      start: 'onStart',
      resume: 'onResume',
      restart: 'onRestart',
      help: 'onHelp',
      closeHelp: 'onCloseHelp',
    }[action];
    currentCallbacks[callbackName]?.();
  };
  const onPrimary = () => invoke(overlay.primary.dataset.action);
  const onSecondary = () => invoke(overlay.secondary.dataset.action);
  overlay.primary.addEventListener('click', onPrimary);
  overlay.secondary.addEventListener('click', onSecondary);

  function update(state = {}) {
    if (!state || typeof state !== 'object') {
      throw new TypeError('[荒野方格 UI] update(state) 需要一个状态对象。');
    }

    const maxHealth = Math.max(1, Number(state.maxHealth) || 20);
    const maxHunger = Math.max(1, Number(state.maxHunger) || 20);
    setMeter(health, state.health ?? maxHealth, maxHealth);
    setMeter(hunger, state.hunger ?? maxHunger, maxHunger);

    const selectedSlot = Math.floor(clamp(state.selectedSlot, 0, HOTBAR_SIZE - 1, 0));
    const items = Array.isArray(state.hotbar) ? state.hotbar : [];
    hotbar.slots.forEach((parts, index) => {
      const item = items[index] ?? null;
      const name = item?.name == null ? '' : String(item.name);
      const count = Math.max(0, Math.floor(Number(item?.count) || 0));
      parts.slot.classList.toggle('is-selected', index === selectedSlot);
      parts.slot.classList.toggle('is-empty', !item || count === 0);
      parts.slot.setAttribute('aria-label', item && count > 0 ? `${index + 1}：${name || '资源'}，${count}` : `${index + 1}：空`);
      parts.slot.setAttribute('aria-current', index === selectedSlot ? 'true' : 'false');
      parts.icon.textContent = item?.icon == null ? '' : String(item.icon).slice(0, 3);
      parts.name.textContent = name;
      parts.count.textContent = count > 0 ? String(count) : '';
    });

    status.textContent = state.status == null ? '' : String(state.status);
    status.classList.toggle('is-hidden', !status.textContent);
    hint.textContent = state.hint == null ? '' : String(state.hint);
    hint.classList.toggle('is-hidden', !hint.textContent);

    const dayTime = clamp(state.dayTime, 0, 0.999999, 0.25);
    const isNight = dayTime < 0.22 || dayTime >= 0.78;
    const phase = isNight ? '夜晚' : dayTime < 0.32 ? '清晨' : dayTime < 0.68 ? '白昼' : '黄昏';
    clockPhase.textContent = phase;
    clockTime.textContent = formatClock(dayTime);
    clockDay.textContent = `第 ${Math.max(1, Math.floor(Number(state.day) || 1))} 天`;
    clock.classList.toggle('is-night', isNight);

    const mode = normalizeOverlay(state.overlay ?? state.screen);
    const copy = OVERLAY_COPY[mode];
    overlay.wrapper.classList.toggle('is-hidden', mode === OVERLAY_MODES.NONE);
    overlay.wrapper.dataset.mode = mode;
    hud.classList.toggle('is-obscured', mode !== OVERLAY_MODES.NONE);

    if (copy) {
      if (mode !== OVERLAY_MODES.HELP) previousOverlay = mode;
      overlay.eyebrow.textContent = copy.eyebrow;
      overlay.title.textContent = state.overlayTitle == null ? copy.title : String(state.overlayTitle);
      overlay.body.textContent = state.overlayMessage == null ? copy.body : String(state.overlayMessage);
      overlay.help.classList.toggle('is-hidden', mode !== OVERLAY_MODES.HELP);
      overlay.primary.textContent = copy.primary;
      overlay.primary.dataset.action = copy.primaryAction;
      if (mode === OVERLAY_MODES.HELP && !currentCallbacks.onCloseHelp) {
        overlay.primary.dataset.action = previousOverlay === OVERLAY_MODES.PAUSE ? 'resume' : 'start';
      }
      overlay.secondary.classList.toggle('is-hidden', !copy.secondary);
      overlay.secondary.textContent = copy.secondary ?? '';
      overlay.secondary.dataset.action = copy.secondaryAction ?? '';
    }

    return api;
  }

  const api = {
    update,
    setCallbacks(nextCallbacks = {}) {
      currentCallbacks = { ...nextCallbacks };
      return api;
    },
    destroy() {
      overlay.primary.removeEventListener('click', onPrimary);
      overlay.secondary.removeEventListener('click', onSecondary);
      host.remove();
    },
    elements: Object.freeze({ host, hud, status, clock, hint, hotbar: hotbar.wrapper, overlay: overlay.wrapper }),
  };

  return update(initialState);
}
