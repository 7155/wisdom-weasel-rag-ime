# UI / audio integration contract

`src/ui/index.js` is the public ES module entry. This layer imports no core or game modules; `main.js` supplies state and callbacks.

## DOM UI

```js
import { initUI, OVERLAY_MODES } from './ui/index.js';
import './style.css';

const ui = initUI({
  root: '#game-root',
  callbacks: {
    onStart,
    onResume,
    onRestart,
    onHelp,
    onCloseHelp,
  },
  initialState: { overlay: OVERLAY_MODES.START },
});

ui.update({
  health: 18,
  maxHealth: 20,
  hunger: 13,
  maxHunger: 20,
  hotbar: [
    { name: 'Sunwood', icon: '木', count: 12 },
    null,
    // up to nine entries
  ],
  selectedSlot: 0,
  status: '附近很安全',
  hint: '左键采集方块',
  dayTime: 0.42, // normalized [0, 1)
  day: 2,
  overlay: 'none', // none | start | pause | death | help
});
```

`update(state)` renders a complete snapshot rather than merging a patch. Defaults are 20 health, 20 hunger, an empty nine-slot hotbar, day 1 at 06:00, and no overlay. It returns the same controller for chaining. `setCallbacks(nextCallbacks)` replaces the menu callback set; `destroy()` removes the generated UI.

The only caller-provided DOM requirement is a mount element. The default selector is `#game-root`; an element may be passed directly. A missing `document`, missing mount, or duplicate generated `#game-ui` throws a descriptive error. The module creates these integration/debug IDs beneath the mount:

- `#game-ui`, `#game-hud`
- `#ui-hearts`, `#ui-hunger`, `#ui-crosshair`
- `#ui-hotbar`, `#ui-status`, `#ui-hint`, `#ui-clock`
- `#ui-overlay`

Core snapshots map without shared-module imports: use `survival.health`, `survival.hunger`, `survival.timeOfDay` as `health`, `hunger`, `dayTime`; use `survival.elapsedDays + 1` as `day`; map inventory `{ blockId, count }` slots to `{ name, icon, count }` and `selectedIndex` to `selectedSlot`.

## Procedural audio

```js
import { createProceduralAudio } from './ui/index.js';

const audio = createProceduralAudio({ volume: 0.18 });
await audio.unlock(); // call from a user gesture when practical
await audio.play('break');
await audio.play('place');
await audio.play('hurt');
await audio.play('step', { material: 'stone', pitch: 1.05 });
```

`play()` lazily creates/resumes an `AudioContext`. Supported event aliases are `break`/`destroy`, `place`, `hurt`/`damage`, and `step`/`footstep`. `setMuted`, `setVolume`, and async `destroy` control lifecycle. Every sound is synthesized at runtime from oscillators and an in-memory random-noise buffer; there are no media requests or external audio assets.
