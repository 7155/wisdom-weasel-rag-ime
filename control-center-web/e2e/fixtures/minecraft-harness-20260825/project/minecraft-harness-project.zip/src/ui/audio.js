const EVENT_ALIASES = Object.freeze({
  break: 'break',
  destroy: 'break',
  place: 'place',
  hurt: 'hurt',
  damage: 'hurt',
  step: 'step',
  footstep: 'step',
});

function clamp(value, min, max, fallback) {
  const number = Number(value);
  return Number.isFinite(number) ? Math.min(max, Math.max(min, number)) : fallback;
}

function resolveAudioContext(AudioContextClass) {
  const Context = AudioContextClass ?? globalThis.AudioContext ?? globalThis.webkitAudioContext;
  if (!Context) {
    throw new Error('[荒野方格 Audio] 当前浏览器不支持 Web Audio API。');
  }
  return Context;
}

/** Creates short original sounds from oscillators and generated noise; no media files are loaded. */
export function createProceduralAudio({ AudioContextClass, volume = 0.18 } = {}) {
  let context = null;
  let master = null;
  let muted = false;
  let masterVolume = clamp(volume, 0, 1, 0.18);

  function ensureContext() {
    if (context) return context;
    const Context = resolveAudioContext(AudioContextClass);
    context = new Context();
    master = context.createGain();
    master.gain.value = muted ? 0 : masterVolume;
    master.connect(context.destination);
    return context;
  }

  async function unlock() {
    const audioContext = ensureContext();
    if (audioContext.state === 'suspended') await audioContext.resume();
    return audioContext;
  }

  function envelope(gainNode, start, peak, duration) {
    const gain = gainNode.gain;
    gain.cancelScheduledValues(start);
    gain.setValueAtTime(0.0001, start);
    gain.exponentialRampToValueAtTime(Math.max(0.0001, peak), start + Math.min(0.012, duration * 0.2));
    gain.exponentialRampToValueAtTime(0.0001, start + duration);
  }

  function tone({ frequency, endFrequency = frequency, type = 'sine', duration = 0.1, gain = 0.22, delay = 0 }) {
    const start = context.currentTime + delay;
    const oscillator = context.createOscillator();
    const amp = context.createGain();
    oscillator.type = type;
    oscillator.frequency.setValueAtTime(Math.max(20, frequency), start);
    oscillator.frequency.exponentialRampToValueAtTime(Math.max(20, endFrequency), start + duration);
    envelope(amp, start, gain, duration);
    oscillator.connect(amp);
    amp.connect(master);
    oscillator.start(start);
    oscillator.stop(start + duration + 0.02);
  }

  function noise({ duration = 0.1, gain = 0.14, frequency = 900, delay = 0 }) {
    const start = context.currentTime + delay;
    const frameCount = Math.max(1, Math.floor(context.sampleRate * duration));
    const buffer = context.createBuffer(1, frameCount, context.sampleRate);
    const data = buffer.getChannelData(0);
    for (let index = 0; index < frameCount; index += 1) {
      const falloff = 1 - index / frameCount;
      data[index] = (Math.random() * 2 - 1) * falloff;
    }
    const source = context.createBufferSource();
    source.buffer = buffer;
    const filter = context.createBiquadFilter();
    filter.type = 'bandpass';
    filter.frequency.setValueAtTime(frequency, start);
    filter.Q.value = 0.8;
    const amp = context.createGain();
    envelope(amp, start, gain, duration);
    source.connect(filter);
    filter.connect(amp);
    amp.connect(master);
    source.start(start);
    source.stop(start + duration + 0.02);
  }

  const players = {
    break(options) {
      const pitch = clamp(options.pitch, 0.7, 1.4, 1);
      noise({ duration: 0.14, gain: 0.24, frequency: 720 * pitch });
      tone({ frequency: 150 * pitch, endFrequency: 70 * pitch, type: 'square', duration: 0.11, gain: 0.09 });
    },
    place(options) {
      const pitch = clamp(options.pitch, 0.75, 1.35, 1);
      tone({ frequency: 120 * pitch, endFrequency: 82 * pitch, type: 'triangle', duration: 0.075, gain: 0.22 });
      noise({ duration: 0.045, gain: 0.08, frequency: 420 * pitch });
    },
    hurt(options) {
      const pitch = clamp(options.pitch, 0.8, 1.2, 1);
      tone({ frequency: 310 * pitch, endFrequency: 105 * pitch, type: 'sawtooth', duration: 0.18, gain: 0.2 });
      tone({ frequency: 180 * pitch, endFrequency: 90 * pitch, type: 'square', duration: 0.13, gain: 0.07, delay: 0.025 });
    },
    step(options) {
      const pitch = clamp(options.pitch, 0.75, 1.35, 1);
      const material = String(options.material ?? 'soil');
      const centers = { soil: 520, stone: 1050, wood: 760, sand: 390, grass: 610 };
      noise({ duration: 0.065, gain: 0.115, frequency: (centers[material] ?? centers.soil) * pitch });
      tone({ frequency: 92 * pitch, endFrequency: 62 * pitch, type: 'sine', duration: 0.055, gain: 0.055 });
    },
  };

  async function play(eventName, options = {}) {
    const event = EVENT_ALIASES[String(eventName).toLowerCase()];
    if (!event) {
      throw new RangeError(`[荒野方格 Audio] 未知音效“${eventName}”；可用值：break、place、hurt、step。`);
    }
    await unlock();
    players[event](options && typeof options === 'object' ? options : {});
    return event;
  }

  return {
    unlock,
    play,
    setMuted(value) {
      muted = Boolean(value);
      if (master) master.gain.setTargetAtTime(muted ? 0 : masterVolume, context.currentTime, 0.015);
    },
    setVolume(value) {
      masterVolume = clamp(value, 0, 1, masterVolume);
      if (master && !muted) master.gain.setTargetAtTime(masterVolume, context.currentTime, 0.015);
      return masterVolume;
    },
    get muted() {
      return muted;
    },
    async destroy() {
      const closing = context;
      context = null;
      master = null;
      if (closing && closing.state !== 'closed') await closing.close();
    },
  };
}
