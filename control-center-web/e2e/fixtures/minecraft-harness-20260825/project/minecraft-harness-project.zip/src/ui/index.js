export { initUI, OVERLAY_MODES } from './hud.js';
export { createProceduralAudio } from './audio.js';

/**
 * Integration example:
 *
 * const ui = initUI({
 *   root: '#game-root',
 *   callbacks: { onStart, onResume, onRestart, onHelp, onCloseHelp },
 *   initialState: { overlay: 'start' },
 * });
 * ui.update({ health: 18, hunger: 14, hotbar, selectedSlot: 0, dayTime: 0.4 });
 *
 * const audio = createProceduralAudio();
 * await audio.play('place'); // call from a user-input/game event
 */
