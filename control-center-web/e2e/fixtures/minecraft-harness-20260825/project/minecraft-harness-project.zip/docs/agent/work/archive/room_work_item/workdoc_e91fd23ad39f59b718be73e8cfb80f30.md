# Independent Integration Review

- Authority: `room_work_item:room-work:10000000-0000-4000-8000-000000000004`
- Authority revision: 2
- Role: reviewer
- State: result
- Scope: independent, read-only integration review against R1–R5.
- Production-code policy: no production files were modified by this reviewer; this Markdown is the only reviewer-owned write.

## Requirement source

`docs/agent/ROOT.md` is a registry navigation file. Its active Root entry resolves to `docs/agent/work/active/session_goal/workdoc_f955935eda4ce8595eaea1daec6b462d.md`, where R1–R5 are stated at lines 7–11.

## Command evidence

Commands were run directly in the authorized workspace:

- `npm test` — exit 0; 7 tests, 7 passed, 0 failed. Covered block definitions, deterministic generation, bounded world edits, nine-slot inventory, survival advancement, JSON save round-trip, and truncated-save rejection.
- `npm run build` — exit 0; output: `构建完成：dist/（零外部运行依赖）`.
- `node --check src/game/runtime.js` — exit 0 with no syntax diagnostics.
- Raw-rendering sanity checks — all six face triangle windings produced their declared outward normals; the perspective matrix contained finite expected coefficients.
- Default dated seeds sampled through `generateWorld` produced valid meadow spawn surfaces and nonzero ore/wood counts.

Two read-only support-review lanes were batch-dispatched (`subagent-batch:0feebf09-e6a4-4ad7-a6f8-ebbd68e2a6a7`) while the parent retained command and integration review. Both overran their bounded duration and were aborted without a final result; no unverified child conclusion is used below. The parent independently read and traced every requested production/test file.

## Findings

### Blocker

No source-level blocker was located. This does **not** substitute for the missing desktop playtest.

### High

1. **Fall damage origin is not reset after landing, so later short falls can repeat damage from an old high point.**
   - Evidence: `src/game/runtime.js:179-181`. `fallStart` advances during ascent, but the landing branch computes damage and sets `grounded` without resetting `fallStart` to the landed height.
   - Reproduction against the real `WildcubeGame.prototype.step`: after a landing at `y=5` with `fallStart=10`, `fallStart` remained `10`; a subsequent modeled one-level-lower landing produced another damage call (`2.6`, then `3.9`).
   - Impact: repeated or exaggerated health loss corrupts the R1/R3 movement-survival loop.
   - Minimal repair: on a downward collision, calculate the current fall once and then set `fallStart = player.y`; also initialize it to the current ledge height when transitioning from grounded to airborne. Add regression tests for two consecutive falls and a jump followed by a short ledge drop.

### Medium

1. **Pointer-lock rejection hides the menu and starts simulation anyway.**
   - Evidence: `src/game/runtime.js:149,152`. `enterGame()` ignores the Promise returned by `requestPointerLock()` and immediately sets `paused=false` and overlay `none`; the change listener only handles losing an already acquired lock.
   - Reproduction against the real method with a rejected pointer-lock Promise yielded `{ rejection: "denied", paused: false, overlay: "none" }`.
   - Impact: when browser policy or focus denies pointer lock, the user is left in a running world without mouse look or a visible recovery/error state, weakening R1 direct playability.
   - Minimal repair: move the unpause/overlay transition to successful `pointerlockchange` (or await the Promise); handle `pointerlockerror`/rejection by restoring START/PAUSE with an actionable message.

2. **The in-game help omits several implemented survival controls.**
   - Evidence: `src/ui/hud.js:136-145` lists WASD, mouse, jump, break/place, hotbar, Esc and H only, while `src/game/runtime.js:140-142` implements Shift sprint, E help, F eat, P save, and L load; `README.md:16-18` documents them.
   - Impact: save/load and the only explicit food action are not discoverable from the required in-game help flow (R3/R4).
   - Minimal repair: add Shift/E/F/P/L rows to the help overlay, preferably generated from one shared control definition.

3. **There is no automated integration seam for game runtime, UI, WebGL, or pointer lock.**
   - Evidence: `tests/core.test.js:1-114` imports only `src/core/index.js`; `src/game/runtime.js` and `src/ui/**` have no checked-in tests.
   - Impact: the two defects above pass all seven tests; shader compilation, matrix upload, input state, collision/fall transitions, HUD callbacks, audio unlock, and save/load wiring can regress while R5 remains green.
   - Minimal repair: add DOM/WebGL/Pointer-Lock fakes for constructor/input transitions and physics regressions, plus one real-browser smoke test when a desktop provider is available.

## Traced call paths and non-findings

- **Raw WebGL:** `src/main.js:1-9` constructs `WildcubeGame`; `runtime.js:61-113` creates WebGL 2, compiles/links shaders, builds exposed faces, uploads interleaved position/color data, multiplies projection and view, and draws with depth/cull enabled. No static matrix-order or face-winding defect was found. Actual GPU compilation/rendering remains unverified.
- **Movement/collision:** `runtime.js:137-181` connects keys/mouse to normalized horizontal movement, axis-separated AABB collision, gravity and jump. The stale fall origin above is the located defect.
- **Break/place:** `runtime.js:188-202` raycasts to six-block reach, restores a broken block when inventory is full, rejects placement into non-air/player collision, removes inventory only after a valid placement, and rebuilds the mesh. No blocker/high/medium defect was found in this path.
- **Inventory/save:** `inventory.js:17-124`, `save.js:8-40`, and `runtime.js:203-207` form the nine-slot/stack/consume/localStorage path; save round-trip and malformed world runs are covered by passing tests. No blocker/high/medium defect was found.
- **HUD/audio/survival:** `runtime.js:155-160,182-185,203`, `survival.js:37-97`, `hud.js:181-322`, and `audio.js:24-149` connect life, hunger, clock, hotbar, night cold, starvation/healing and generated break/place/hurt audio. `step` audio exists but is not wired; this is a feature gap, not a failure of R4's minimum audio requirement.
- **Scope honesty:** `docs/agent/FINAL.md:13-22` explicitly lists absent Minecraft-scale systems and the unexecuted desktop test. The accepted scope does not claim those systems complete.

## R1–R5 assessment

- **R1:** implementation present; fall-damage defect located; pointer-lock behavior and desktop input remain unverified.
- **R2:** deterministic terrain/tree/ore logic passes; break/place path is statically coherent; desktop interaction remains unverified.
- **R3:** inventory, health, hunger, day/night and night-cold threat are integrated; fall-damage defect affects survival correctness.
- **R4:** save/load, pause/help, responsive HUD, shader visuals and procedural audio are integrated; help is incomplete and browser policy behavior remains unverified.
- **R5:** test/build/check pass and implemented/missing scope is documented; no real desktop play receipt exists.

## Dual-axis conclusion

- **Operability verdict: UNVERIFIED.** Node tests, production build, syntax, deterministic generation, and static rendering math passed. A real desktop WebGL 2 session with pointer lock, movement, break/place, save/load and audio was not executed; static review is not a substitute.
- **Requirement-satisfaction verdict: UNVERIFIED.** R1–R5 have substantive code paths and R3/R5 have strong logic/command evidence, but the precise top-level requirement is browser-playable and that real path lacks a successful receipt. One high and three medium findings should be addressed before claiming reliable completion.

## Recommended repair order

1. Reset fall origin correctly and add regression tests.
2. Gate simulation/menu transition on successful pointer lock with an error recovery path.
3. Complete the in-game help control list.
4. Add runtime/UI fakes, then perform a real desktop smoke play covering pointer lock, movement/collision, break/place, F/P/L, pause/resume, HUD/audio, and a night-cold interval.
