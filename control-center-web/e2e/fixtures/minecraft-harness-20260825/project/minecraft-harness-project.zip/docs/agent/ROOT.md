# Root WorkDocument 入口

当前 Root 权威文档由 WorkDocument registry 管理。请读取 `docs/agent/work/ACTIVE.json` 中 authorityKey 为 `session_goal:goal:10000000-0000-4000-8000-000000000001` 的条目，再读取其 `path`；不要把本导航文件当作动态状态副本。

项目文档导航见 [INDEX.md](INDEX.md)。
