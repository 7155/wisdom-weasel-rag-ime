# 架构

- `src/core/`：纯 ES module；方块目录、确定性有限体素世界、库存、生存推进和版本化 JSON 存档。
- `src/game/runtime.js`：零依赖 WebGL 2 合并网格渲染、着色器程序化颗粒、相机/指针锁、AABB 碰撞、体素射线采集/放置、昼夜和夜寒循环。
- `src/ui/`：DOM HUD/覆盖层和纯 Web Audio 生成音效。
- `src/main.js`：组合入口与启动错误边界。
- `scripts/`：Node 静态服务器与零依赖构建复制器。

世界是 32×24×32 的有限 dense voxel array。修改方块后重建可见面网格；该方案适合本轮小世界，不适合无限区块。
