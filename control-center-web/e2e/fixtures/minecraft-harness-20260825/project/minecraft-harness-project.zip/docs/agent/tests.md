# 测试证据

- `npm install --ignore-scripts --no-audit --no-fund`：通过（零依赖，1 秒）。
- `npm test`：10/10 通过；覆盖目录、确定性生成、编辑、九格库存、生存推进、存档往返、损坏存档拒绝、指针锁拒绝恢复、跌落伤害重置与零依赖浏览器入口 CSS 契约。
- `npm run build`：通过；生成 `dist/`。
- `node --check src/game/runtime.js`：通过。
- 后台 HTTP 验证：`GET http://127.0.0.1:4174/` 返回 200、`text/html` 且入口 `/src/main.js` 存在。
- UI 轨道 DOM/Web Audio 桩：伙伴证据为 `dom-path-ok`、`audio-path-ok`。

浏览器观察：真实 Chromium 首轮 DOM 为空，动态 import 诊断证明原因为原生浏览器不支持 JavaScript CSS import。修复后真实 Task Space smoke 通过：WebGL2、Pointer Lock、覆盖层隐藏、移动 1.33182、P/L 恢复误差 0、采集/放置库存 20→21→20、存档 12801 bytes；轨迹 `bcmd_8f2ba2dc52784b7fb1ef2019433bbb9a`。启动截图 `snap_e38066a62d014e558fdc487f7fe6aded`。
