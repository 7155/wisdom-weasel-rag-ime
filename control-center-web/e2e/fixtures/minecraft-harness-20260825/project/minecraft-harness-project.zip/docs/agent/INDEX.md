# 文档索引

- [Root 工作文档](ROOT.md)
- [已接受需求](requirements.md)
- [架构](architecture.md)
- [决定](decisions.md)
- [测试证据](tests.md)
- [验收矩阵](acceptance.md)
- [最终结果与缺口](FINAL.md)

活跃/归档 WorkDocument 的权威关系见 `docs/agent/work/ACTIVE.json` 与 `ARCHIVE.json`；Runtime 决定当前 owner 和终态。
