# 验收矩阵

| 需求 | 实现证据 | 状态 |
|---|---|---|
| R1 第一人称、跳跃、重力、碰撞、指针锁 | `src/game/runtime.js` | 真实浏览器 Pointer Lock 与移动 1.33182 通过；重力/碰撞有运行时测试与路径证据 |
| R2 程序化世界、破坏放置 | `src/core/world.js`、`src/game/runtime.js` | 真实浏览器采集/放置库存 20→21→20 通过 |
| R3 九格、生命饥饿、昼夜、威胁 | core + HUD；饥饿/跌落/无屋顶夜寒 | 逻辑与集成路径通过 |
| R4 存档、暂停帮助、HUD、原创音效/纹理 | save/UI/Web Audio/fragment shader | 真实浏览器 P/L 恢复误差 0、存档 12801 bytes；HUD/音频路径通过 |
| R5 安装启动、构建测试、缺口 | package/scripts/FINAL；10/10 测试 | 构建、测试与真实浏览器 smoke 通过 |
