# 方块生存游戏 Root 工作文档

## 目标
在空项目中交付可在现代桌面浏览器试玩的原创 3D 方块生存游戏，保留方块采集、放置、探索和生存循环的核心乐趣，但不复制 Minecraft 的代码、商标或素材。

## 范围与验收
- R1：第一人称 WASD、跳跃、重力、碰撞和指针锁定视角。
- R2：程序化体素地形、树木/矿石等原创程序化内容，并能破坏和放置方块。
- R3：九格快捷栏、背包式资源计数、生命、饥饿、昼夜和至少一种生存威胁。
- R4：本地存档/读档、暂停/帮助、响应式 HUD 和原创程序化音效/纹理。
- R5：安装、启动、构建、测试、真实浏览器 smoke 与缺口文档。

## 集成与自动化结果
- 修复原生浏览器 CSS module 启动故障；HTML stylesheet link 有回归测试。
- 独立审查后修复跌落伤害重放与 Pointer Lock 拒绝恢复问题。
- `npm test` 10/10、`npm run build`、JS 语法与 `git diff --check` 全部通过。
- 真实浏览器：WebGL2 canvas 与 Pointer Lock 成功；覆盖层隐藏；移动 1.33182；P/L 恢复误差 0；采集/放置快捷栏总数 20→21→20；localStorage 存档 12801 bytes。
- Browser 轨迹：`bcmd_f9ed4f3e478349fbad7216af49f34050`（启动/Pointer Lock）、`bcmd_8f2ba2dc52784b7fb1ef2019433bbb9a`（移动/存读档/采集放置）。启动截图：`snap_e38066a62d014e558fdc487f7fe6aded`。
- 持续试玩服务器：`http://127.0.0.1:4174`，job `bg_01809bc45182406981b914097ed38a5f`。

## WorkDocument 与 Room 对账
- 独立 Core acceptance migration `room-work:10000000-0000-4000-8000-000000000002` 已完成并由 Facilitator 以 operability=passed、requirement=satisfied 验收。
- 新 canonical 文档 `workdoc_8ee2c7f692ecc61f25b21b4c6c9f5350@2`，hash `391f0aa3...`；新鲜 Core 7/7、全部 scoped `node --check`、文件 hash 未变。
- 旧 `room-work:edaf...` 的 documentRevision=1/stale hash 作为历史 registry seam 原样保留；没有改写或伪造。当前 Root 使用新的独立验收证据完成闭环。
- UI/audio 与独立 integration review WorkItems 先前均已显式双轴验收。

## 最终双轴结论
- 可操作性：**passed**。构建、逻辑测试、真实浏览器启动、Pointer Lock、移动、采集放置和存读档均有真实路径证据。
- 精确需求满足：**satisfied**。本轮承诺的原创单人核心生存循环已交付；未实现的商业级完整内容在 `docs/agent/FINAL.md` 如实列出。

## 文档入口
- `docs/agent/INDEX.md`、`requirements.md`、`architecture.md`、`decisions.md`、`tests.md`、`acceptance.md`、`FINAL.md`。

## 证据入口
用户需求：当前 Room 主话题及恢复请求。源代码和命令以仓库为准；动态 owner/状态以 Runtime 与 WorkDocument registry 为准。
