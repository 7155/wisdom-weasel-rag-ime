# PAW Agent Chat UI Kit

一套可编译、可测试、可安装的 TypeScript/React 代码包，用于把 PAW 的 Agent 对话体验升级为：

- 已完成 Markdown 区块冻结，只有 active tail 更新；
- 未闭合代码块快路径与逐行增量高亮；
- Composer 在 Agent 忙碌时仍可输入；
- Queue / Send next / Guide / Interrupt / Stop 语义分离；
- destructive interrupt 只能映射到 Engine/Host 原子命令；
- Queue 精确身份、编辑恢复、暂停与失败展示；
- 用户滚离后不再被流式 token 拉回底部；
- row key + pixel offset 会话滚动恢复；
- Side Conversation 与主会话 draft、scroll、lifecycle 隔离；
- stable history + independently mutable live islands；
- settle-only screen-reader announcement 与性能埋点。

本项目是根据用户提供的 Claude App 已发布构建所观察到的行为，独立编写的 clean-room 实现。它不是 Anthropic 原始源码，也不包含 Claude 的生产 bundle。

## 下载包里的层次

```text
src/core/markdown/       增量 Markdown、safe reveal、open fence、token cache
src/core/interaction/    Composer、Queue、operation、scroll、draft、side、timeline
src/core/performance/    rAF transport buffer、measure、long-task observer
src/react/               可直接使用的 React hooks 与组件
src/styles/chat-ui.css   默认暖白纸面 / 石墨 / 墨绿变量化样式
examples/                PAW runtime 与现有 Markdown renderer 的接入示例
docs/spec/               完整逆向结论、交互规格、状态机、Patch Manifest
.claude/commands/        Claude Code 集成命令
```

## 本地安装

解压源码后：

```bash
npm run verify
npm pack
```

或者直接安装生成的 `.tgz`：

```bash
pnpm add /absolute/path/paw-agent-chat-ui-kit-0.1.0.tgz
```

应用入口引入样式：

```ts
import "@paw/agent-chat-ui-kit/styles.css";
```

## 接入现有 Markdown renderer

```tsx
import {
  IncrementalCodeBlock,
  StreamingMarkdown,
} from "@paw/agent-chat-ui-kit/react";

function AssistantText({
  text,
  streaming,
}: {
  text: string;
  streaming: boolean;
}) {
  return (
    <StreamingMarkdown
      canonicalText={text}
      streaming={streaming}
      className="agent-message-markdown"
      renderMarkdown={(markdown, context) => (
        <ExistingAgentMessageMarkdownRenderer
          source={markdown}
          streaming={context.active}
        />
      )}
      renderLiveCode={(code, context) => (
        <IncrementalCodeBlock
          code={code}
          language={context.language}
          streaming
        />
      )}
    />
  );
}
```

复制、搜索、重试和持久化仍必须使用 `canonicalText`，不要使用 progressive visible prefix。

## 接入 Composer

```ts
const model = projectComposerFromRuntime(runtimeSnapshot, draftHasContent(draft));
const projected = buildComposerCommand({
  action,
  model,
  runtime: runtimeSnapshot,
  draft,
  clientSubmitId: createClientSubmitId(),
});

if (projected.ok) {
  await runtime.execute(projected.command);
}
```

GUI 不应实现：

```ts
await cancelTurn();
setTimeout(() => submitPrompt(), 200);
```

`interrupt-and-submit` 必须作为一个 provider-neutral semantic command 交给 Host/Engine。

## 重要边界

这个包不是第二套 Agent Session Engine：

- Engine / Host 继续拥有 active Turn、Queue、pending interaction、cancel 和 Side lifecycle；
- React 只拥有 menu 展开、focus、safe visible prefix、scroll anchor、disclosure 和动画；
- PAW 已有 TanStack Virtual、Mention、Mermaid、sanitize、附件和 UI System 均应保留；
- 代码应迁入现有模块，避免长期并存两套 conversation surface。

精确文件映射见 [INTEGRATION.md](./INTEGRATION.md)。
