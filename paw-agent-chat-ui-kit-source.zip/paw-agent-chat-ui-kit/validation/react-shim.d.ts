declare module "react" {
  export type ReactNode = any;
  export type CSSProperties = Record<string, string | number | undefined>;
  export type DependencyList = readonly unknown[];
  export type RefObject<T> = { current: T };
  export type MutableRefObject<T> = { current: T };
  export type HTMLAttributes<T> = Record<string, any>;
  export type ButtonHTMLAttributes<T> = Record<string, any>;
  export const Fragment: any;
  export function memo<T>(component: T, compare?: (previous: any, next: any) => boolean): T;
  export function startTransition(callback: () => void): void;
  export function useCallback<T extends (...args: any[]) => any>(callback: T, deps: DependencyList): T;
  export function useDeferredValue<T>(value: T): T;
  export function useEffect(effect: () => void | (() => void), deps?: DependencyList): void;
  export function useId(): string;
  export function useLayoutEffect(effect: () => void | (() => void), deps?: DependencyList): void;
  export function useMemo<T>(factory: () => T, deps: DependencyList): T;
  export function useReducer<R extends (state: any, action: any) => any, I>(reducer: R, initialArg: I, initializer?: (arg: I) => ReturnType<R>): [ReturnType<R>, (action: Parameters<R>[1]) => void];
  export function useRef<T>(initialValue: T): MutableRefObject<T>;
  export function useState<T>(initialValue: T | (() => T)): [T, (value: T | ((previous: T) => T)) => void];
  export function useSyncExternalStore<T>(subscribe: (listener: () => void) => () => void, getSnapshot: () => T, getServerSnapshot?: () => T): T;
}

declare module "react/jsx-runtime" {
  export const Fragment: any;
  export function jsx(type: any, props: any, key?: any): any;
  export function jsxs(type: any, props: any, key?: any): any;
}

declare namespace JSX {
  interface IntrinsicAttributes { key?: any; }
  interface IntrinsicElements { [element: string]: any; }
}
