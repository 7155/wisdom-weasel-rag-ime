# 代码模块与产品行为映射

| 产品行为 | Pure core | React |
|---|---|---|
| stable Markdown blocks | `markdown/scanner.ts` | `StreamingMarkdown.tsx` |
| safe token reveal | `markdown/reveal.ts` | `useSafeVisibleText.ts` |
| open code fence fast path | `markdown/openFence.ts` | `StreamingMarkdown.tsx` |
| incremental highlight | `markdown/tokenizer.ts` | `IncrementalCodeBlock.tsx` |
| whole-doc settle semantics | `markdown/partition.ts` | `AstStreamingMarkdown.tsx` |
| send / queue / steer / interrupt | `interaction/composer.ts` | `ComposerActionBar.tsx`, `AgentComposer.tsx` |
| queue summary/actions | `interaction/queue.ts` | `QueuePanel.tsx` |
| canonical receipt state | `interaction/operation.ts` | `OperationReceipt.tsx` |
| pinned/detached transcript | `interaction/followEnd.ts` | `useTranscriptScrollController.ts` |
| row anchor restoration | `interaction/messageAnchor.ts` | `useTranscriptScrollController.ts` |
| main/side draft isolation | `interaction/draft.ts` | host integration |
| side context boundary | `interaction/sideChat.ts` | `SideConversationPane.tsx` |
| stable history identity | `interaction/timeline.ts` | existing Turn memo boundary |
| transport delta coalescing | `performance/rafBuffer.ts` | stream ingestion edge |
| settle-only accessibility | — | `SettledMessageAnnouncer.tsx` |
