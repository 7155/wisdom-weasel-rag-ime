# 00 · 基线、证据等级与硬边界

## 1. 两个基线

### 1.1 Claude App 构建

上传包包含完整 `ion-dist` 静态构建。可验证：

- 2,696 个文件；
- 2,350 个 JS 文件；
- 无 `.map`；
- 能定位模块、事件、React 结构、状态字段、调度策略和性能快路径；
- 不能恢复 Anthropic 原始目录、TSX 类型、注释、设计文档和真实符号名。

证据使用三级标记：

- **Confirmed**：在 bundle 中找到直接结构或字符串证据；
- **Strong inference**：多处调用关系共同支持，但没有原始类型/注释；
- **Proposal**：针对 PAW 的独立设计，不声称 Claude 如此实现。

### 1.2 PAW / Tutti 仓库

目标代码不是空白项目。AgentGUI 的硬边界是：

- Host：Session / Turn / Goal / runtime-operation 生命周期；
- `AgentSessionEngine`：canonical frontend entities、pending intents、queue 和 selectors；
- AgentGUI：投影、controller、view、DOM、焦点、滚动与临时 disclosure；
- transcript：历史展示，不是审批、问题、Turn 或可发送性的 authority。

## 2. 开工前必须读

Claude Code 必须按顺序读取：

1. `/AGENTS.md`
2. `/packages/AGENTS.md`
3. `/packages/agent/gui/AGENTS.md`
4. `/docs/architecture/agent-gui-node.md`
5. `/packages/agent/gui/REVIEW.md`
6. `/docs/conventions/testing.md`
7. 若改 lifecycle：`/packages/agent/host/README.md` 与 conformance 场景
8. 若改 UI primitive/token：`/packages/ui/AGENTS.md`

## 3. 生命周期决策规则

每项改动先回答：

> 是否改变 Session / Turn / Goal / runtime-operation 何时创建、何时可发送、何时终结、如何恢复？

- 是：先改 `packages/agent/host`，先写 conformance scenario；
- 否：可以是 activity-core、GUI 投影、adapter 或 presentation；
- 不确定：确认另一个 Host consumer 是否也需要；需要则归 Host。

### 典型归属

| 需求 | 归属 |
|---|---|
| Queue 按钮文案、折叠方式 | GUI |
| busy 时默认显示 Queue 还是 Send | GUI 投影 |
| prompt 排队顺序的 durable 规则 | Host / Engine |
| `send_now` 是否先取消当前 Turn | Host / Engine |
| scroll anchor、跳到底部、动画 | GUI |
| Side panel 宽度和 draft focus | GUI |
| Side 是否可观察主会话上下文 | Host Side contract |
| Edit/Retry 是否产生 lineage | Host / Engine |

## 4. 兼容要求

- provider-neutral：禁止 `if provider === "claude"`；
- identity exact：始终使用 workspace/session/turn/request/clientSubmit IDs；
- Windows 是默认合同；前端路径、快捷键和文件链接都要评估；
- 用户文案全部进入 i18n；中文文案不以中文句号结尾；
- 优先复用 `@tutti-os/ui-system`；禁止随手写原始颜色；
- 业务文件不超过仓库 800 行限制；
- 不引入 `shared/common/utils` 之类模糊包。

## 5. 法务与工程边界

Claude bundle 只用于理解外部可观察机制。新代码必须：

- 使用 PAW 现有命名、类型和层级；
- 由需求和测试重新实现；
- 不复制大段压缩源码、专有文案或样式；
- 在 PR 说明中写明 clean-room behavior reference；
- 不把上传 ZIP 或逆向片段提交到仓库。
