# 14 · Review Checklist

## Architecture

- [ ] 读完所有 required docs
- [ ] lifecycle owner判断写入PR
- [ ] GUI没有复制canonical state
- [ ] exact IDs，无latest-row/timestamp推断
- [ ] provider-neutral
- [ ] closed-surface test通过

## Renderer

- [ ] original whitespace保留
- [ ] non-append reset
- [ ] safe reveal有max holdback
- [ ] stable key不依赖不断增长全文
- [ ] open fence fallback安全
- [ ] sanitize/link/mention/media/Mermaid不退化
- [ ] copy/selection基于canonical text

## Scroll

- [ ] user intent优先
- [ ] virtual/non-virtual一致
- [ ] row anchor缺失有fallback
- [ ] ResizeObserver cleanup
- [ ] stale controller拒绝
- [ ] conversation identity切换安全

## Composer/Queue

- [ ] primary label等于实际semantic command
- [ ] destructive action不被普通shortcut触发
- [ ] draft snapshot恢复
- [ ] optimistic/canonical record关联用clientSubmitId
- [ ] image/attachment恢复
- [ ] paused queue不自动清空

## Side/Edit/Fork

- [ ] Side fail closed
- [ ] source session exact
- [ ] main与Side draft/scroll/focus隔离
- [ ] edit/retry exact turn
- [ ] fork lineage明确

## UI/A11y

- [ ] UI System tokens/primitives
- [ ] i18n
- [ ] 中文copy无中文句号结尾
- [ ] keyboard/focus
- [ ] reduced motion
- [ ] screen reader announcement节流
- [ ] Windows path/shortcut评估

## Validation

- [ ] characterisation tests
- [ ] focused tests
- [ ] performance fixture
- [ ] changed-aware check
- [ ] required boundary checks
- [ ] REVIEW lanes有证据
- [ ] docs impact/self-evolution notes
