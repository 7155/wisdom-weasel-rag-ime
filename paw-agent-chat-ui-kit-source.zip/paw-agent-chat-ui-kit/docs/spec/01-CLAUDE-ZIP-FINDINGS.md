# 01 · Claude ZIP 发现

## 1. 关键 bundle

构建 hash 会变，下面只用于本次样本定位：

| 文件 | 可观察职责 |
|---|---|
| `shared-10-Dndtc5mJ.js` | streaming Markdown、safe reveal、open fence、增量高亮 |
| `c3e2391e3-BQJuX05U.js` | 主消息 renderer 调用点 |
| `c360a9e1c-BhqEnXIC.js` | Composer、scroll/follow、virtual transcript、interrupt/steer |
| `cb63ed069-Bg_gHwhb.js` | queued message presentation |
| `cf8e2003d-0glxypSq.js` | edit/retry presentation |
| `c11959232-C6pCsmyv.js` | rewind、side conversation、queue 相关流程 |
| `ca2ef848d-yNH4UL1M.js` | conversation/history 相关投影 |
| `shared-8-D2-aSTzM.js` | composer/draft shared logic |

## 2. 流式渲染

### Confirmed：稳定前缀 + 活跃尾部

它保存已经闭合的 Markdown chunks，后续只更新最后一个 mutable tail。核心效果：

```text
stable block 0  ── memoized / frozen
stable block 1  ── memoized / frozen
stable block 2  ── memoized / frozen
active tail     ── streaming / mutable
```

### Confirmed：Markdown-aware boundary

扫描状态至少覆盖：

- fenced code；
- math block；
- list 与 blank continuation；
- table；
- blockquote；
- indented code；
- 上一空行与是否已有内容；
- 最后一条未完成物理行的 offset。

它不是按固定字符数或简单 `\n\n` 切块。

### Confirmed：safe reveal

可见文字不是毫无约束地按字符推进。边界会避开：

- 未闭合 inline code；
- Markdown link/image；
- emphasis marker；
- 只有 `-`、`##` 的未完成结构；
- surrogate pair；
- 短的未完成单词。

同时限制最大视觉 holdback，防止格式永远不闭合时长时间落后。

### Confirmed：未闭合 code fence 快路径

发现最后一个 fenced block 未闭合时，正常解析围栏前 Markdown；不断增长的 code body 走专门路径，而不是每次重跑整段 Markdown pipeline。

### Confirmed：增量 syntax tokenization

完整代码行缓存：

- 原行文本；
- tokens；
- 行后 grammar state；
- source offset。

更新从第一条变化行开始；当前未完成行走 cheap path；状态重新收敛后复用后续缓存。

### Confirmed：deferred settle 与全文最终 parse

流停止后不立即在最紧急更新中完成昂贵工作，而是先保留 streaming presentation，再做一次全文 parse，并按 source offset 把顶层节点分配回已有 chunk，保留完整文档语义。

## 3. Composer 与 Queue

### Confirmed

- Agent 工作时 Composer 仍可输入；
- 普通 follow-up 可进入 queue；
- queue 可折叠/展开；
- 队列项可以编辑、删除、提升/立即处理；
- “当前响应”与“后续消息”在 UI 上有可见区别；
- interrupt 是显式高风险动作，不和普通 Enter 混为一谈。

## 4. Scroll 与长会话

### Confirmed

- follow-end 与 detached 是不同模式；
- 用户主动向上滚后，新 token 不再抢滚动；
- 有返回底部控制；
- transcript 使用虚拟化；
- 动态高度、切换会话和恢复位置被单独处理。

## 5. Side conversation

### Confirmed

Side conversation：

- 能读取主对话上下文；
- 有独立消息、draft、发送和取消；
- 不把内容写回主 transcript；
- 关闭主 surface 时生命周期由明确 owner 管理，而不是一段临时 React 数组。

## 6. 对 PAW 最有价值的抽象

```text
append-only canonical timeline
        +
independently mutable live islands
        +
always-available composer
        +
explicit user intent routing
        +
scroll ownership belongs to user
```

借鉴的是这些原则，不是 Claude 的视觉壳。
