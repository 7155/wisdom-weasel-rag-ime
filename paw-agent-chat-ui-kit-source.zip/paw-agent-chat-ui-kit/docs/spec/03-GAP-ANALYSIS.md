# 03 · 差距分析与优先级

## 总体评分

| 能力 | 当前 | 目标 | 动作 |
|---|---:|---:|---|
| Canonical ownership | 9/10 | 10/10 | 保留，禁止 UI 复制 lifecycle |
| Composer busy usability | 8/10 | 10/10 | 统一动作与文案 |
| Queue capability | 8/10 | 10/10 | 精简 presentation，补 reorder 前置验证 |
| Streaming Markdown | 6/10 | 10/10 | append-aware scanner + safe reveal + code fast path |
| Transcript virtualization | 8/10 | 9/10 | 保留，优化 live isolation 与测量 |
| Scroll stability | 7/10 | 10/10 | row anchor + offset，明确用户 ownership |
| Side conversation | 8/10 | 9/10 | 打磨 shell、draft、状态和可见边界 |
| Edit/Retry/Fork | 8/10 | 9/10 | 统一 lineage presentation |
| Visual hierarchy | 6/10 | 9/10 | 减少卡片和内部术语 |
| Observability | 6/10 | 9/10 | renderer/scroll/intent 专项指标 |

## P0：必须先做

### P0-A 测量与回归基线

在不改变行为前增加：

- Markdown parse / render 次数；
- stable block render 次数；
- active tail 字符数；
- visible rows / total rows；
- scroll follow/detach transition；
- queue/normal/send-now/immediate routing；
- 50ms 以上 long tasks；
- first delta → first paint；
- final delta → settled render。

所有 telemetry 禁止包含 prompt/message 内容。

### P0-B append-aware Markdown scanner

替换 stateless full scan，但保留现有 normalization、links、mentions、Mermaid 和 sanitize。

### P0-C row anchor scroll memory

兼容旧 geometry fallback；新增 stable row key + intra-row offset。

### P0-D Intent presentation model

只做纯函数投影，不改 lifecycle。Composer、send button、menu、Queue panel 和 receipt 共同消费一个 model。

## P1：体验闭环

- adaptive safe reveal；
- open fence code fast path；
- active tail / stable blocks memo contract；
- detached 时显示“有新内容”与数量；
- queue summary 改为一行 next-item preview；
- explicit “Interrupt and send” action；
- `Stop` 后 queue paused 的可见解释与 resume/send-next 路径；
- Side pane 轻量化；
- Edit/Retry/Fork lineage 文案统一。

## P2：高级性能与细节

- settled whole-document AST pass + source-offset partition；
- incremental syntax highlighting；
- dynamic estimated turn size；
- row-level external store selectors；
- drag reorder（仅在 Engine 有 canonical move command 时）；
- 120Hz 设备专项 benchmark；
- reduced motion / screen reader live-region 细化。

## 不应在第一轮做

- 换整套 Markdown 库；
- 自建新 virtualizer；
- 改 Side Host 生命周期；
- 重写 queue engine；
- 把所有 Tool event 变成节点图；
- 增加大量永久可见状态 badge；
- 因为 Claude 有某功能就扩大 PAW scope。
