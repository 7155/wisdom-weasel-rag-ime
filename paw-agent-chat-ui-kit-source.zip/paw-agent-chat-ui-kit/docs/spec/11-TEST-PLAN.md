# 11 · 测试计划

## 1. Characterisation tests先行

在改代码前锁定：

- busy composer可编辑；
- busy submit进入queue；
- pending approval/question时follow-up可queue；
- edit queue恢复structured draft与图片；
- send next exact prompt；
- stop后queue paused；
- detached不跟底；
- submit prompt回底；
- switch conversation恢复follow mode；
- Side `/side` fail closed；
- Edit/Retry失败保留draft。

## 2. Markdown pure tests

### Scanner

- paragraph boundaries；
- heading + blank；
- unordered/ordered list continuation；
- list blank continuation；
- table；
- blockquote；
- fenced code与更长closing fence；
- indented code；
- `$$` math；
-最后未完成物理行；
- CRLF normalization；
- append-only不重扫stable prefix；
- edit/regeneration reset；
- empty/whitespace-only；
- 100k字符随机增量差分测试。

### Safe reveal

- inline code；
- link/image；
- emphasis/strike；
- bare list/heading marker；
- CJK；
- emoji surrogate；
- malformed 2k字符结构且holdback≤600；
- hidden document flush；
- settle immediate full reveal。

### Open fence

- backtick/tilde；
- opener length；
- invalid shorter closer；
- info string；
- frontmatter回退；
- partial最后一行。

## 3. React renderer tests

- stable chunk component render count；
- active tail only changes；
- non-append reset正确 remount；
- callback identity不导致streaming stable chunks更新；
- settle时全文语义正确；
- copy使用canonical content；
- Mermaid只在settled；
- reduced motion；
- screen reader不逐token announce。

## 4. Scroll tests

### Non-virtual

- following append；
- wheel/touch/pointer detach；
- row above anchor高度增加；
- bottom dock resize；
- history prepend；
- conversation switch；
- anchor row missing fallback；
- new updates count。

### Virtual

- stable turn key restore；
- virtual controller stale identity拒绝；
- dynamic measure；
- scrollToEnd只在following；
- disclosure animation；
- locate unmounted row；
- 500 Turn DOM count。

## 5. Composer/Queue tests

表驱动覆盖：

| busy | pending interaction | hard block | draft | expected primary |
|---|---|---|---|---|
| no | no | no | nonempty | send |
| yes | no | no | nonempty | queue |
| yes | yes | no | nonempty | queue |
| no | yes | no | nonempty | queue |
| any | any | yes | any | blocked |
| stopping | any | no | nonempty | blocked/settling |

动作：

- default Enter；
- Shift+Enter；
- send next；
- remove；
- edit；
- optimistic record reconcile；
- accepted/queued clear；
- rejected restore；
- duplicate click幂等；
- exact session切换竞态；
- interrupt outcome unknown。

## 6. Side / Edit / Fork

- Side open exact source session；
-已有Side同source复用；
- 不同source不串线；
- unsupported `/side`不泄漏到main；
- side busy initial prompt进Side draft；
- close/cancel/respond failures；
- edit retry eligibility与exact turn；
- recovery action availability；
- fork pending按turn隔离。

## 7. 性能测试

至少保留脚本/fixture，不能只人工看：

- 100k Markdown streaming；
- 2k code lines；
- 500 Turn virtual transcript；
- 1k tool updates；
- React Profiler render counts；
- long task observer；
- memory snapshot前后。

## 8. 仓库验证

Claude Code必须依据 `docs/conventions/testing.md#validation-selection` 选择，不要机械跑全仓。通常包括：

- affected focused tests；
- `pnpm check:changed`；
- provider strategy/capability contract改变时额外 `pnpm check:agent-provider-strategy-boundaries`；
- Host lifecycle改变时 conformance；
- Windows impact assessment；
- docs impact check；
- REVIEW lanes逐项报告。

若环境无法执行，必须写出精确命令、失败原因和未验证风险。
