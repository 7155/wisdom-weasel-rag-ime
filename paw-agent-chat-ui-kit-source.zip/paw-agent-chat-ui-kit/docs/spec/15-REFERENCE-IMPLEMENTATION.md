# 15 · 参考实现说明

`reference/` 不是要在 PAW 中并行保留的新框架，而是一组可测试的 clean-room 算法样本。

## Core

### `incrementalMarkdownDocument.ts`

提供：

- `createStreamingMarkdownDocumentState()`
- `scanAppendedMarkdown()`
- `advanceStreamingMarkdownDocument()`
- `projectStreamingMarkdownChunks()`

迁移目标：演进现有 `splitStreamingMarkdownBlocks()`，保留当前 public helpers 与 tests，最终让 `AgentMessageMarkdown` 使用 stable chunks + active tail。

### `safeStreamingReveal.ts`

提供：

- `findSafeMarkdownRevealOffset()`
- `markdownRevealCeiling()`
- `advanceMarkdownReveal()`

迁移目标：演进 `useStreamingVisibleText.ts` 的 pure advance helper。React hook只负责调度，安全边界逻辑必须可独立测试。

### `openFenceTail.ts`

识别最后一个未闭合 code fence。PAW接入时必须继续尊重 Mermaid、frontmatter、sanitize 和当前 code renderer能力。

### `composerActionModel.ts`

只做 presentation projection，不直接 dispatch。实际 PAW model应复用 `AgentGUIComposerGate` 类型并读取 provider-neutral capabilities。

### `messageAnchor.ts`

展示 stable row key + offset 算法。生产代码应接入已有 `AgentGUIConversationScrollMemory` 和 `AgentTranscriptVirtualScrollController`，不要新增第二个 scroll owner。

### `queuePresentation.ts`

只归一化 collapsed/paused/draining presentation，不包含文案。文案由 i18n 提供。

### `liveTimelineProjection.ts`

展示稳定 Turn revision 的原则。生产 revision应使用已有 canonical version/identity，不要真的把大量数组 join 作为热路径。

## React adapters

`reference/react/` 只说明接法：

- safe reveal scheduling；
- stable Markdown chunk memo；
- open fence live code；
- anchor memory；
- action model统一消费。

必须迁入现有组件，而不是创建 `StreamingMarkdownBlocks` 和现有 `AgentMessageMarkdown` 并存的永久双栈。

## 已知简化

- reference scanner不是完整 CommonMark parser；它只找安全冻结边界；
- table识别较保守；
- safe reveal不涵盖PAW所有自定义 directive；接入时要加入现有 mention/object-token语法；
- code tokenizer没有绑定实际 highlighter；
- settled whole-document HAST partition未在reference中强行实现，因为必须先确认PAW parser/source position契约；
- React adapters使用通用props，不引用PAW私有类型。

这些简化是为了让迁移过程由仓库 tests和现有 contracts驱动，而不是假装外部样本可直接替代生产代码。
