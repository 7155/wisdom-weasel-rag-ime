# Claude Code Master Prompt · PAW Agent Chat UI & Interaction Optimization

你现在在 `7155/paw-os` 仓库中工作。你的任务不是复制 Claude UI，而是根据一份 Claude Desktop 生产构建的可观察机制，**对 PAW 当前 AgentGUI 做仓库原生、provider-neutral、可测试、可回滚的聊天 UI 与交互优化**。

必须实际修改代码并运行验证；不要只写方案。任务很大时按下面阶段连续推进，不要停在“建议”。工作区已有修改必须保留，禁止覆盖或重置用户改动。

---

## 0. 输入与基线

外部参考 ZIP：

```text
c679f1d1-081c-4c40-b1f8-6046cb0f1753.zip
SHA-256 d3ef57aad1acd7aa399b758fa2acc40cf46531e136da9499589be50a0a3d045a
```

它包含 Claude Desktop `ion-dist` 已发布 bundle，无 sourcemap。它只用于确认外部可观察行为，不允许直接复制压缩代码到仓库，也不允许声称恢复了 Anthropic 原始 TSX。

本任务包包含：

```text
README.md
docs/00-BASELINE-AND-RULES.md
docs/01-CLAUDE-ZIP-FINDINGS.md
docs/02-PAW-CURRENT-STATE.md
docs/03-GAP-ANALYSIS.md
docs/04-TARGET-ARCHITECTURE.md
docs/05-INTERACTION-SPEC.md
docs/06-STATE-MACHINES.md
docs/07-VISUAL-AND-MOTION-SPEC.md
docs/08-PERFORMANCE-PLAN.md
docs/09-IMPLEMENTATION-PLAN.md
docs/10-PATCH-MANIFEST.md
docs/11-TEST-PLAN.md
docs/12-ACCEPTANCE-CRITERIA.md
docs/13-TELEMETRY-AND-DIAGNOSTICS.md
docs/14-REVIEW-CHECKLIST.md
reference/
tests/
```

先完整读取这些文件，再开始改仓库。

---

## 1. 开工纪律

### 1.1 先记录现场

执行并保存输出：

```bash
git status --short
git rev-parse HEAD
git branch --show-current
git diff --stat
git diff -- packages/agent/gui packages/agent/activity-core packages/agent/host
```

若有用户已有修改：

- 不 reset；
- 不 checkout 覆盖；
- 不用 `--ours/--theirs`；
- 先理解已有意图；
- 让本任务 patch 与它们兼容；
- 最终报告列出哪些修改原先已存在。

### 1.2 按顺序读仓库规则

必须读：

```text
AGENTS.md
packages/AGENTS.md
packages/agent/gui/AGENTS.md
docs/architecture/agent-gui-node.md
packages/agent/gui/REVIEW.md
docs/conventions/testing.md
CONTRIBUTING.md
```

若任何改动改变 Session / Turn / Goal / operation 生命周期，再读：

```text
packages/agent/host/README.md
packages/agent/host/conformance/**
```

若扩展 UI System，再读：

```text
packages/ui/AGENTS.md
```

### 1.3 先审计当前实现，不得从零重写

至少阅读：

```text
packages/agent/gui/shared/AgentMessageMarkdown.tsx
packages/agent/gui/shared/agentMessageMarkdownRuntime.ts
packages/agent/gui/shared/useStreamingVisibleText.ts
packages/agent/gui/shared/streamingMarkdownTailStabilizer.ts
packages/agent/gui/shared/cachedMarkdownParser.ts

packages/agent/gui/shared/agentConversation/components/AgentTranscriptView.tsx
packages/agent/gui/shared/agentConversation/components/useAgentTranscriptVirtualizer.ts
packages/agent/gui/shared/agentConversation/agentConversationFollowEndController.ts

packages/agent/gui/agent-gui/agentGuiNode/view/useAgentGUIDetailScroll.ts
packages/agent/gui/agent-gui/agentGuiNode/view/agentGUIScrollMemory.ts
packages/agent/gui/agent-gui/agentGuiNode/view/agentGUIDetailScrollHelpers.ts
packages/agent/gui/agent-gui/agentGuiNode/view/AgentGUIConversationTimelinePane.tsx

packages/agent/gui/agent-gui/agentGuiNode/model/agentGuiComposerGate.ts
packages/agent/gui/agent-gui/agentGuiNode/composer/AgentComposer.types.ts
packages/agent/gui/agent-gui/agentGuiNode/composer/AgentComposerChrome.tsx
packages/agent/gui/agent-gui/agentGuiNode/composer/AgentComposerView.tsx
packages/agent/gui/agent-gui/agentGuiNode/composer/ComposerFooter.tsx
packages/agent/gui/agent-gui/agentGuiNode/AgentComposer.tsx
packages/agent/gui/agent-gui/agentGuiNode/AgentQueuedPromptPanel.tsx
packages/agent/gui/agent-gui/agentGuiNode/controller/useAgentGUIQueueActions.ts
packages/agent/gui/agent-gui/agentGuiNode/controller/useAgentGUISubmitInteractionActions.ts
packages/agent/gui/agent-gui/agentGuiNode/controller/agentGuiQueueStatus.ts

packages/agent/gui/agent-gui/agentGuiNode/view/useAgentGUIDetailSideConversation.ts
packages/agent/gui/agent-gui/agentGuiNode/view/AgentGUISideConversationPane.tsx
packages/agent/gui/agent-gui/agentGuiNode/controller/useAgentGUIEditRetryController.ts
```

确认实际文件名和代码后再决定 patch。任务包里的路径是审计基线，不是替代现场事实。

---

## 2. 不可违反的架构原则

1. `AgentGUIRuntime` 是生产活动数据和命令入口。
2. Session / Turn / Interaction / Goal / operation 是 canonical facts。
3. Transcript row 和 React state 不得成为 lifecycle authority。
4. queue/order/suspend/submit settlement 继续由 `AgentSessionEngine` 拥有。
5. GUI 只拥有 DOM、focus、scroll、临时 disclosure、动画和 presentation projection。
6. exact IDs：workspace/session/turn/request/clientSubmit/target；禁止按标题、时间、数组位置或 latest row 推断。
7. provider-neutral；禁止通过 Claude/Codex/Cursor 名称选择行为。
8. 所有用户文案走 i18n；中文 copy 不以中文句号结尾。
9. 先复用 `@tutti-os/ui-system`；禁止随手写 raw colors 或重复 primitive。
10. 保留 Windows 行为与本地/Windows path Markdown 支持。
11. 不引入第二套 transcript store、queue store 或 Side state machine。
12. 业务文件保持 ≤800 行；拆 pure model/controller，不往 React component 塞 orchestration。
13. 不把外部 ZIP、反编译代码或 Anthropic 文案提交到仓库。

---

## 3. 最终产品行为

### 3.1 Composer 永远是入口

除 hard block 外，Agent 正在工作时 Composer 仍可编辑。

- idle：Enter = Send；
- busy：Enter = Add to queue；
- pending approval/question：交互控件优先，但普通输入仍可 queue；
- stopping/outcome unknown：可继续编辑，submission 暂时 blocked，draft 不丢；
- Shift+Enter 换行；
- destructive interrupt 绝不能绑定普通 Enter；
-按钮文案、tooltip、shortcut 和实际 Engine routing 必须完全一致。

### 3.2 Queue

保留 Engine-owned queue。展示改成：

```text
3 queued · Next: <one-line preview>                         ›
```

展开后显示每条内容、附件、Send next、Edit、Remove。已有图片恢复与 optimistic/canonical reconciliation 保留。

- Stop 后若 `suspendReason=user_stop`，明确显示 Queue paused；
- 不自动清空 queue；
- Edit 恢复 exact structured draft 并回焦 Composer；
- Reorder 仅当 activity-core/Host 已有 canonical move command；否则不要伪造本地顺序。

### 3.3 Queue / Guide / Interrupt 分离

用户必须能理解：

- Queue：不改变当前 Turn；
- Guide current turn：只有现有 `routing: immediate` 的 contract 明确支持“不中断 guidance”时才展示；
- Interrupt and send：只有 Engine/Host 提供 exact、可恢复、幂等语义时才展示。

先追踪 `submitPrompt`、`routing: immediate`、`routing: send_now`、cancel 和 queue drain 的完整链路。若语义不满足，暂停 GUI 猜测，先在 Host/Engine 加 contract + conformance。

### 3.4 Scroll ownership

- following：append/resize 自动跟底；
- user scroll away：detached；新 token 绝不拉回；
- detached 显示 `N new updates`；
- jump-to-latest 或用户提交 prompt 后回 following；
- conversation switching 使用 stable row key + intra-row offset 恢复；
- row 不存在才回退 `scrollTop`；
- virtual/non-virtual一致；
- history prepend、图片加载、Mermaid、tool disclosure 不得造成跳动。

### 3.5 Transcript

保留 TanStack Virtual 和 Turn grouping。优化目标：

```text
stable historical turns        memoized/frozen
active assistant text          live island
active tool progress           live island
pending interaction            live island
composer/queue/side state       must not rerender history
```

不要把整个 conversation 变成一个不断变化的巨型 props 对象。用纯 projection 和 stable revisions让历史 Turn 的 comparator真正命中。

### 3.6 Streaming Markdown

保留当前 ReactMarkdown、sanitize、links、mentions、media、local/Windows path、Mermaid 和 renderer components。

把性能内核升级为：

```text
canonical text
  -> safe rAF reveal
  -> append-aware Markdown boundary scanner
  -> stable completed chunks + one active tail
  -> open fenced code fast path
  -> memoized chunk rendering
  -> deferred final whole-document settle
```

具体要求：

- scanner 保存最后未完成行 offset；append只扫后缀；
- code/math/list/table/blockquote/indented code aware；
- non-append edit/regeneration reset；
- stable chunk ID是sequence/offset identity，不是不断增长全文；
- safe reveal避开半截 inline code/link/emphasis/list/heading/surrogate；
- holdback最多600字符；
- hidden document追到ceiling；
-未闭合code fence不反复高亮整个代码块；
- active partial line cheap；
- settle后恢复完整GFM/插件语义；
- copy/selection使用canonical full text；
- screen reader不逐token播报。

### 3.7 Side

保持当前 Host-backed Side architecture，不改为本地假聊天：

- 主上下文只读；
- 不写main transcript；
-独立draft/focus/scroll；
- exact source session；
- `/side` unsupported时fail closed；
- pending interaction只在Side内处理；
- visible shell说明隔离边界。

### 3.8 Edit / Retry / Fork

保留 Engine dispatch和recovery。只统一 presentation：

- Retry from here；
- branch/fork明确创建新lineage，不是假回滚；
- outcome unknown保留draft并展示recovery；
- exact turn eligibility；
- pending只禁用相同操作，不锁死整个Composer。

---

## 4. 实施顺序

按以下阶段工作。每阶段先加/更新 focused tests，再实现。能连续完成就连续完成；不要只交付 Phase 0。

### Phase 0 — Characterisation & metrics

- 锁定当前 gate、queue、scroll、Side、Edit/Retry 行为；
- 添加不含正文的性能 counters/marks；
- 建立 100k Markdown、2k code lines、500 Turn、1k tool updates fixtures；
- 输出 baseline 数字。

### Phase 1 — Incremental Markdown

新增建议文件（可按现场调整命名）：

```text
packages/agent/gui/shared/streamingMarkdownDocument.ts
packages/agent/gui/shared/streamingMarkdownSafeReveal.ts
packages/agent/gui/shared/streamingMarkdownOpenFence.ts
```

修改：

```text
AgentMessageMarkdown.tsx
agentMessageMarkdownRuntime.ts
useStreamingVisibleText.ts
streamingMarkdownTailStabilizer.ts
cachedMarkdownParser.ts
```

要求：旧 link/mention/media/sanitize tests 全通过。

### Phase 2 — Code tail and final settle

- open fence fast path；
- incremental complete-line token cache，若当前 highlighter支持 grammar state；
-否则先实现 plain live tail + final highlight，不引入不可靠 tokenizer；
- feasibility评估whole-document AST partition；有稳定source offsets才做。

### Phase 3 — Scroll anchor & render isolation

- `agentGUIScrollMemory.ts` 增加 row anchor；
- virtual controller增加 locate/capture/restore能力；
- detached unseen count；
- ResizeObserver/follow-end rAF合并；
- React Profiler修复历史 Turn无关render。

### Phase 4 — Composer intent model

新增纯函数：

```text
agentGuiComposerActionModel.ts
```

所有 Composer chrome/view/footer消费同一模型。不要在各组件分别推断 busy、queue、stop。

### Phase 5 — Queue presentation

- compact summary；
- expanded actions；
- paused explanation；
- focus restore；
- canonical receipts；
- keyboard/a11y。

### Phase 6 — Side / Edit / Fork polish

不改 lifecycle，只完成交互闭环、视觉层级、error/recovery 和隔离说明。

### Phase 7 — Cleanup / docs / validation

- 删除被新内核替代的重复路径；
- architecture/troubleshooting docs；
- i18n；
- REVIEW lanes；
- Windows assessment；
- focused + changed-aware validation；
- 前后性能报告。

---

## 5. 测试要求

完整测试矩阵见 `docs/11-TEST-PLAN.md`。最低不可省：

1. Markdown scanner每类block与non-append reset；
2. safe reveal link/code/emphasis/emoji/600-char cap；
3. stable chunk render count；
4. long open code fence；
5. scroll following/detached/anchor/resize/prepend/switch；
6. virtual/non-virtual parity；
7. Composer action table；
8. Queue exact IDs、draft image restore、send next、paused；
9. submit accepted/queued/rejected/outcome unknown；
10. Side exact source/fail closed；
11. Edit/Retry exact Turn/recovery；
12. 100k Markdown和500 Turn performance fixtures。

按照仓库 Validation Selection 执行。不要因为是 UI 就错误套用“presentation-only不跑检查”：本任务改变行为与逻辑，不属于该例外。

若改 provider strategy/capability contract，额外运行：

```bash
pnpm check:agent-provider-strategy-boundaries
```

若改 Host lifecycle，运行相关 conformance。最后至少尝试：

```bash
pnpm check:changed
```

不能运行的命令如实报告，不得写“应该通过”。

---

## 6. 性能验收

以实际测量为准，目标：

- stable Markdown chunk稳定后不再render；
- active tail parse 95p <4ms；
- React commit 95p <8ms；
- streaming期间无>50ms long task；
- first delta→paint 95p <100ms；
- final delta→settled 95p <250ms；
- detached append scroll drift ≤1px；
- row anchor restore ≤2px；
- 500 Turn DOM只保留visible + overscan；
- active tool/Side更新不重渲染历史main turns。

若目标环境无法稳定达到，保留测量结果并说明瓶颈，不要伪造数据。

---

## 7. 视觉与无障碍

- 使用当前 UI System semantic tokens；
- 内容列优先，不给每条assistant回复套厚卡片；
- Queue collapsed为一行；
- pending interaction在bottom dock优先；
- tool/thinking渐进披露；
- 120–200ms轻动效；auto-follow使用instant，不连续smooth；
- reduced motion；
- Queue `aria-expanded`；
- reorder必须有keyboard替代；
- focus不因streaming/virtual mount丢失；
- screen reader不逐token宣读。

---

## 8. 提交纪律

建议小提交：

```text
chore(agent-gui): add chat interaction performance baselines
perf(agent-gui): incrementally render streaming markdown blocks
perf(agent-gui): isolate live code tails during streaming
fix(agent-gui): preserve transcript position by stable row anchor
refactor(agent-gui): unify composer submit intent presentation
feat(agent-gui): clarify queued follow-up controls
feat(agent-gui): refine side and conversation lineage interactions
refactor(agent-gui): finalize conversation interaction architecture
```

遵循仓库 Conventional Commits/DCO。除非用户要求，不自动 push。不要把无关格式化混入提交。

---

## 9. 最终输出格式

完成后按以下顺序报告：

1. **Outcome**：用户现在感受到什么变化；
2. **Architecture**：哪些 canonical owner保持不变；
3. **Files changed**：按阶段分组；
4. **Interaction semantics**：Send / Queue / Send next / Guide / Interrupt / Stop；
5. **Renderer**：scanner、safe reveal、open fence、settle；
6. **Scroll**：following/detached/anchor；
7. **Side / Edit / Fork**；
8. **Performance before/after**：真实数字；
9. **Tests and commands**：逐条 PASS/FAIL/未运行；
10. **REVIEW lanes and Windows assessment**；
11. **Docs changed**；
12. **Known risks / deferred items**：只列确实未完成的；
13. **Diff summary / commits**。

不要只说“完成优化”。给出证据。
