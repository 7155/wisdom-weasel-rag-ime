# 06 · 状态机

## 1. Composer presentation

```mermaid
stateDiagram-v2
  [*] --> HardBlocked: collaborator/runtime/non-retryable
  [*] --> Idle: active session + no active work
  [*] --> Busy: active turn or pending work
  [*] --> Interaction: approval/question pending
  [*] --> Settling: submit/cancel outcome unresolved

  Idle --> Busy: prompt accepted
  Busy --> Busy: follow-up queued
  Busy --> Settling: interrupt requested
  Interaction --> Busy: interaction resolved
  Settling --> Busy: operation accepted
  Settling --> Idle: operation terminal + no active work
  Settling --> HardBlocked: non-retryable failure
```

Projection rules：

| State | Editor | Primary |
|---|---|---|
| HardBlocked | blocked | disabled |
| Idle | editable | send |
| Busy | editable | queue |
| Interaction | editable | queue；interaction controls separate |
| Settling | editable | temporarily blocked |

## 2. Queue record presentation

```mermaid
stateDiagram-v2
  [*] --> Optimistic
  Optimistic --> Queued: canonical record reconciled
  Optimistic --> Failed: submit rejected
  Queued --> Draining: send next / engine drain
  Queued --> Editing: edit selected
  Queued --> Removed: remove
  Draining --> Consumed: next turn accepted
  Draining --> Queued: retryable failure
  Editing --> Removed: draft restored
  Failed --> Queued: retry
  Failed --> Removed: dismiss
```

`Optimistic` 由 `clientSubmitId` 关联，不能靠文本去重。

## 3. Guidance / Interrupt operation

```mermaid
stateDiagram-v2
  [*] --> Requested
  Requested --> Accepted
  Requested --> Rejected
  Accepted --> Applying
  Applying --> Applied
  Applying --> OutcomeUnknown
  Applying --> Failed
  OutcomeUnknown --> Applied: reconciliation
  OutcomeUnknown --> Failed: recovery
```

不得只用 UI timer 把 Requested 变成 Applied。

## 4. Follow-end

```mermaid
stateDiagram-v2
  [*] --> Following
  Following --> Detached: wheel/touch/pointer/keyboard away
  Detached --> Detached: append or resize; preserve row anchor
  Detached --> Following: jump-to-latest
  Detached --> Following: user submits prompt
  Following --> Following: append/resize; scroll end
  Following --> Detached: restore remembered detached conversation
```

## 5. Streaming document

```mermaid
stateDiagram-v2
  [*] --> Empty
  Empty --> Streaming: first delta
  Streaming --> Streaming: append suffix
  Streaming --> Resetting: source no longer extends previous
  Resetting --> Streaming: rebuild scanner
  Streaming --> Settling: stream ends
  Settling --> Settled: final full parse/partition
  Settled --> Resetting: edit/retry/regeneration
```

## 6. Side conversation

沿用 Host canonical state，不在 GUI 自创：

```text
closed → opening → idle ↔ running → closing → closed
                     ↘ pending interaction
                     ↘ error/recovery
```

GUI local only：pane visible、focus、draft、scroll、disclosure。
