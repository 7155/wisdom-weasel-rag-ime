# 04 · 目标架构

## 1. 最终结构

```text
AgentGUIRuntime / AgentSessionEngine
             │
             ├── canonical session / turn / interaction / queue
             │
             ▼
Conversation projection layer
  ├── stable turn identities
  ├── immutable historical rows
  ├── active live islands
  ├── composer action model
  └── scroll anchor model
             │
             ▼
Agent Conversation Surface
  ├── Virtualized Transcript
  │    ├── Stable Turn Group 0
  │    ├── Stable Turn Group 1
  │    ├── Active Turn Live Island
  │    │    ├── Streaming Markdown Tail
  │    │    ├── Active Tool Progress
  │    │    └── Pending Interaction
  │    └── New Activity Below control
  ├── Side Conversation Pane
  └── Bottom Dock
       ├── Prompt / Approval / Question
       ├── Queue Summary
       └── Always-available Composer
```

## 2. 一条事实一个 owner

### Engine / Host facts

- current active Turn；
- queue records/order/suspend reason；
- submit settlement；
- pending approval/question；
- cancel state；
- Side lifecycle；
- edit/retry/fork lineage。

### GUI-local facts

- queue panel expanded；
- menu open；
- composer focus；
- follow-end or detached presentation；
- stable row anchor；
- disclosure expansion；
- animation state；
- selected text；
- locally visible streaming prefix。

GUI-local state不得反向定义 canonical lifecycle。

## 3. Timeline：stable history + live islands

不要把 `conversation` 当一个巨大 mutable object。在现有 VM 边界内至少建立如下 render contract：

```ts
type TimelineRenderItem =
  | {
      key: string;
      kind: "stable-turn";
      revision: string;
      turn: StableTurnProjection;
    }
  | {
      key: string;
      kind: "active-turn";
      revision: string;
      turn: ActiveTurnProjection;
    };
```

稳定 Turn 的 `revision` 只有 canonical 内容改变才变化。以下变化不得使历史 Turn 重渲染：

- active text delta；
- tool progress；
- composer draft；
- queue expand；
- bottom dock height；
- Side draft；
- scroll position。

## 4. Markdown pipeline

```text
canonical message text
       │
       ▼
normalization preserving original whitespace
       │
       ▼
safe reveal scheduler
       │
       ▼
append-aware scanner
       │
       ├── completed chunks (stable IDs)
       └── active tail
              │
              ├── open fence → code fast path
              └── normal tail parse
       │
       ▼
existing link/mention/media/sanitize renderers
       │
       ▼
settle → optional full-document parse/partition
```

### Scanner state必须独立于 React render

```ts
interface StreamingMarkdownDocumentState {
  sourceText: string;
  committedOffset: number;
  nextChunkId: number;
  chunks: readonly StableMarkdownChunk[];
  cursor: MarkdownScanCursor;
}
```

append 情况只扫 `cursor.offset` 后内容；edit/regeneration 检测前缀不匹配后 reset。

## 5. Composer action model

所有按钮和快捷键消费一个纯投影：

```ts
interface ComposerActionModel {
  editor: "editable" | "blocked";
  primary: "send" | "queue" | "answer" | "approve" | "stop";
  secondary: readonly (
    | "send-next"
    | "guide-current-turn"
    | "interrupt-and-send"
    | "stop"
  )[];
  destructive: readonly ("interrupt-and-send" | "stop-and-clear-queue")[];
  reason: string | null;
}
```

它读取 gate、active Turn、pending Interaction、queue 和 draft presence；不读取 provider name。

## 6. Semantic command mapping

Claude Code 必须追踪 activity-core 当前定义后再落地：

| UI intent | 优先使用现有语义 |
|---|---|
| idle send | normal submit |
| busy follow-up | queue |
| send queued item next | `queue/sendNowRequested` |
| guide current turn | 只有 `routing: immediate` 明确定义为该语义时才使用 |
| interrupt and send | 只有 Engine/Host 有原子或可恢复 command 时才开放 |
| stop current turn | exact active `turnId` cancel |

若发现 `immediate` 或 `send_now` 语义与 UI 文案不匹配，先修 contract / conformance，不得在 GUI 猜。

## 7. Scroll ownership

```text
following
  ├─ append / resize → follow end
  └─ user scroll away → detached

detached
  ├─ append → preserve anchor; increment unseen count
  ├─ conversation switch → persist anchor
  ├─ row size change → restore row anchor
  └─ jump-to-latest / prompt submitted → following
```

Anchor：

```ts
interface TimelineMessageAnchor {
  conversationId: string;
  rowKey: string;
  offsetFromViewportTopPx: number;
  fallbackScrollTop: number;
  capturedAtLayoutRevision: number;
}
```

## 8. Side boundary

Side 保持当前 Host-backed architecture。UI 只优化：

- 显示“读取主对话上下文，但不写入主对话”；
- 独立 draft、focus、scroll 和 queue/idle state；
- source session 变化时明确关闭或重开；
- pending interaction 只在 Side pane 内响应；
- 主 Composer `/side` fail closed 逻辑保持。
