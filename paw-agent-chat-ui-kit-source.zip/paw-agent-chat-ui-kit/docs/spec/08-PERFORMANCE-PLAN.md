# 08 · 性能计划

## 1. 先测再改

增加开发态 profiler counters：

```ts
interface AgentChatRenderMetrics {
  messageChars: number;
  visibleChars: number;
  stableChunkCount: number;
  activeTailChars: number;
  markdownParseCount: number;
  markdownParseDurationMs: number;
  codeTokenizedLines: number;
  renderedTurnGroups: number;
  totalTurnGroups: number;
  followEndMode: "following" | "detached";
}
```

禁止记录正文、文件名、路径和 prompt。

## 2. 基准场景

### A. 长普通回答

- 100,000 字符；
- 3,000–5,000 delta；
- heading/list/table/link 混合；
- 用户保持底部。

### B. 长代码

- 2,000 行 TypeScript；
- fence 在最后才闭合；
- syntax highlight enabled；
- Mermaid 不参与。

### C. 长会话

- 500 Turn；
- 每 Turn 2–5 messages + tools；
- 10 个动态图片/diagram；
- detached / switch / restore / prepend history。

### D. 高频工具

- 1,000 tool progress/update；
- active tool 每秒多次更新；
-历史 Turn render count 应保持不变。

## 3. 目标预算

以下是工程目标，不是假装已有测量：

- 流式阶段 stable Markdown chunk render count：每块稳定后为 0；
- 常规 active tail：95p < 1,200 字符；
- active tail parse：95p < 4ms；
- 单次 React commit：95p < 8ms，99p < 16ms；
- 流式期间 >50ms long task：0；
- first delta → first painted text：95p < 100ms；
- final delta → settled representation：95p < 250ms；
- detached 时 append 导致 scrollTop drift：≤1px；
- anchor restore：row top 误差 ≤2px；
- virtualized DOM Turn groups：约 visible + overscan，不随总 Turn 线性增长；
- Side update 不导致主 transcript历史 Turn render。

## 4. append-aware scanner

当前全文 scan 工作量近似：

```text
len1 + len2 + ... + lenN
```

目标：

```text
new suffix + last incomplete line
```

scanner 不是 parser，不需要产生 AST；只负责安全 commit boundary。

## 5. Safe reveal

替代固定 setTimeout 链：

- `requestAnimationFrame` 对齐显示帧；
- backlog 大时加快；
- backlog 小时缓和；
- safe boundary；
- max holdback 600 chars；
- document hidden 时直接追到 ceiling；
- stream settle 时显示全部 canonical text，再 deferred final parse。

## 6. Code fast path

未闭合 code fence：

- Markdown prefix 正常 parse；
- active code value 使用 plain/pre token path；
- 完整行增量 tokenize；
- partial line cheap；
- fence close 后 final highlight；
- 超大代码超过预算时降级 plain text 并保留 Copy。

## 7. Virtualizer

保留 TanStack Virtual。优化项：

- stable turn key 继续保留；
- exact row anchor restore；
- estimate size 按历史测量/row kind 可选改进；
- tool disclosure motion期间只阻止不安全调整；
-避免每个 bottom dock ResizeObserver callback 都触发多次 scroll end；
- rAF coalesce safe-area measurement 与 bottom lock；
- profiler验证 `useFlushSync: true` 是否只在必要路径使用，不能凭感觉移除。

## 8. 性能 feature flag

建议一开始增加内部 flag：

```text
agent_gui_incremental_markdown_v2
agent_gui_row_anchor_scroll_memory
agent_gui_composer_intent_model
```

flag 只选择 presentation implementation，不复制 canonical state。稳定后删除旧路径与 flag。
