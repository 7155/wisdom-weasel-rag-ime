# 12 · 验收标准

## A. 功能

- [ ] Agent工作时Composer仍可输入
- [ ] busy时Enter默认Queue，按钮文案同步
- [ ] pending approval/question不吞普通follow-up
- [ ] Queue编辑恢复exact structured draft
- [ ] Queue删除/Send next使用exact IDs
- [ ] Stop不误清Queue；paused状态清晰
- [ ] destructive interrupt不能被普通Enter误触
- [ ] Side内容不进入main transcript
- [ ] Edit/Retry失败不丢草稿
- [ ] Fork明确创建分支而非改写原历史

## B. Scroll

- [ ] following时stream/resize保持底部
- [ ] 用户向上滚后不被新token拉回
- [ ] detached显示新内容数量
- [ ] 点击跳转恢复following并清零
- [ ] 会话切换按row anchor恢复≤2px
- [ ] 图片、代码、tool展开导致高度变化时anchor稳定
- [ ] history prepend不跳
- [ ] virtual/non-virtual行为一致

## C. Markdown

- [ ] append update不全文扫描
- [ ] stable block稳定后不再render
- [ ] active tail是唯一持续变化Markdown块
- [ ] 半截link/emphasis/code不闪烁
- [ ] 未闭合长代码不反复全量高亮
- [ ] settle后GFM/link/mention/media/Mermaid语义不退化
- [ ] Windows/local path行为不退化
- [ ] sanitize不退化
- [ ] canonical whitespace不被trim替换

## D. 性能

- [ ] 100k字符streaming无>50ms长任务（目标环境）
- [ ] active tail parse 95p <4ms
- [ ] React commit 95p <8ms
- [ ] 500 Turn DOM不线性增长
- [ ] active tool update不重渲染历史Turn
- [ ] Side update不重渲染main历史
- [ ] first delta→paint 95p <100ms

## E. 无障碍

- [ ] Queue折叠控件有aria-expanded/count
- [ ] 所有menu键盘可达
- [ ] reorder有非拖拽替代
- [ ] focus不被streaming抢走
- [ ] reduced motion正确
- [ ] screen reader不逐token轰炸
- [ ] tooltip不是唯一说明

## F. 架构

- [ ] 没有GUI-owned第二套lifecycle
- [ ] 没有provider-name分支
- [ ] exact identity贯穿
- [ ] user copy进入i18n
- [ ] UI System优先
- [ ] lifecycle变化有Host conformance
- [ ] architecture/troubleshooting/docs同步
- [ ] Windows影响已评估

## G. 交付报告

Claude Code最终必须列出：

1. 修改文件；
2. 每个交互变化；
3. canonical owner未变的证据；
4. 性能前后数据；
5. focused tests及结果；
6.未执行验证；
7. REVIEW lanes；
8. docs更新；
9.剩余风险；
10.建议后续但未擅自扩大scope的事项。
