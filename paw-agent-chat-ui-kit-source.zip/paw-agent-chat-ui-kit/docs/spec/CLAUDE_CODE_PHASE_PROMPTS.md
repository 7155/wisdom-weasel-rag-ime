# Claude Code 分阶段提示词

当一次性总任务过大，可逐条运行。每条都继承 `CLAUDE_CODE_MASTER_PROMPT.md` 的全部边界。

## Phase 0 · 审计与基线

```text
读取本任务包和仓库 AGENTS/architecture/REVIEW/testing。记录 HEAD、branch、status、现有 diff，不覆盖用户修改。对 AgentMessageMarkdown、Transcript virtualizer、detail scroll、Composer gate、Queue actions/panel、submit settlement、Side、Edit/Retry 做当前状态审计。先增加 characterisation tests 与无正文性能指标，建立 100k Markdown、2k code lines、500 Turn 和 1k tool update fixtures。不要改变用户可见行为。运行 focused tests，输出 baseline 和下一阶段精确 patch plan。
```

## Phase 1 · Streaming Markdown

```text
在保留 ReactMarkdown、sanitize、link/mention/media、Windows/local path、Mermaid 和当前 renderer components 的前提下，将 stateless splitStreamingMarkdownBlocks 升级为 append-aware scanner：保存最后未完成行 offset，识别 fence/math/list/table/blockquote/indented code，输出stable numeric chunks + one active tail，non-append reset。把 useStreamingVisibleText 升级为 rAF safe reveal，避开半截inline code/link/emphasis/list/heading/surrogate，holdback≤600。stable block必须memoized且稳定后不再render。先写pure tests、random differential和render-count tests，再改生产代码。运行相关测试与性能fixture，给出前后parse/render数据。
```

## Phase 2 · Code tail

```text
基于现有 Markdown renderer 增加 open fenced-code fast path。流式未闭合code block时只解析fence之前的Markdown，动态code body使用cheap path；完整行可缓存token与grammar state，partial line不做昂贵高亮；fence闭合/stream settle后final highlight。Mermaid只在完整和safe settle后渲染。若当前highlighter不提供可靠state API，采用plain live tail + final highlight，不伪造incremental highlighter。加入2k-line benchmark与超大code降级测试。
```

## Phase 3 · Scroll & live islands

```text
保留TanStack Virtual与现有follow-end controller。把conversation scroll memory从纯scrollTop geometry扩展为stable transcript row key + offsetFromViewportTop + fallbackScrollTop。virtual controller暴露exact row locate/capture/restore。following append/resize继续跟底；user wheel/touch/pointer/keyboard away变detached；detached append不漂移并累积unseen count；jump/latest或submit回following。覆盖conversation switch、history prepend、image/Mermaid/tool disclosure height change、stale controller、virtual/nonvirtual。用React Profiler修复active text/tool/Side更新导致历史turn rerender的问题。
```

## Phase 4 · Composer intent

```text
新增纯 projectAgentGUIComposerActionModel，统一AgentComposer、Chrome、View、Footer、Queue panel的动作投影。idle primary=send；busy或pending interaction primary=queue；settling可编辑但submission blocked；hard block才禁editor。追踪routing normal/immediate/send_now、cancel与queue drain完整contract。只有canonical语义明确时显示Guide current turn和Interrupt and send；destructive interrupt不得绑定普通Enter。所有copy走i18n，保留draft snapshot/settlement恢复与exact IDs。加入表驱动测试。
```

## Phase 5 · Queue

```text
保留Engine-owned queue和useAgentGUIQueueActions。把AgentQueuedPromptPanel做成一行collapsed summary（count + next preview + paused状态），expanded list显示attachments、Send next、Edit、Remove。Edit恢复exact structured draft与图片并回焦Composer。Stop后queue paused不自动清空。只有Engine已有canonical move command时增加reorder，并提供keyboard move。receipt必须来自canonical submit/operation state。更新组件、controller和settlement tests及a11y tests。
```

## Phase 6 · Side / Edit / Fork / Visual

```text
保持Host-backed Side lifecycle与fail-closed /side逻辑，只优化独立pane的上下文隔离说明、draft/focus/scroll、pending interaction、close/cancel recovery。统一Edit/Retry/Fork lineage presentation，明确retry from here和fork creates branch。使用UI System tokens，减少厚卡片，Queue一行、Tool/Thinking渐进披露、120–200ms轻动效、reduced motion。不要增加provider-specific UI或新lifecycle。
```

## Phase 7 · 收尾

```text
删除旧的重复renderer/scroll/intent路径和临时flag；更新agent-gui-node architecture与agent runtime troubleshooting；完成i18n、Windows影响评估、REVIEW lanes、focused tests、check:changed和必要boundary/conformance检查。运行长文本/长code/500 Turn性能基准，给出真实前后数据、未运行验证与剩余风险。按master prompt格式输出最终报告。
```
