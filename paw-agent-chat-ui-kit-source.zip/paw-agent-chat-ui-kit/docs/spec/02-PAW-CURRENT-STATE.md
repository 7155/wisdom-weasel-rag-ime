# 02 · PAW 当前实现审计

## 1. 当前已经做对的事情

### 1.1 Canonical ownership 正确

`AgentSessionEngine` 已经拥有 queue、pending intent 和 canonical frontend state。GUI controller 通过 semantic dispatch 操作：

- `submit/canceled`
- `queue/removed`
- `queue/sendNowRequested`
- `sessionEngine.submitPrompt(...)`

这比在组件里维护本地 queue 更正确，必须保留。

### 1.2 Composer 已支持 busy 时排队

`resolveAgentGUIComposerGate()` 已把 editor 与 submission 拆开：

- conversation busy 时 editor 仍可 editable；
- `submission.status === "queue"`；
- runtime/hard block 才真正禁用 editor；
- pending interaction 也能进入 queue 路径。

这已经接近 Claude 的 always-available composer，不应重写为 disabled input。

### 1.3 Queue 已有完整基础动作

`useAgentGUIQueueActions.ts` 已有：

- remove；
- edit 并恢复结构化 draft 和图片；
- send next，带 exact session/prompt ID 和 timeout；
- 对 optimistic submit 与 canonical queued record 做兼容分支。

`AgentQueuedPromptPanel.tsx` 已有：

- 单条摘要；
- 多条展开；
- overflow tooltip；
- 图片加载；
-键盘 Enter/Space；
- Send next / Edit / Delete menu；
- paused-by-user presentation。

### 1.4 提交恢复链路成熟

`useAgentGUISubmitInteractionActions.ts` 已有：

- `clientSubmitId`；
- draft snapshot；
- accepted / queued 后 optimistic clear；
- send 后失败时由 settlement controller 恢复 draft；
- `routing: immediate` 与 `routing: send_now` 入口；
- exact session/turn identity；
- diagnostics 与 paint mark。

因此交互优化应复用这里，不应另写一套 fetch/send。

### 1.5 Timeline 已虚拟化

`AgentTranscriptView.tsx` 已：

- 按 Turn group 建模；
- 根据 complexity 决定是否 virtualize；
- memoized props comparator；
- participant / tool / thinking / edit-retry / fork 投影；
- user-message locator；
- entering row motion。

`useAgentTranscriptVirtualizer.ts` 已：

- `@tanstack/react-virtual`；
- stable key = session + turn group key；
- direct DOM transform updates；
- append follow；
- overscan；
- dynamic size；
- virtual scroll controller。

所以“增加虚拟列表”不是任务；任务是让 live row、anchor restoration 和动态高度更稳。

### 1.6 Scroll 已有 follow-end controller

`useAgentGUIDetailScroll.ts` 已处理：

- following / detached；
- conversation switching；
- submitted prompt jump；
- older-message prepend；
- bottom dock safe area；
- ResizeObserver；
- virtual/non-virtual 双路径；
- near-top prefetch；
- user scroll direction。

### 1.7 Side conversation 已是正式架构

`useAgentGUIDetailSideConversation.ts` 不是假侧栏：

- capability-gated；
- runtime.open/send/cancel/close/respond；
- exact source session identity；
- fail closed，不把 `/side` 内容泄漏到主对话；
- 独立 draft；
- approval/question interaction；
- busy 时把初始 prompt 留在 Side draft。

### 1.8 Edit/Retry 已走 Engine

`useAgentGUIEditRetryController.ts` 通过 activity-core dispatch，保留 typed failure/recovery state，并在拒绝时保留编辑草稿。

### 1.9 Markdown 已有优化基础

`AgentMessageMarkdown.tsx` 当前已有：

- fixed-rate visible text；
- streaming tail stabilizer；
- split blocks；
- cached parser；
- React memo；
- link / mention / media / local path / Windows path；
- Mermaid streaming guard；
- sanitization。

## 2. 当前主要结构性问题

### 2.1 `splitStreamingMarkdownBlocks()` 是 stateless full scan

每次内容增长都：

```ts
content.replace(...).split("\n")
for every line ...
```

它知道 code fence，却没有保存上一轮 scanner offset；长回答持续增长时仍反复扫描全文。

### 2.2 fixed-rate visible text 不理解 Markdown 安全边界

当前按 `frameMs` 和 `maxCharsPerSecond` 截断。尾部 stabilizer 能补一部分格式，但可见边界与 parser boundary 仍分离，可能产生：

- 半截链接/强调；
- marker 短暂变形；
- 额外 tail repair；
- fixed timer 与 60/120Hz 刷新不同步。

### 2.3 completed block key 稳定性需要审计

`initialKeyContent` 基于内容。要确认：

- streaming tail 变成 stable block 时 key 是否连续；
- edit/regeneration 时是否正确 reset；
- plugin/normalization 导致内容变化时是否重挂旧 DOM；
- callback identity 是否使旧 block 重新 render。

### 2.4 scroll memory 仍以数值 geometry 为主

当前 `TimelineScrollAnchor` 主要保存：

- `scrollTop`
- `scrollHeight`
- `clientHeight`
- conversation ID

虚拟化、图片、Mermaid、tool disclosure 和代码高亮导致上方高度变化时，纯 offset 恢复不如“稳定 row key + row 内像素偏移”可靠。

### 2.5 Queue、Steer、Interrupt 的用户心智仍不够统一

底层已有 `immediate`、`send_now`、queue 和 stop，但需要一个纯 presentation model 明确：

- Enter 当前会发生什么；
- Queue 和 Send next 区别；
- Stop 当前 Turn 后 queue 是否暂停；
- 哪个动作会改变当前 Turn；
- 高风险 interrupt 是否需要二次确认；
- action receipt 如何展示。

### 2.6 时间线 live updates 的隔离还可加强

虽然顶层 view memo 和 virtualizer 已存在，仍需 profiler 验证：

- active assistant text delta 是否重建整个 `conversation.rows`；
- parent props 是否让所有 turn groups comparator 失败；
- tool progress 是否使无关 Markdown 重渲染；
- bottom dock resize 是否触发不必要 timeline pass。

### 2.7 UI 信息层级偏工程化

功能很多，但用户不应同时看到所有内部状态。需要按渐进披露收敛：

- 正常状态只显示内容、当前工作和 composer；
- Queue 用一行摘要；
- Tool group 默认折叠；
- pending approval/question 提升到 dock；
- recovery/diagnostic 只在需要时出现；
- Side 是独立上下文，不伪装成主 timeline 一段普通消息。
