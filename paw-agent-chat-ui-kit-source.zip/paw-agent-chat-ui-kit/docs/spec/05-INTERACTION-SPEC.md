# 05 · 完整聊天交互规格

## 1. Composer

### 1.1 基本规则

- Composer 是持续可用的工作入口，不因为 Agent 正在输出就整体 disabled；
- hard block 才禁用：read-only collaborator、runtime unavailable、non-retryable recovery、明确权限/身份失败；
- busy、waiting tool、pending queue 时允许继续输入；
- draft 是 session-scoped；Side draft 与主 draft 完全分离；
- submit 被拒绝或结果未知时恢复 exact draft snapshot，包括图片和引用；
-切换会话后恢复各自 draft 与 cursor/focus；
- Enter 语义必须由按钮 label 和 tooltip明确展示。

### 1.2 键盘

推荐默认：

| 操作 | 行为 |
|---|---|
| Enter | 执行当前 primary action：idle=Send，busy=Add to queue |
| Shift+Enter | 换行 |
| Esc | 关闭当前 palette/menu；不默认 Stop |
| Cmd/Ctrl+Enter | 可配置为 Send；不要默认映射 destructive interrupt |
| Up/Down（空输入） | 历史输入导航，保持现有规则 |
| Cmd/Ctrl+Shift+Enter | 不默认启用；若启用 interrupt，必须设置里显式开启 |

### 1.3 按钮模式

#### Idle

```text
[ Send ↑ ]
```

#### Busy、无 pending Interaction

```text
[ Add to queue ↗ ] [▾]
menu:
  Add to queue          default
  Send next             提升为下一条
  Guide current turn    仅 canonical immediate 支持时
  Interrupt and send    destructive
```

#### Pending approval/question

主交互控件优先出现；Composer 仍可输入 follow-up 并 queue，但发送按钮明确写 `Add to queue`，避免用户以为输入是答案。

#### Stopping / outcome unknown

Composer 可编辑但 submission blocked；显示短状态，不吞 draft。

## 2. Queue

### 2.1 折叠态

一条：

```text
Queued · Next: <一行预览>                              ⋯
```

多条：

```text
3 queued · Next: <一行预览>                            ›
```

paused：

```text
Queue paused · 3 waiting · Next: <预览>                 ›
```

不要让 Queue panel 占据多行常驻空间。

### 2.2 展开态

每条展示：

- drag handle（仅 canonical reorder 支持时）；
- content preview；
- attachment chips / thumbnails；
- queued time 作为次要信息；
- `Send next`、`Edit`、`Remove`；
- 当前 draining 项显示 progress 且动作禁用。

### 2.3 编辑

- 点击 Edit：从 queue 移除/cancel exact record，并恢复到 Composer；
- 恢复完整 structured draft；
- 图片异步加载失败不丢文本；
- focus 回 Composer；
- 编辑后再次 Enter 遵循当前 primary action。

### 2.4 Stop 与 Queue

Stop 只针对 exact active Turn。队列后续行为由 canonical `suspendReason` 决定。UI 必须：

- 若 `paused_by_user`：明确 Queue paused；
- 提供 `Send next` 或 canonical resume；
- 不自动清空；
- 不把 stop 误写成取消整个 Session；
- 提供单独的 Clear queue，且 destructive confirmation 只在多条或含附件时出现。

## 3. Guide / Steer / Interrupt

### 3.1 三个概念必须分开

- **Queue**：当前 Turn 不变，内容以后处理；
- **Guide current turn**：内容进入当前 Turn 的可观察 guidance lane，不取消 Turn；
- **Interrupt and send**：取消 exact active Turn，再启动新提交。

只有当 Engine/Host 有对应 semantic contract 时才显示后两项。

### 3.2 Receipt

对于非普通 queue 的消息，在用户消息下显示轻量 receipt：

```text
Queued
Delivering
Applied to current turn
Interrupting…
Interrupted · sent
Failed · Retry
```

状态必须来自 canonical submit/operation projection。GUI 可以对 `applied -> timestamp` 做短暂动画，但不能伪造“已读”。

### 3.3 失败

- guidance 失败：保留消息和 Retry；不自动改成普通 queue；
- interrupt outcome unknown：禁用重复 destructive action，提供 recovery；
- cancel 成功但新 submit 失败：恢复 draft或显示明确 queued/failed record；
- exact clientSubmitId 保证幂等。

## 4. Transcript

### 4.1 消息视觉

- 用户消息：轻微 surface 区分，不使用厚重气泡；
- Assistant：正文直接落在内容列，不套每条卡片；
- Thinking：默认折叠，只显示当前阶段摘要和时长；
- Tool：同一 Turn 的连续 tool calls 组合为 work section；
- 当前 tool：只更新自己的 live island；
- completed tool：冻结；
- error：内联、可恢复、不过度红色；
- artifact：结果卡片与正文分离，但属于同一 Turn。

### 4.2 新内容与底部

- following 时继续跟随；
- 用户滚离后绝不被 token 拉回；
- detached 时底部悬浮：`↓ 12 new updates`；
- 点击回到底部并清零；
- 用户提交新 prompt 时默认回到底部；若有 text selection 或辅助阅读模式，可保留并提示。

### 4.3 会话切换

- 保存 row anchor；
- 回来先渲染骨架/virtual list，再按 row key 恢复；
- row 不存在时 fallback scrollTop；
- anchor row 被历史分页移除时选择最近后继；
- pinned/following 会话切回直接 end。

## 5. Streaming Markdown

- stable chunk 不随新 token 重渲染；
- active tail 才重新 parse；
- 一帧最多一次 visible update；
- 不展示半截 inline construct；
- code fence 未闭合时禁止反复高亮整段；
- Mermaid 在 fence 完整且 settle 后才渲染；
- 用户复制时必须拿 canonical full content，而不是 visible prefix；
-屏幕阅读器不要逐 token 宣读；settle 后或按句子/段落节流 announce。

## 6. Side Conversation

- 右侧 pane 或可调整宽度 drawer；
- 顶部固定说明：`Uses this conversation as context · Not added to the main thread`；
- 主 timeline 和 Side 各自 scroll/follow；
- Side busy 时保留 draft，不偷用主 queue；
- `/side prompt` 成功 open 后才清主 draft；
- Side close failure 保留 recovery；
- source session 改变时不得把 Side 错接到另一个 Session。

## 7. Edit / Retry / Fork

### Edit & Retry

- 只在 canonical eligible user message 上出现；
- inline editor 替换原消息正文，但不立即删除后续历史；
- submit 前显示 `Retry from here`；
-结果未知时保留 editor draft；
- recovery actions来自 Engine。

### Fork through turn

- 视觉文案明确是创建分支，不是假装回滚原对话；
- 显示新分支来源 Turn；
- pending 时只禁用同一 Turn 的重复 fork；
- fork 后滚动到新会话开始或保留原会话，按现有 product policy。

## 8. Empty / Loading / Error

- 初始加载：稳定 skeleton，不先闪空态；
- history prepend：顶部局部 loading，不覆盖 transcript；
- reconnect gap：冻结 live duration，保留历史；
- failed session：Composer 根据 recovery gate 决定 editable，不一律锁死；
- unsupported capability：隐藏不完整入口，不展示死按钮。
