# 13 · Telemetry 与诊断

## 1. Privacy

绝不记录：

- message/prompt正文；
-文件名、路径、URL；
- tool input/output；
- Side内容；
- queue preview；
- provider secret。

只记录数量、耗时、枚举状态和stable IDs的不可逆局部诊断关联（遵循仓库现有 policy）。

## 2. 建议事件

```text
agent.chat.stream_first_paint
agent.chat.stream_settled
agent.chat.markdown_parse
agent.chat.markdown_reset
agent.chat.scroll_mode_changed
agent.chat.scroll_anchor_restored
agent.chat.new_activity_below
agent.chat.composer_intent_submitted
agent.chat.queue_action
agent.chat.side_opened
agent.chat.edit_retry_action
```

字段例：

```ts
{
  message_chars_bucket: "10k-50k",
  stable_chunks: 42,
  active_tail_chars: 613,
  duration_ms: 2.8,
  intent: "queue",
  result: "accepted",
  follow_end_mode: "detached",
  virtualized: true
}
```

## 3. 开发态诊断

提供可开关 debug panel / console group：

- current session/turn/clientSubmit IDs（按仓库日志安全规则）；
- gate与action model；
- queue status/count；
- follow-end mode；
- anchor row key；
- virtual rows count；
- streaming chunk count；
- parse/render counters；
- last settlement/reconciliation reason。

## 4. 常见故障定位

### 一直跳到底部

检查：

1. follow controller是否被错误 dispatch `conversation-changed`；
2. ResizeObserver是否在detached仍调用scrollToEnd；
3. virtual controller identity是否stale；
4. prompt-submitted ref是否未清；
5. anchor restore是否失败后默认following。

### Queue文案与实际行为不一致

检查：

1. gate action model；
2. submit options routing；
3. engine accepted/queued；
4. optimistic record clientSubmitId；
5. canonical queue record reconcile；
6. suspend reason。

### 长回答后卡顿

检查：

1. scanner reset次数；
2. active tail长度；
3. stable chunk render次数；
4. code fence是否一直走normal parser；
5. Mermaid是否过早render；
6. parent callback/props identity；
7. virtual row remeasure频率。
