# 10 · 精确 Patch Manifest

`M` 修改，`A` 新增，`?` 先审计后决定。

## 1. Streaming Markdown

| 类型 | 文件 | 任务 |
|---|---|---|
| M | `packages/agent/gui/shared/AgentMessageMarkdown.tsx` | 接入 incremental document、stable chunks、active tail；保留现有 renderers |
| M | `packages/agent/gui/shared/agentMessageMarkdownRuntime.ts` | 把 stateless split演进为兼容 wrapper；保留 links/helpers |
| M | `packages/agent/gui/shared/useStreamingVisibleText.ts` | rAF + safe boundary + backlog adaptive；保持 pure advance helper可测 |
| M/? | `packages/agent/gui/shared/streamingMarkdownTailStabilizer.ts` | 缩为 fallback；避免与 safe reveal重复修复 |
| M | `packages/agent/gui/shared/cachedMarkdownParser.ts` | 审计 cache key与 settled whole-doc parse支持 |
| A | `packages/agent/gui/shared/streamingMarkdownDocument.ts` | append-aware scanner与 state |
| A | `packages/agent/gui/shared/streamingMarkdownSafeReveal.ts` | safe reveal算法 |
| A | `packages/agent/gui/shared/streamingMarkdownOpenFence.ts` | open fence fast path |
| A/? | `packages/agent/gui/shared/streamingCodeTokenizer.ts` | 行级 cache adapter；先确认现有 highlighter能力 |
| A | 对应 `.spec.ts(x)` | scanner/reveal/fence/cache/regeneration测试 |

## 2. Timeline / Scroll

| 类型 | 文件 | 任务 |
|---|---|---|
| M | `.../view/agentGUIScrollMemory.ts` | 保存 row anchor + offset + fallback geometry |
| M | `.../view/useAgentGUIDetailScroll.ts` | capture/restore anchor；new update count；coalesce resize/follow |
| M | `.../view/agentGUIDetailScrollTypes.ts` | 新 anchor类型 |
| M | `.../view/agentGUIDetailScrollHelpers.ts` | pure geometry/anchor helpers |
| M | `packages/agent/gui/shared/agentConversation/components/useAgentTranscriptVirtualizer.ts` | 增加 row-key locate/anchor API；保留现有 virtualizer |
| M | `.../AgentTranscriptView.tsx` | 暴露 row locator/controller；确认 stable turn memo |
| M | `.../AgentGUIConversationTimelinePane.tsx` | new activity control与 data attributes |
| M | `.../useAgentGUIDetailScroll.spec.tsx` | anchor、resize、switch、prepend、detached测试 |
| A | `.../agentGUIMessageAnchor.ts` | pure capture/restore projection（若 helper不适合承载） |

## 3. Composer / Intent / Queue

| 类型 | 文件 | 任务 |
|---|---|---|
| A | `.../model/agentGuiComposerActionModel.ts` | 纯 presentation投影 |
| M | `.../model/agentGuiComposerGate.ts` | 只补必要输出，不复制 intent lifecycle |
| M | `.../composer/AgentComposer.types.ts` | action model与支持能力props |
| M | `.../composer/AgentComposerChrome.tsx` | 主/次动作与 menu |
| M | `.../composer/AgentComposerView.tsx` | primary action label/tooltip/keyboard |
| M | `.../composer/ComposerFooter.tsx` | 次要动作布局 |
| M | `.../AgentComposer.tsx` | 连接 action model，不添加 orchestration |
| M | `.../controller/useAgentGUISubmitInteractionActions.ts` | 只映射现有 semantic routing；保持settlement恢复 |
| M | `.../controller/useAgentGUIQueueActions.ts` | focus回Composer；若已有 canonical move再暴露 reorder |
| M | `.../AgentQueuedPromptPanel.tsx` | 一行摘要、expanded list、a11y、paused解释 |
| M | `.../AgentQueuedPromptPanel.spec.tsx` | collapsed/expanded/keyboard/action测试 |
| M | `.../useAgentGUIQueueActions.spec.tsx` | exact identity、restore draft、failure测试 |
| M | `.../useAgentGUISubmitInteractionActions.spec.ts` | routing/settlement/draft恢复测试 |

## 4. Side / Edit / Fork

| 类型 | 文件 | 任务 |
|---|---|---|
| M | `.../view/AgentGUISideConversationPane.tsx` | isolation说明、状态层级、scroll/draft polish |
| M | `.../view/useAgentGUIDetailSideConversation.ts` | 只做presentation/focus错误处理，不改Host semantics |
| M | `.../view/useAgentGUIDetailSideConversation.spec.ts` | source identity、fail-closed、draft测试 |
| M | `.../controller/useAgentGUIEditRetryController.ts` | 保持 engine dispatch；补telemetry/interaction契约所需最小改动 |
| M | `.../view/AgentGUIEditRetryStatus.tsx` | lineage/recovery presentation |
| M | `.../AgentTranscriptView.tsx` / Fork controls | 统一 branch wording与pending state |

## 5. Docs / i18n / UI System

| 类型 | 文件 | 任务 |
|---|---|---|
| M | `docs/architecture/agent-gui-node.md` | streaming、intent、scroll ownership数据流 |
| M | matching troubleshooting doc | 记录重复跳底、队列不一致、streaming卡顿诊断 |
| M | AgentGUI i18n resources | 所有新label；中文无中文句号结尾 |
| ? | `packages/ui/*` | 只有缺可复用primitive/token才扩展 |
| M | `packages/agent/gui/REVIEW.md`触发lane说明 | 逐lane给证据 |

## 6. 不要修改

除非发现明确 contract 缺口：

- provider adapters；
- `apps/desktop` business lifecycle；
- HTTP/OpenAPI；
- Side Host lifecycle；
- store schema；
- provider-specific renderer。
