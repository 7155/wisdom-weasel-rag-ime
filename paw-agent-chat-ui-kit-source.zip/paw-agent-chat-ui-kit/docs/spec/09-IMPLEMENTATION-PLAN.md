# 09 · 分阶段实施计划

每阶段独立小提交，禁止一次大爆改。

## Phase 0 · Baseline & guardrails

### 目标

- 记录 HEAD、diff、现有测试；
- 读完 AGENTS / architecture / REVIEW；
- 添加无正文 telemetry 与 benchmark harness；
- 写 characterisation tests，不改视觉。

### 提交

```text
chore(agent-gui): add chat interaction performance baselines
```

## Phase 1 · Incremental Markdown core

### 修改

- 新增 append-aware scanner；
- 替换 `splitStreamingMarkdownBlocks` 内核；
- stable numeric/sequence keys；
- non-append reset；
- 保留旧函数兼容出口，逐步切换；
- safe reveal scheduler；
-现有 tail stabilizer 退化为异常 fallback 或删除重复修复。

### 不做

- 不换 ReactMarkdown；
- 不动 link/media/mention；
- 不动 Host。

### 提交

```text
perf(agent-gui): incrementally render streaming markdown blocks
```

## Phase 2 · Code fence & settle

- open fence detection；
- growing code tail fast path；
- incremental line tokenizer adapter；
- final whole-document parse/partition feasibility spike；
- Mermaid 只在安全 settle 渲染。

```text
perf(agent-gui): isolate live code tails during streaming
```

## Phase 3 · Scroll anchor & live isolation

- 扩展 scroll memory为 row key + offset；
- legacy offset fallback；
- virtual controller新增 locate/restore anchor能力；
- unseen count；
- profiler修复历史 Turn无关 rerender；
- Side/main scroll互不影响。

```text
fix(agent-gui): preserve transcript position by stable row anchor
```

## Phase 4 · Composer intent model

- 新增纯 `projectAgentGUIComposerActionModel()`；
- AgentComposerChrome / View / Footer统一消费；
- idle/busy/interaction/settling文案一致；
- menu列出 queue/send-next/guidance/interrupt only when supported；
- action mapping复用 `submitPrompt` options和Engine dispatch。

若 `immediate`/`send_now` 语义不够：暂停 GUI改动，转 Host/Engine conformance小阶段。

```text
refactor(agent-gui): unify composer submit intent presentation
```

## Phase 5 · Queue presentation

- 一行 collapsed summary；
- expanded list信息层级；
- focus return；
- keyboard move替代/补充 drag；
- paused状态解释；
- receipts与canonical settlement关联。

```text
feat(agent-gui): clarify queued follow-up controls
```

## Phase 6 · Side / Edit / Fork polish

- 不改 Side lifecycle；
- 明确 isolation文案；
- Side draft/focus/scroll；
- Edit/Retry/Fork统一 lineage UI；
- error/recovery状态一致。

```text
feat(agent-gui): refine side and conversation lineage interactions
```

## Phase 7 · Visual, a11y, cleanup

- UI System tokens；
- motion/reduced motion；
- remove obsolete renderer path；
- docs更新；
- full review lanes。

```text
refactor(agent-gui): finalize conversation interaction architecture
```

## 每阶段停止条件

出现以下情况立即停止当前 UI patch并报告：

- 需要猜测 queue/immediate/send_now lifecycle；
- exact turn/request/clientSubmit identity不可得；
- 只能用 provider name分支；
- 只能在 React local state伪造 canonical状态；
- 必须更改 OpenAPI但尚未先改 schema；
- 工作区已有冲突修改；
- focused tests出现与改动相关回归。
