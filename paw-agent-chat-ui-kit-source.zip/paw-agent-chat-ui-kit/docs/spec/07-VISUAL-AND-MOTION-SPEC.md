# 07 · 视觉、布局与动效规格

## 1. 设计方向

使用 PAW 当前 UI System，不复制 Claude 配色。目标：现代纸面、内容优先、低噪声。

- 背景：现有 app/background semantic token；
- 内容列：无厚卡片；
- 字体：现有中文 Sans 与 mono token；
- 圆角：沿用 UI System 小圆角；
- 分隔：细边界，不依赖阴影堆层级；
- 强调色：只用于 active / actionable，不铺满；
- 所有颜色必须来自 semantic token。

## 2. 桌面布局

```text
┌ rail ┬──────────────── conversation ────────────────┬ side(optional) ┐
│      │ header                                        │                │
│      │                                               │ side context   │
│      │ centered content column                       │ timeline       │
│      │ max-width 760–860px                           │ composer       │
│      │                                               │                │
│      │ new activity control                          │                │
│      │ queue summary                                 │                │
│      │ composer dock                                 │                │
└──────┴───────────────────────────────────────────────┴────────────────┘
```

不要把内容列拉满大屏。Tool result 或宽表格可局部横向滚动。

## 3. Turn 层级

### Stable Turn

- 用户 prompt 作为 Turn 入口；
- assistant 正文；
- Work section（thinking/tools）可折叠；
- artifact 与 final summary；
- Turn 间距大于同 Turn 内间距。

### Active Turn

只显示一个主脉冲来源：

- 当前工具/阶段旁微弱 activity indicator；
- streaming text 不给每个词做夸张动画；
- 新文字可做 120–180ms opacity easing；
- reduced motion 下直接出现。

## 4. Bottom Dock

顺序固定：

1. pending interaction（最高优先）；
2. Queue summary；
3. Composer；
4. 次要 settings/action footer。

Queue 展开时不能让 Composer 从视口消失；最大高度取 `min(280px, 38vh)`，现有实现可保留。

## 5. 动效

| 场景 | 时长 | 规则 |
|---|---:|---|
| 新文字 fade | 120–180ms | 只作用新增 span |
| Queue expand | 160–200ms | height/opacity，保持 Composer anchor |
| Side open | 180–220ms | width/opacity，避免 timeline 大幅 reflow |
| Jump-to-latest | 160–240ms | 用户显式点击才 smooth |
| 自动 follow | 0ms/instant | 流式期间不要连续 smooth scroll |
| receipt settle | 200ms | canonical state 后淡化为时间戳 |

## 6. 无障碍

- Queue summary 是 button，含 `aria-expanded` 与数量；
- destructive menu 项可键盘访问；
- drag reorder 必须同时提供 Move up/down；
- new activity control 读出数量；
- streaming content不放在 assertive live region；
- pending approval/question可以 polite announce 一次；
- focus 不因 token、Queue 更新或 virtual row mount 被抢走；
- `prefers-reduced-motion` 禁止 fade/slide；
- tooltip 不是唯一信息载体。
