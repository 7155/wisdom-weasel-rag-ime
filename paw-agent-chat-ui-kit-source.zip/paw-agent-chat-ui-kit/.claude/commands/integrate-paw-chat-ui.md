# Integrate PAW Agent Chat UI Kit

Use this package as tested source material and migrate it into the existing PAW AgentGUI. Do not create a permanent parallel chat surface.

## Required procedure

1. Record current branch, HEAD and `git status --short`.
2. Read all applicable `AGENTS.md`, architecture docs and AgentGUI review instructions.
3. Run focused existing tests before changing behavior.
4. Read `INTEGRATION.md`, `docs/MODULE_MAP.md`, and `docs/spec/10-PATCH-MANIFEST.md`.
5. Migrate one lane at a time:
   - incremental Markdown;
   - live code path;
   - scroll anchor/live islands;
   - Composer semantic action projection;
   - Queue presentation;
   - Side/Edit/Fork polish.
6. Preserve PAW's canonical Host/Engine lifecycle and existing UI System, i18n, Mention, Mermaid, sanitize, attachments, Windows paths and TanStack Virtual.
7. Never implement interrupt as `cancel + timeout + send`; expose it only if Host/Engine has an atomic or recoverable semantic command.
8. Add characterization and regression tests before replacing each hot path.
9. Use small commits. Do not reset or overwrite unrelated user changes.
10. Finish with focused tests, `pnpm check:changed`, profiler evidence, and an honest validation report.

## Source mapping

- `src/core/markdown/*` → existing AgentMessageMarkdown streaming internals.
- `src/core/interaction/composer.ts` → one provider-neutral Composer presentation model.
- `src/core/interaction/messageAnchor.ts` and `followEnd.ts` → existing detail scroll owner and virtualizer controller.
- `src/react/*` → patterns to migrate into current components, not a new long-lived component tree.
- `src/styles/chat-ui.css` → translate to `@tutti-os/ui-system` tokens and current component styling.
