# Validation

执行日期：2026-08-25

## 结果

```text
TypeScript core strict build        PASS
React/TSX strict static check       PASS
Node tests                          40 / 40 PASS
Full dist build                     PASS
Dist integrity check                PASS
Packed core export smoke test       PASS
```

`npm run verify` 已完整执行通过。

## 测试覆盖

- append-only Markdown block freezing；
- open/closed fenced code；
- list continuation；
- retry/edit/regeneration reset；
- settle 后 stable ID 与 final tail；
- safe reveal：inline code、link、list、heading、emoji、CJK、holdback cap；
- open code fence extraction；
- incremental tokenizer cache；
- whole-document AST node partition；
- Composer idle/busy/interaction/settling；
- semantic interrupt command；
- unsupported guidance fail-closed；
- Queue paused/draining/reorder/clientSubmitId reconciliation；
- operation canonical state transitions、outcome unknown；
- row anchor capture/restore/nearest successor；
- detached unseen count；
- main/side draft isolation；
- Side read-only context；
- stable Turn render identity。

## 构建产物

```text
dist total files       159
dist JavaScript files   38
```

## 合成 benchmark

见 `BENCHMARK_RESULT.json`：

```json
{
  "documentChars": 106707,
  "deltas": 4447,
  "stableChunks": 1632,
  "appendAwareScannedChars": 325401,
  "naiveScannedChars": 237363051,
  "scannedCharacterReduction": 729.4,
  "incrementalScannerMs": 608.87
}
```

`scannedCharacterReduction` 只表示 scanner 输入字符工作量模型，不能直接解释为浏览器 FPS 或整个 Markdown pipeline 的加速倍数。

## 仍需在 PAW 仓库验证

- 真实 `react-markdown` / unified parser 与 source position adapter；
- 当前 syntax highlighter 是否支持跨行 grammar state；
- Mermaid、Mention、local path、sanitize 和 attachment renderer 回归；
- TanStack Virtual row geometry 接口；
- Host/Engine 是否具备真正的 guide 与 atomic interrupt-and-submit contract；
- Electron/浏览器 React Profiler、Long Task、INP 和 dropped frame；
- `pnpm check:changed` 与 AgentGUI REVIEW lanes。

本包没有直接修改 PAW 仓库，因此不能声称 PAW 集成已经完成。
