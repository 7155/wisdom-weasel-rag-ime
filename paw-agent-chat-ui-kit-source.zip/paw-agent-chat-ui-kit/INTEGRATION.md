# PAW 集成手册

## 0. 先做基线

在 `paw-os` 当前工作分支执行：

```bash
git status --short
git rev-parse HEAD
pnpm check:changed
```

保留用户已有 diff，不 reset、不切换分支、不批量格式化无关文件。

## 1. Streaming Markdown

将代码包中的模块迁入：

| Kit 模块 | PAW 目标 |
|---|---|
| `core/markdown/scanner.ts` | `packages/agent/gui/shared/streamingMarkdownDocument.ts` |
| `core/markdown/reveal.ts` | `.../streamingMarkdownSafeReveal.ts` 与现有 `useStreamingVisibleText.ts` |
| `core/markdown/openFence.ts` | `.../streamingMarkdownOpenFence.ts` |
| `core/markdown/tokenizer.ts` | `.../streamingCodeTokenizer.ts`，仅在 highlighter 支持 grammar state 时启用 |
| `react/StreamingMarkdown.tsx` | 迁入现有 `AgentMessageMarkdown.tsx`，不要永久双栈 |
| `react/IncrementalCodeBlock.tsx` | 适配现有 code renderer / syntax highlighter |

必须继续保留 PAW 现有：

- Mention/object token；
- URL/local path/Windows path；
- sanitize；
- image/media；
- Mermaid；
- copy canonical content；
- cached parser。

Mermaid 只在 fence 完整并 settle 后执行昂贵渲染。

## 2. Composer 与语义命令

目标文件：

```text
packages/agent/gui/**/model/agentGuiComposerActionModel.ts
packages/agent/gui/**/composer/AgentComposer.types.ts
packages/agent/gui/**/composer/AgentComposerChrome.tsx
packages/agent/gui/**/composer/AgentComposerView.tsx
packages/agent/gui/**/controller/useAgentGUISubmitInteractionActions.ts
```

迁移 `core/interaction/composer.ts` 的纯投影。所有按钮、tooltip、Enter 快捷键和菜单消费同一个 `ComposerActionModel`。

逐一追踪现有 Host/Engine contract：

```text
send                 normal submit
queue                canonical queue submit
send-next            canonical priority/send-next
 guide-current-turn  只有当前 routing 明确支持 guidance lane 时开放
interrupt-and-send   只有原子/可恢复 command 时开放
stop                 exact active turnId cancel
```

不按 Claude/Codex/provider 名称做 UI 分支。

## 3. Queue

目标文件：

```text
.../AgentQueuedPromptPanel.tsx
.../controller/useAgentGUIQueueActions.ts
```

使用 `QueuePanel` 的表现层，但 records 必须来自现有 Engine projection。不要新增 canonical queue reducer。

必须保留：

- `queueId` 与 `clientSubmitId`；
- structured draft；
- 图片、引用和附件；
- edit 后恢复 exact draft；
- failure settlement；
- `paused_by_user`；
- draining item action disabled。

只有 Engine 有 canonical move command 时才传 `onMove`。

## 4. Transcript / Scroll

目标文件：

```text
.../view/agentGUIScrollMemory.ts
.../view/useAgentGUIDetailScroll.ts
.../view/agentGUIDetailScrollHelpers.ts
.../agentConversation/components/useAgentTranscriptVirtualizer.ts
.../AgentTranscriptView.tsx
```

保留 TanStack Virtual。把 virtualizer 已知 row geometry 传给 `captureTranscriptMessageAnchor()` / `restoreTranscriptMessageAnchor()`，不要安装第二个 virtualizer 或第二个 scroll owner。

状态规则：

```text
following + append/resize  -> end
user scroll away          -> detached + capture row anchor
detached + append/resize  -> restore anchor + unseen count
tap Jump to latest        -> following
user submits prompt       -> following
conversation switch       -> persist/restore per-conversation anchor
```

验收：detached streaming 漂移不超过 1px；正常 row anchor 恢复误差不超过 2px。

## 5. Live islands

历史 Turn 的 memo identity只依赖 canonical `turnId + revision + active`。以下变化不得重渲染稳定历史：

- active text delta；
- tool progress；
- composer draft；
- queue expand；
- side draft；
- scroll position。

推荐结构：

```text
Turn
├── completed markdown       frozen
├── completed tools          frozen
├── active markdown tail     live
├── active tool progress     live
├── pending interaction      live
└── artifacts                independent
```

## 6. Side Conversation

保留现有 Host-backed lifecycle。只迁移：

- isolation 文案；
- main/side draft vault；
- 独立 scroll/follow；
- source conversation identity guard；
- opening/closing/error presentation。

Side 读取主会话上下文，但不得写回主 transcript。

## 7. 测试命令

代码包自身：

```bash
npm run verify
```

PAW 中至少补：

```text
scanner append/reset/fence/list/math/table
safe reveal link/emphasis/emoji/CJK
open code fast path
queue exact identity + draft restore
composer idle/busy/interaction/settling
unsupported guidance hidden
interrupt outcome unknown recovery
scroll detached/resize/switch/prepend
Side source identity + draft isolation
React profiler stable-turn render count
```
