import { access, readdir, readFile } from "node:fs/promises";
const required = [
  "dist/index.js",
  "dist/index.d.ts",
  "dist/core/index.js",
  "dist/react/index.js",
  "dist/styles/chat-ui.css",
];
for (const path of required) await access(path);
const files = await readdir("dist", { recursive: true });
const js = files.filter((path) => path.endsWith(".js"));
if (js.length < 10) throw new Error(`dist unexpectedly small: ${js.length} JS files`);
const css = await readFile("dist/styles/chat-ui.css", "utf8");
if (!css.includes(".paw-chat-surface")) throw new Error("chat styles missing");
console.log(`dist OK: ${files.length} files, ${js.length} JavaScript modules`);
