import { performance } from "node:perf_hooks";
import {
  advanceStreamingMarkdownDocument,
  createStreamingMarkdownDocumentState,
} from "../build-test/core/markdown/scanner.js";

function makeDocument(paragraphs = 800) {
  const blocks = [];
  for (let index = 0; index < paragraphs; index += 1) {
    blocks.push(
      `## Section ${index}\n\n` +
        `Paragraph ${index} describes stable history, active live islands, ` +
        `queued follow-ups and anchored transcript scrolling.`,
    );
    if (index % 25 === 0) {
      blocks.push(
        "```ts\n" +
          `export const section${index} = ${index};\n` +
          `console.log(section${index});\n` +
          "```",
      );
    }
  }
  return blocks.join("\n\n");
}

const document = makeDocument();
const deltaSize = 24;
let state = createStreamingMarkdownDocumentState();
let naiveScannedChars = 0;
const incrementalStart = performance.now();
for (let end = deltaSize; end <= document.length + deltaSize; end += deltaSize) {
  const prefix = document.slice(0, Math.min(end, document.length));
  naiveScannedChars += prefix.length;
  state = advanceStreamingMarkdownDocument(state, prefix, true);
}
const incrementalMs = performance.now() - incrementalStart;
state = advanceStreamingMarkdownDocument(state, document, false);

const result = {
  documentChars: document.length,
  deltas: Math.ceil(document.length / deltaSize),
  stableChunks: state.chunks.length,
  appendAwareScannedChars: state.scannedChars,
  naiveScannedChars,
  scannedCharacterReduction: Number(
    (naiveScannedChars / Math.max(1, state.scannedChars)).toFixed(1),
  ),
  incrementalScannerMs: Number(incrementalMs.toFixed(2)),
};
console.log(JSON.stringify(result, null, 2));
