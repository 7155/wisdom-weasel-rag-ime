# Repository instructions

This repository is a clean-room implementation kit, not a replacement Agent runtime.

- Keep `src/core` framework-free and covered by Node tests.
- React components must consume provider-neutral projections.
- Do not add lifecycle facts to GUI-local state.
- Do not fake operation receipts with timers.
- Do not introduce a second queue owner or scroll owner.
- Preserve canonical full text separately from progressive visible text.
- Destructive actions require explicit labels and semantic runtime commands.
- Run `npm run verify` before completing changes.
