import test from "node:test";
import assert from "node:assert/strict";
import {
  advanceMarkdownReveal,
  findSafeMarkdownRevealOffset,
  markdownRevealCeiling,
  remapVisibleOffsetAfterEdit,
} from "../build-test/core/markdown/reveal.js";

test("holds unfinished inline code", () => {
  assert.equal(findSafeMarkdownRevealOffset("Use `unfinished"), 4);
});

test("holds unfinished link destination", () => {
  assert.equal(findSafeMarkdownRevealOffset("See [Claude](htt"), 4);
});

test("holds bare list and heading markers", () => {
  assert.equal(findSafeMarkdownRevealOffset("Text\n-"), 5);
  assert.equal(findSafeMarkdownRevealOffset("Text\n##"), 5);
});

test("does not split a surrogate pair", () => {
  const text = "A😀B";
  const result = advanceMarkdownReveal(text, 0, text.length, 2);
  assert.notEqual(result, 2);
});

test("caps pathological holdback", () => {
  const text = "`" + "x".repeat(2_000);
  assert.ok(markdownRevealCeiling(text, 600) >= text.length - 600);
});

test("CJK text can advance without waiting for spaces", () => {
  const text = "这是一个正在流式输出的中文句子";
  assert.equal(findSafeMarkdownRevealOffset(text), text.length);
});

test("remaps visible offset to common prefix on replacement", () => {
  assert.equal(
    remapVisibleOffsetAfterEdit("hello old world", "hello new world", 8),
    6,
  );
});
