import test from "node:test";
import assert from "node:assert/strict";
import {
  moveQueueRecord,
  projectQueuePresentation,
  reconcileOptimisticQueueRecord,
} from "../build-test/core/interaction/queue.js";
import {
  applyChatOperationEvent,
  projectOperationReceipt,
} from "../build-test/core/interaction/operation.js";

function record(id, status = "queued", preview = id) {
  return {
    id,
    clientSubmitId: `submit-${id}`,
    draft: { text: preview },
    preview,
    attachmentCount: 0,
    createdAt: 1,
    status,
  };
}

test("queue projection distinguishes paused and draining", () => {
  assert.equal(
    projectQueuePresentation({
      records: [record("a")],
      queueStatus: "paused_by_user",
    }).state,
    "paused",
  );
  assert.equal(
    projectQueuePresentation({
      records: [record("a", "draining")],
      queueStatus: "active",
    }).state,
    "draining",
  );
});

test("queue reorder preserves exact identity", () => {
  const moved = moveQueueRecord([record("a"), record("b"), record("c")], "c", "a");
  assert.deepEqual(moved.map((item) => item.id), ["c", "a", "b"]);
});

test("optimistic record reconciles by clientSubmitId, not text", () => {
  const optimistic = record("local", "optimistic", "same text");
  const canonical = {
    ...record("server", "queued", "same text"),
    clientSubmitId: optimistic.clientSubmitId,
  };
  const result = reconcileOptimisticQueueRecord({
    records: [optimistic, record("other", "queued", "same text")],
    clientSubmitId: optimistic.clientSubmitId,
    canonical,
  });
  assert.deepEqual(result.map((item) => item.id), ["server", "other"]);
});

test("operation state advances only through legal canonical events", () => {
  let result = applyChatOperationEvent(null, {
    type: "requested",
    operationId: "op1",
    kind: "interrupt-and-send",
    clientSubmitId: "s1",
    at: 1,
  });
  assert.equal(result.ok, true);
  result = applyChatOperationEvent(result.state, { type: "accepted", at: 2 });
  assert.equal(result.ok, true);
  result = applyChatOperationEvent(result.state, { type: "applying", at: 3 });
  assert.equal(result.ok, true);
  result = applyChatOperationEvent(result.state, { type: "applied", at: 4 });
  assert.equal(result.ok, true);
  assert.equal(projectOperationReceipt(result.state).labelKey, "interrupted-and-sent");
});

test("illegal UI-timer style transition is rejected", () => {
  const started = applyChatOperationEvent(null, {
    type: "requested",
    operationId: "op1",
    kind: "guide-current-turn",
    at: 1,
  });
  const applied = applyChatOperationEvent(started.state, {
    type: "applied",
    at: 2,
  });
  assert.equal(applied.ok, false);
  assert.match(applied.reason, /illegal-transition/);
});

test("outcome unknown disables blind retry", () => {
  const started = applyChatOperationEvent(null, {
    type: "requested",
    operationId: "op1",
    kind: "interrupt-and-send",
    clientSubmitId: "s1",
    at: 1,
  });
  const unknown = applyChatOperationEvent(started.state, {
    type: "outcome-unknown",
    at: 2,
  });
  const receipt = projectOperationReceipt(unknown.state);
  assert.equal(receipt.canRetry, false);
  assert.equal(receipt.labelKey, "outcome-unknown");
});
