import test from "node:test";
import assert from "node:assert/strict";
import {
  captureTranscriptMessageAnchor,
  restoreTranscriptMessageAnchor,
} from "../build-test/core/interaction/messageAnchor.js";
import {
  createFollowEndState,
  reduceFollowEndState,
} from "../build-test/core/interaction/followEnd.js";
import {
  createEmptyDraft,
  DraftVault,
  draftHasContent,
  updateDraft,
} from "../build-test/core/interaction/draft.js";
import {
  buildIsolatedSideContext,
  sideConversationMatchesSource,
} from "../build-test/core/interaction/sideChat.js";
import {
  buildStableTurnRevision,
  stableTurnRenderIdentityEqual,
} from "../build-test/core/interaction/timeline.js";

const rows = [
  { key: "a", top: 0, height: 100 },
  { key: "b", top: 100, height: 120 },
  { key: "c", top: 220, height: 80 },
];

test("captures row key plus pixel offset", () => {
  const anchor = captureTranscriptMessageAnchor({
    conversationId: "c1",
    rows,
    scrollTop: 130,
    layoutRevision: 1,
  });
  assert.ok(anchor);
  assert.equal(anchor.rowKey, "b");
  assert.equal(anchor.offsetFromViewportTopPx, -30);
});

test("restores exact row after earlier heights change", () => {
  const anchor = captureTranscriptMessageAnchor({
    conversationId: "c1",
    rows,
    scrollTop: 130,
    layoutRevision: 1,
  });
  const changed = [
    { key: "a", top: 0, height: 180 },
    { key: "b", top: 180, height: 120 },
    { key: "c", top: 300, height: 80 },
  ];
  const restored = restoreTranscriptMessageAnchor({
    anchor,
    rows: changed,
    maxScrollTop: 500,
  });
  assert.equal(restored.scrollTop, 210);
  assert.equal(restored.source, "row");
});

test("missing row restores nearest successor by remembered index", () => {
  const anchor = captureTranscriptMessageAnchor({
    conversationId: "c1",
    rows,
    scrollTop: 130,
    layoutRevision: 1,
  });
  const restored = restoreTranscriptMessageAnchor({
    anchor,
    rows: [rows[0], rows[2]],
    maxScrollTop: 500,
  });
  assert.equal(restored.source, "nearest-row");
  assert.equal(restored.rowKey, "c");
});

test("detached follow state counts updates without changing anchor", () => {
  const anchor = captureTranscriptMessageAnchor({
    conversationId: "c1",
    rows,
    scrollTop: 130,
    layoutRevision: 1,
  });
  let state = reduceFollowEndState(createFollowEndState(), {
    type: "user-detached",
    anchor,
  });
  state = reduceFollowEndState(state, {
    type: "content-appended",
    updateCount: 3,
  });
  assert.equal(state.mode, "detached");
  assert.equal(state.unseenUpdates, 3);
  assert.equal(state.anchor.rowKey, "b");
  state = reduceFollowEndState(state, { type: "jump-to-latest" });
  assert.equal(state.mode, "following");
  assert.equal(state.unseenUpdates, 0);
});

test("draft vault isolates main and side lanes", () => {
  const vault = new DraftVault();
  vault.set("c1", "main", { text: "main" });
  vault.set("c1", "side", { text: "side" });
  assert.equal(vault.get("c1", "main").text, "main");
  assert.equal(vault.get("c1", "side").text, "side");
});

test("structured draft content includes attachments and references", () => {
  const empty = createEmptyDraft();
  assert.equal(draftHasContent(empty), false);
  const updated = updateDraft(empty, { attachments: [{ id: "a" }] });
  assert.equal(updated.revision, 1);
  assert.equal(draftHasContent(updated), true);
});

test("side context is explicitly read-only relative to main transcript", () => {
  const context = buildIsolatedSideContext({
    mainConversationContext: { turns: 4 },
    sideMessages: [{ role: "user", text: "why?" }],
  });
  assert.match(context.isolationInstruction, /read-only/);
  assert.equal(
    sideConversationMatchesSource(
      {
        sourceConversationId: "c1",
        sideConversationId: "s1",
        status: "idle",
        messages: [],
        draft: "",
      },
      "c1",
    ),
    true,
  );
});

test("stable turn identity ignores unrelated composer state", () => {
  const revision = buildStableTurnRevision({
    turnId: "t1",
    messageVersions: [1, 2],
    toolVersions: [5],
    phase: "done",
    outcome: "success",
  });
  assert.equal(
    stableTurnRenderIdentityEqual(
      { turnId: "t1", revision, active: false },
      { turnId: "t1", revision, active: false },
    ),
    true,
  );
});
