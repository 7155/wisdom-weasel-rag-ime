import test from "node:test";
import assert from "node:assert/strict";
import {
  advanceStreamingMarkdownDocument,
  createStreamingMarkdownDocumentState,
  projectStreamingMarkdownChunks,
} from "../build-test/core/markdown/scanner.js";

function feed(text, sizes = [1, 3, 9, 2, 17]) {
  let state = createStreamingMarkdownDocumentState();
  let end = 0;
  let index = 0;
  while (end < text.length) {
    end = Math.min(text.length, end + sizes[index % sizes.length]);
    state = advanceStreamingMarkdownDocument(state, text.slice(0, end), true);
    index += 1;
  }
  return state;
}

test("freezes completed paragraphs and keeps one active tail", () => {
  const text = "# Title\n\nFirst paragraph.\n\nSecond paragraph is live";
  const state = feed(text);
  const chunks = projectStreamingMarkdownChunks(state, text, true);
  assert.ok(chunks.length >= 2);
  assert.equal(chunks.at(-1).active, true);
  assert.ok(chunks.slice(0, -1).every((chunk) => !chunk.active));
  assert.match(chunks[0].content, /# Title/);
});

test("does not freeze inside an open fenced code block", () => {
  const text = "Before\n\n```ts\nconst x = 1;\n\nconst y = 2;";
  const state = feed(text, [2, 7, 1]);
  const chunks = projectStreamingMarkdownChunks(state, text, true);
  const codeChunk = chunks.find((chunk) => chunk.content.includes("```ts"));
  assert.ok(codeChunk);
  assert.equal(codeChunk.active, true);
  assert.match(codeChunk.content, /const y/);
});

test("closed fence can become a stable chunk", () => {
  const text = "Before\n\n```ts\nconst x = 1;\n```\n\nAfter";
  const state = feed(text);
  const chunks = projectStreamingMarkdownChunks(state, text, true);
  const codeChunk = chunks.find((chunk) => chunk.content.includes("```ts"));
  assert.ok(codeChunk);
  assert.equal(codeChunk.active, false);
});

test("list continuation is not cut at its internal blank line", () => {
  const text = "- first\n\n  continuation\n\nOutside paragraph";
  const state = feed(text);
  const chunks = projectStreamingMarkdownChunks(state, text, true);
  const listChunk = chunks.find((chunk) => chunk.content.startsWith("- first"));
  assert.ok(listChunk);
  assert.match(listChunk.content, /continuation/);
});

test("non-prefix replacement resets safely", () => {
  let state = feed("A paragraph.\n\nSecond paragraph");
  state = advanceStreamingMarkdownDocument(state, "Replacement response", true);
  const chunks = projectStreamingMarkdownChunks(
    state,
    "Replacement response",
    true,
  );
  assert.equal(chunks.length, 1);
  assert.equal(chunks[0].id, 0);
  assert.equal(chunks[0].content, "Replacement response");
  assert.equal(chunks[0].active, true);
});

test("settle preserves existing chunk ids and freezes the tail", () => {
  const text = "One\n\nTwo\n\nThree";
  const streamingState = feed(text);
  const before = projectStreamingMarkdownChunks(streamingState, text, true);
  const settledState = advanceStreamingMarkdownDocument(
    streamingState,
    text,
    false,
  );
  const after = projectStreamingMarkdownChunks(settledState, text, false);
  assert.ok(after.every((chunk) => !chunk.active));
  assert.deepEqual(
    after.slice(0, before.length - 1).map((chunk) => chunk.id),
    before.slice(0, -1).map((chunk) => chunk.id),
  );
  assert.equal(after.at(-1).content, "Three");
});

test("append-aware scanning does substantially less work than full rescans", () => {
  const text = Array.from(
    { length: 500 },
    (_, index) => `## ${index}\n\nParagraph ${index} with some content.`,
  ).join("\n\n");
  let state = createStreamingMarkdownDocumentState();
  let naive = 0;
  for (let end = 16; end <= text.length + 16; end += 16) {
    const prefix = text.slice(0, Math.min(end, text.length));
    naive += prefix.length;
    state = advanceStreamingMarkdownDocument(state, prefix, true);
  }
  assert.ok(state.scannedChars < naive / 20);
});
