import test from "node:test";
import assert from "node:assert/strict";
import {
  buildComposerCommand,
  projectComposerActionModel,
  projectComposerFromRuntime,
} from "../build-test/core/interaction/composer.js";

const draft = {
  text: "hello",
  attachments: [],
  references: [],
  selection: null,
  revision: 1,
};

function runtime(overrides = {}) {
  return {
    conversationId: "c1",
    lane: "main",
    editorStatus: "editable",
    submissionStatus: "ready",
    submissionBlockReason: null,
    activeTurn: null,
    pendingInteraction: null,
    queue: [],
    queueStatus: "active",
    operationSettling: false,
    capabilities: {
      sendNext: true,
      guideCurrentTurn: true,
      interruptAndSend: true,
      stopTurn: true,
      reorderQueue: false,
      sideConversation: true,
      editRetry: true,
      forkThroughTurn: true,
    },
    ...overrides,
  };
}

test("idle composer sends", () => {
  const model = projectComposerFromRuntime(runtime(), true);
  assert.equal(model.mode, "idle");
  assert.equal(model.primary, "send");
  assert.equal(model.primaryDisabled, false);
});

test("busy composer queues and exposes semantic alternatives", () => {
  const model = projectComposerFromRuntime(
    runtime({
      submissionStatus: "queue",
      activeTurn: { id: "t1", status: "running" },
    }),
    true,
  );
  assert.equal(model.primary, "queue");
  assert.deepEqual(model.secondary, [
    "send-next",
    "guide-current-turn",
    "interrupt-and-send",
    "stop",
  ]);
  assert.deepEqual(model.destructive, ["interrupt-and-send", "stop"]);
});

test("pending interaction keeps ordinary draft in queue lane", () => {
  const model = projectComposerActionModel({
    editorStatus: "editable",
    submissionStatus: "queue",
    draftHasContent: true,
    hasActiveTurn: true,
    hasPendingInteraction: true,
    isSettling: false,
    capabilities: {
      sendNext: false,
      guideCurrentTurn: false,
      interruptAndSend: false,
      stopTurn: false,
    },
  });
  assert.equal(model.mode, "interaction");
  assert.equal(model.primary, "queue");
});

test("settling keeps editor editable but blocks primary", () => {
  const model = projectComposerFromRuntime(
    runtime({ operationSettling: true }),
    true,
  );
  assert.equal(model.editorDisabled, false);
  assert.equal(model.primary, "none");
  assert.equal(model.primaryDisabled, true);
});

test("interrupt action creates one atomic semantic command", () => {
  const current = runtime({
    submissionStatus: "queue",
    activeTurn: { id: "t1", status: "running" },
  });
  const model = projectComposerFromRuntime(current, true);
  const result = buildComposerCommand({
    action: "interrupt-and-send",
    model,
    runtime: current,
    draft,
    clientSubmitId: "s1",
  });
  assert.equal(result.ok, true);
  assert.deepEqual(result.command, {
    kind: "interrupt-and-submit",
    conversationId: "c1",
    lane: "main",
    turnId: "t1",
    clientSubmitId: "s1",
    draft,
  });
});

test("unsupported guide cannot be synthesized by GUI", () => {
  const current = runtime({
    submissionStatus: "queue",
    activeTurn: { id: "t1", status: "running" },
    capabilities: {
      ...runtime().capabilities,
      guideCurrentTurn: false,
    },
  });
  const model = projectComposerFromRuntime(current, true);
  const result = buildComposerCommand({
    action: "guide-current-turn",
    model,
    runtime: current,
    draft,
    clientSubmitId: "s1",
  });
  assert.equal(result.ok, false);
  assert.equal(result.reason, "action-not-exposed");
});
