import test from "node:test";
import assert from "node:assert/strict";
import { findOpenFenceTail } from "../build-test/core/markdown/openFence.js";
import { partitionTopLevelNodes } from "../build-test/core/markdown/partition.js";
import { updateIncrementalTokenCache } from "../build-test/core/markdown/tokenizer.js";

test("extracts an open fenced code tail", () => {
  const result = findOpenFenceTail("Intro\n\n```ts\nconst x = 1");
  assert.ok(result);
  assert.equal(result.language, "ts");
  assert.equal(result.markdownBefore, "Intro\n\n");
  assert.equal(result.code, "const x = 1");
});

test("valid closer removes open fence", () => {
  assert.equal(findOpenFenceTail("```js\nx()\n```"), null);
});

test("shorter fence does not close longer opener", () => {
  const result = findOpenFenceTail("````js\nx()\n```");
  assert.ok(result);
  assert.equal(result.markerLength, 4);
});

test("incremental tokenizer reuses unchanged complete lines", () => {
  const counter = { calls: 0 };
  const tokenizer = {
    initialState: 0,
    stateEquals: (a, b) => a === b,
    tokenizeLine(line, stateBefore) {
      counter.calls += 1;
      return {
        tokens: [{ content: line }],
        stateAfter:
          stateBefore +
          (line.match(/\{/g) ?? []).length -
          (line.match(/\}/g) ?? []).length,
      };
    },
  };
  const first = updateIncrementalTokenCache("a\nb\nc\npartial", tokenizer);
  assert.equal(counter.calls, 3);
  counter.calls = 0;
  const second = updateIncrementalTokenCache(
    "a\nb\nc\npartial grows",
    tokenizer,
    first.completeLines,
  );
  assert.equal(counter.calls, 0);
  assert.equal(second.partialLine, "partial grows");
});

test("incremental tokenizer starts at first changed line", () => {
  const counter = { calls: 0 };
  const tokenizer = {
    initialState: null,
    tokenizeLine(line) {
      counter.calls += 1;
      return { tokens: [{ content: line }], stateAfter: null };
    },
  };
  const first = updateIncrementalTokenCache("a\nb\nc\n", tokenizer);
  counter.calls = 0;
  updateIncrementalTokenCache("a\nchanged\nc\n", tokenizer, first.completeLines);
  assert.equal(counter.calls, 1);
});

test("partitions whole-document nodes by source offset", () => {
  const nodes = [
    { name: "a", start: 0 },
    { name: "b", start: 20 },
    { name: "plugin replacement" },
    { name: "c", start: 44 },
  ];
  const groups = partitionTopLevelNodes(nodes, [0, 16, 40], (node) => node.start);
  assert.deepEqual(groups.map((group) => group.map((node) => node.name)), [
    ["a"],
    ["b"],
    ["plugin replacement", "c"],
  ]);
});
