import { useCallback, useMemo, useState, type ReactNode } from "react";
import {
  AgentComposer,
  ConversationBottomDock,
  ConversationSurface,
  IncrementalCodeBlock,
  JumpToLatestButton,
  QueuePanel,
  SideConversationPane,
  StreamingMarkdown,
  buildComposerCommand,
  createClientSubmitId,
  draftHasContent,
  projectComposerFromRuntime,
  type ChatDraftSnapshot,
  type ChatRuntimeAdapter,
  type ChatRuntimeSnapshot,
  type ChatSemanticCommand,
  type ComposerAction,
} from "../src/index.js";

type Draft = ChatDraftSnapshot<{ id: string; name: string }, { id: string }>;
type Snapshot = ChatRuntimeSnapshot<Draft>;
type Command = ChatSemanticCommand<Draft>;

/** Replace this with PAW's existing AgentMessageMarkdown renderer. */
function ExistingMarkdownRenderer({ source }: { source: string }): ReactNode {
  return <div style={{ whiteSpace: "pre-wrap" }}>{source}</div>;
}

export function PawConversationIntegration({
  runtime,
  transcript,
  sideTranscript,
  sideOpen,
  onCloseSide,
  unseenUpdates,
  onJumpToLatest,
}: {
  runtime: ChatRuntimeAdapter<Snapshot, Command>;
  transcript: ReactNode;
  sideTranscript?: ReactNode;
  sideOpen: boolean;
  onCloseSide(): void;
  unseenUpdates: number;
  onJumpToLatest(): void;
}): ReactNode {
  const snapshot = runtime.getSnapshot();
  const [draft, setDraft] = useState<Draft>({
    text: "",
    attachments: [],
    references: [],
    selection: null,
    revision: 0,
  });
  const actionModel = useMemo(
    () => projectComposerFromRuntime(snapshot, draftHasContent(draft)),
    [draft, snapshot],
  );

  const executeAction = useCallback(
    async (action: Exclude<ComposerAction, "none">) => {
      const projected = buildComposerCommand({
        action,
        model: actionModel,
        runtime: snapshot,
        draft,
        clientSubmitId: createClientSubmitId(),
      });
      if (!projected.ok) return;
      const result = await runtime.execute(projected.command);
      if (result.accepted) {
        setDraft((previous) => ({
          ...previous,
          text: "",
          attachments: [],
          references: [],
          revision: previous.revision + 1,
        }));
      }
      // Rejected/outcome-unknown: keep exact draft snapshot and let PAW's
      // canonical settlement/recovery projection decide what to show.
    },
    [actionModel, draft, runtime, snapshot],
  );

  const queue = (
    <QueuePanel
      records={snapshot.queue}
      queueStatus={snapshot.queueStatus}
      labels={{
        queued: (count) => `${count} queued`,
        paused: (count) => `Queue paused · ${count} waiting`,
        draining: (count) => `Sending · ${count} queued`,
        next: "Next:",
        attachment: "Attachment",
        empty: "Empty message",
        expand: "Expand queued messages",
        collapse: "Collapse queued messages",
        sendNow: "Send next",
        edit: "Edit",
        remove: "Remove",
        clear: "Clear queue",
        moveUp: "Move up",
        moveDown: "Move down",
        failed: "Failed",
      }}
      onSendNow={async (queueId) => {
        await runtime.execute({
          kind: "queue-send-now",
          conversationId: snapshot.conversationId,
          lane: snapshot.lane,
          queueId,
        });
      }}
      onEdit={async (record) => {
        setDraft(record.draft);
        await runtime.execute({
          kind: "queue-restore-to-draft",
          conversationId: snapshot.conversationId,
          lane: snapshot.lane,
          queueId: record.id,
        });
      }}
      onRemove={async (queueId) => {
        await runtime.execute({
          kind: "queue-remove",
          conversationId: snapshot.conversationId,
          lane: snapshot.lane,
          queueId,
        });
      }}
    />
  );

  const composer = (
    <AgentComposer
      value={draft.text}
      onChange={(text) =>
        setDraft((previous) => ({
          ...previous,
          text,
          revision: previous.revision + 1,
        }))
      }
      model={actionModel}
      labels={{
        send: "Send",
        queue: "Add to queue",
        "answer-interaction": "Answer above",
        "send-next": "Send next",
        "guide-current-turn": "Guide current turn",
        "interrupt-and-send": "Interrupt and send",
        stop: "Stop current turn",
        moreActions: "More send actions",
        settling: "Confirming operation…",
      }}
      placeholder="Reply at any time, even while the agent is working…"
      ariaLabel="Message"
      onAction={executeAction}
      confirmDestructive={(action) =>
        action === "interrupt-and-send"
          ? window.confirm("Interrupt the current turn and send this message?")
          : window.confirm("Stop the current turn?")
      }
    />
  );

  return (
    <ConversationSurface
      transcript={transcript}
      overlay={
        <JumpToLatestButton
          unseenUpdates={unseenUpdates}
          label={(count) => `${count} new updates`}
          onClick={onJumpToLatest}
        />
      }
      bottomDock={
        <ConversationBottomDock queue={queue} composer={composer} />
      }
      sideConversation={
        <SideConversationPane
          open={sideOpen}
          status="idle"
          title="Side chat"
          isolationDescription="Uses this conversation as context · Not added to the main thread"
          closeLabel="Close side chat"
          onClose={onCloseSide}
        >
          {sideTranscript}
        </SideConversationPane>
      }
    />
  );
}

export function AssistantMarkdownExample({
  text,
  streaming,
}: {
  text: string;
  streaming: boolean;
}): ReactNode {
  return (
    <StreamingMarkdown
      canonicalText={text}
      streaming={streaming}
      renderMarkdown={(source) => <ExistingMarkdownRenderer source={source} />}
      renderLiveCode={(code, context) => (
        <IncrementalCodeBlock
          code={code}
          language={context.language}
          streaming
        />
      )}
    />
  );
}
