export interface StableTurnRenderIdentity {
  turnId: string;
  revision: string;
  active: boolean;
}

export function stableTurnRenderIdentityEqual(
  previous: StableTurnRenderIdentity,
  next: StableTurnRenderIdentity,
): boolean {
  return (
    previous.turnId === next.turnId &&
    previous.revision === next.revision &&
    previous.active === next.active
  );
}

export function buildStableTurnRevision(input: {
  turnId: string;
  messageVersions: readonly (string | number)[];
  toolVersions: readonly (string | number)[];
  phase: string | null;
  outcome: string | null;
}): string {
  return [
    input.turnId,
    input.phase ?? "",
    input.outcome ?? "",
    input.messageVersions.join(","),
    input.toolVersions.join(","),
  ].join("|");
}

export type TimelineRenderItem<StableTurn, ActiveTurn> =
  | {
      key: string;
      kind: "stable-turn";
      revision: string;
      turn: StableTurn;
    }
  | {
      key: string;
      kind: "active-turn";
      revision: string;
      turn: ActiveTurn;
    };

export function projectTimelineItems<Turn>(input: {
  turns: readonly Turn[];
  getTurnId(turn: Turn): string;
  getRevision(turn: Turn): string;
  isActive(turn: Turn): boolean;
}): readonly TimelineRenderItem<Turn, Turn>[] {
  return input.turns.map((turn) => {
    const key = input.getTurnId(turn);
    const revision = input.getRevision(turn);
    return input.isActive(turn)
      ? { key, kind: "active-turn", revision, turn }
      : { key, kind: "stable-turn", revision, turn };
  });
}
