export type ChatOperationKind =
  | "queue"
  | "send-next"
  | "guide-current-turn"
  | "interrupt-and-send"
  | "stop";

export type ChatOperationStatus =
  | "requested"
  | "accepted"
  | "applying"
  | "applied"
  | "outcome-unknown"
  | "failed"
  | "rejected";

export interface ChatOperationState {
  operationId: string;
  kind: ChatOperationKind;
  status: ChatOperationStatus;
  clientSubmitId?: string;
  createdAt: number;
  updatedAt: number;
  errorCode?: string;
  errorMessage?: string;
}

export type ChatOperationEvent =
  | {
      type: "requested";
      operationId: string;
      kind: ChatOperationKind;
      clientSubmitId?: string;
      at: number;
    }
  | { type: "accepted"; at: number }
  | { type: "applying"; at: number }
  | { type: "applied"; at: number }
  | { type: "outcome-unknown"; at: number; errorMessage?: string }
  | { type: "failed"; at: number; errorCode?: string; errorMessage?: string }
  | { type: "rejected"; at: number; errorCode?: string; errorMessage?: string };

const LEGAL_TRANSITIONS: Readonly<
  Record<ChatOperationStatus, readonly ChatOperationStatus[]>
> = {
  requested: ["accepted", "rejected", "failed", "outcome-unknown"],
  accepted: ["applying", "applied", "failed", "outcome-unknown"],
  applying: ["applied", "failed", "outcome-unknown"],
  applied: [],
  "outcome-unknown": ["applied", "failed"],
  failed: [],
  rejected: [],
};

export type OperationTransitionResult =
  | { ok: true; state: ChatOperationState }
  | { ok: false; reason: string; state: ChatOperationState | null };

/** Status only changes in response to canonical events, never UI timers. */
export function applyChatOperationEvent(
  previous: ChatOperationState | null,
  event: ChatOperationEvent,
): OperationTransitionResult {
  if (event.type === "requested") {
    if (previous) return { ok: false, reason: "already-started", state: previous };
    return {
      ok: true,
      state: {
        operationId: event.operationId,
        kind: event.kind,
        status: "requested",
        clientSubmitId: event.clientSubmitId,
        createdAt: event.at,
        updatedAt: event.at,
      },
    };
  }
  if (!previous) return { ok: false, reason: "operation-not-started", state: null };

  const nextStatus = event.type;
  if (!LEGAL_TRANSITIONS[previous.status].includes(nextStatus)) {
    return {
      ok: false,
      reason: `illegal-transition:${previous.status}->${nextStatus}`,
      state: previous,
    };
  }
  return {
    ok: true,
    state: {
      ...previous,
      status: nextStatus,
      updatedAt: event.at,
      errorCode: "errorCode" in event ? event.errorCode : previous.errorCode,
      errorMessage:
        "errorMessage" in event ? event.errorMessage : previous.errorMessage,
    },
  };
}

export interface OperationReceiptModel {
  visible: boolean;
  tone: "neutral" | "progress" | "success" | "warning" | "error";
  labelKey:
    | "queued"
    | "delivering"
    | "applied"
    | "interrupting"
    | "interrupted-and-sent"
    | "stopping"
    | "outcome-unknown"
    | "failed"
    | "rejected";
  canRetry: boolean;
  canCancelAndEdit: boolean;
}

export function projectOperationReceipt(
  operation: ChatOperationState,
): OperationReceiptModel {
  if (operation.status === "failed") {
    return {
      visible: true,
      tone: "error",
      labelKey: "failed",
      canRetry: true,
      canCancelAndEdit: Boolean(operation.clientSubmitId),
    };
  }
  if (operation.status === "rejected") {
    return {
      visible: true,
      tone: "warning",
      labelKey: "rejected",
      canRetry: true,
      canCancelAndEdit: Boolean(operation.clientSubmitId),
    };
  }
  if (operation.status === "outcome-unknown") {
    return {
      visible: true,
      tone: "warning",
      labelKey: "outcome-unknown",
      canRetry: false,
      canCancelAndEdit: false,
    };
  }
  if (operation.status === "applied") {
    return {
      visible: true,
      tone: "success",
      labelKey:
        operation.kind === "interrupt-and-send"
          ? "interrupted-and-sent"
          : operation.kind === "guide-current-turn"
            ? "applied"
            : "queued",
      canRetry: false,
      canCancelAndEdit: false,
    };
  }
  return {
    visible: true,
    tone: "progress",
    labelKey:
      operation.kind === "interrupt-and-send"
        ? "interrupting"
        : operation.kind === "stop"
          ? "stopping"
          : operation.status === "requested"
            ? "queued"
            : "delivering",
    canRetry: false,
    canCancelAndEdit:
      operation.status === "requested" && Boolean(operation.clientSubmitId),
  };
}
