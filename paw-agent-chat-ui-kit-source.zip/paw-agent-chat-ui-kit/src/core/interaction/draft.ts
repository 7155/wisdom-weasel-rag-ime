import type { ChatDraftSnapshot, ConversationLane } from "./runtime.js";

export function draftHasContent<Attachment, Reference>(
  draft: ChatDraftSnapshot<Attachment, Reference>,
): boolean {
  return (
    draft.text.trim().length > 0 ||
    draft.attachments.length > 0 ||
    draft.references.length > 0
  );
}

export function createEmptyDraft<Attachment = never, Reference = never>(): ChatDraftSnapshot<
  Attachment,
  Reference
> {
  return {
    text: "",
    attachments: [],
    references: [],
    selection: null,
    revision: 0,
  };
}

export function updateDraft<Attachment, Reference>(
  previous: ChatDraftSnapshot<Attachment, Reference>,
  patch: Partial<Omit<ChatDraftSnapshot<Attachment, Reference>, "revision">>,
): ChatDraftSnapshot<Attachment, Reference> {
  return {
    ...previous,
    ...patch,
    revision: previous.revision + 1,
  };
}

function draftKey(conversationId: string, lane: ConversationLane): string {
  return `${conversationId}\u0000${lane}`;
}

/** Exact session/lane-scoped draft snapshots; main and side never share state. */
export class DraftVault<Draft> {
  readonly #drafts = new Map<string, Draft>();

  get(conversationId: string, lane: ConversationLane): Draft | undefined {
    return this.#drafts.get(draftKey(conversationId, lane));
  }

  set(conversationId: string, lane: ConversationLane, draft: Draft): void {
    this.#drafts.set(draftKey(conversationId, lane), draft);
  }

  delete(conversationId: string, lane: ConversationLane): boolean {
    return this.#drafts.delete(draftKey(conversationId, lane));
  }

  clear(): void {
    this.#drafts.clear();
  }
}
