import type { TranscriptMessageAnchor } from "./messageAnchor.js";

export interface FollowEndState {
  mode: "following" | "detached";
  unseenUpdates: number;
  anchor: TranscriptMessageAnchor | null;
  detachedReason: "user-scroll" | "selection" | "restored" | null;
}

export type FollowEndEvent =
  | { type: "content-appended"; updateCount?: number }
  | { type: "layout-changed" }
  | {
      type: "user-detached";
      anchor: TranscriptMessageAnchor | null;
      reason?: "user-scroll" | "selection";
    }
  | { type: "anchor-updated"; anchor: TranscriptMessageAnchor | null }
  | { type: "jump-to-latest" }
  | { type: "prompt-submitted" }
  | {
      type: "conversation-restored";
      mode: "following" | "detached";
      anchor?: TranscriptMessageAnchor | null;
    };

export function createFollowEndState(
  mode: "following" | "detached" = "following",
): FollowEndState {
  return {
    mode,
    unseenUpdates: 0,
    anchor: null,
    detachedReason: mode === "detached" ? "restored" : null,
  };
}

export function reduceFollowEndState(
  state: FollowEndState,
  event: FollowEndEvent,
): FollowEndState {
  switch (event.type) {
    case "content-appended":
      return state.mode === "following"
        ? state
        : {
            ...state,
            unseenUpdates:
              state.unseenUpdates + Math.max(1, event.updateCount ?? 1),
          };
    case "layout-changed":
      return state;
    case "user-detached":
      return {
        mode: "detached",
        unseenUpdates: state.unseenUpdates,
        anchor: event.anchor,
        detachedReason: event.reason ?? "user-scroll",
      };
    case "anchor-updated":
      return state.mode === "detached" ? { ...state, anchor: event.anchor } : state;
    case "jump-to-latest":
    case "prompt-submitted":
      return createFollowEndState("following");
    case "conversation-restored":
      return {
        mode: event.mode,
        unseenUpdates: 0,
        anchor: event.anchor ?? null,
        detachedReason: event.mode === "detached" ? "restored" : null,
      };
  }
}

export function shouldAutoFollow(state: FollowEndState): boolean {
  return state.mode === "following";
}
