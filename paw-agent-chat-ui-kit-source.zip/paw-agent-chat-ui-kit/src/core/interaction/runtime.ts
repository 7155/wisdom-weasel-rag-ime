export type ConversationLane = "main" | "side";

export interface DraftSelection {
  start: number;
  end: number;
  direction?: "forward" | "backward" | "none";
}

export interface ChatDraftSnapshot<Attachment = unknown, Reference = unknown> {
  text: string;
  attachments: readonly Attachment[];
  references: readonly Reference[];
  selection: DraftSelection | null;
  revision: number;
}

export interface ChatCapabilities {
  sendNext: boolean;
  guideCurrentTurn: boolean;
  interruptAndSend: boolean;
  stopTurn: boolean;
  reorderQueue: boolean;
  sideConversation: boolean;
  editRetry: boolean;
  forkThroughTurn: boolean;
}

export interface PendingInteractionSnapshot<Payload = unknown> {
  id: string;
  kind: "approval" | "question" | "permission" | "custom";
  payload: Payload;
}

export interface ActiveTurnSnapshot {
  id: string;
  status: "starting" | "running" | "waiting-tool" | "stopping" | "unknown";
}

export interface RuntimeQueueRecord<Draft> {
  id: string;
  clientSubmitId: string;
  draft: Draft;
  preview: string;
  attachmentCount: number;
  createdAt: number;
  status: "optimistic" | "queued" | "draining" | "failed";
  error?: string;
}

export interface ChatRuntimeSnapshot<
  Draft,
  InteractionPayload = unknown,
> {
  conversationId: string;
  lane: ConversationLane;
  editorStatus: "editable" | "blocked";
  submissionStatus: "ready" | "queue" | "blocked";
  submissionBlockReason: string | null;
  activeTurn: ActiveTurnSnapshot | null;
  pendingInteraction: PendingInteractionSnapshot<InteractionPayload> | null;
  queue: readonly RuntimeQueueRecord<Draft>[];
  queueStatus: "active" | "paused_by_user";
  operationSettling: boolean;
  capabilities: ChatCapabilities;
}

export type ChatSemanticCommand<Draft, InteractionAnswer = unknown> =
  | {
      kind: "submit";
      conversationId: string;
      lane: ConversationLane;
      routing: "normal" | "queue" | "send-next";
      clientSubmitId: string;
      draft: Draft;
    }
  | {
      kind: "guide-current-turn";
      conversationId: string;
      lane: ConversationLane;
      turnId: string;
      clientSubmitId: string;
      draft: Draft;
    }
  | {
      kind: "interrupt-and-submit";
      conversationId: string;
      lane: ConversationLane;
      turnId: string;
      clientSubmitId: string;
      draft: Draft;
    }
  | {
      kind: "stop-turn";
      conversationId: string;
      lane: ConversationLane;
      turnId: string;
    }
  | {
      kind: "answer-interaction";
      conversationId: string;
      lane: ConversationLane;
      interactionId: string;
      answer: InteractionAnswer;
    }
  | {
      kind: "queue-send-now";
      conversationId: string;
      lane: ConversationLane;
      queueId: string;
    }
  | {
      kind: "queue-remove";
      conversationId: string;
      lane: ConversationLane;
      queueId: string;
    }
  | {
      kind: "queue-restore-to-draft";
      conversationId: string;
      lane: ConversationLane;
      queueId: string;
    }
  | {
      kind: "queue-move";
      conversationId: string;
      lane: ConversationLane;
      queueId: string;
      beforeQueueId: string | null;
    }
  | {
      kind: "queue-clear";
      conversationId: string;
      lane: ConversationLane;
    };

export interface ChatCommandResult {
  accepted: boolean;
  operationId?: string;
  clientSubmitId?: string;
  errorCode?: string;
  errorMessage?: string;
  outcomeUnknown?: boolean;
}

export interface ChatRuntimeAdapter<
  Snapshot,
  Command,
> {
  getSnapshot(): Snapshot;
  getServerSnapshot?(): Snapshot;
  subscribe(listener: () => void): () => void;
  execute(command: Command): Promise<ChatCommandResult>;
}

export function createClientSubmitId(prefix = "chat"): string {
  const random =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`;
  return `${prefix}-${random}`;
}
