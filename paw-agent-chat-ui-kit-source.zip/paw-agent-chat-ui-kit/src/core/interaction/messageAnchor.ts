export interface TranscriptRowGeometry {
  key: string;
  top: number;
  height: number;
}

export interface TranscriptMessageAnchor {
  conversationId: string;
  rowKey: string;
  rowIndex: number;
  offsetFromViewportTopPx: number;
  fallbackScrollTop: number;
  layoutRevision: number;
}

export function captureTranscriptMessageAnchor(input: {
  conversationId: string;
  rows: readonly TranscriptRowGeometry[];
  scrollTop: number;
  viewportTopInset?: number;
  layoutRevision: number;
}): TranscriptMessageAnchor | null {
  const viewportLine = input.scrollTop + (input.viewportTopInset ?? 0);
  const rowIndex = input.rows.findIndex(
    (candidate) => candidate.top + candidate.height > viewportLine,
  );
  if (rowIndex < 0) return null;
  const row = input.rows[rowIndex]!;
  return {
    conversationId: input.conversationId,
    rowKey: row.key,
    rowIndex,
    offsetFromViewportTopPx: row.top - input.scrollTop,
    fallbackScrollTop: input.scrollTop,
    layoutRevision: input.layoutRevision,
  };
}

export function restoreTranscriptMessageAnchor(input: {
  anchor: TranscriptMessageAnchor;
  rows: readonly TranscriptRowGeometry[];
  maxScrollTop: number;
}): {
  scrollTop: number;
  source: "row" | "nearest-row" | "fallback";
  rowKey: string | null;
} {
  const exact = input.rows.find((candidate) => candidate.key === input.anchor.rowKey);
  const nearest =
    exact ??
    (input.rows.length > 0
      ? input.rows[
          Math.max(0, Math.min(input.anchor.rowIndex, input.rows.length - 1))
        ]
      : undefined);
  const raw = nearest
    ? nearest.top - input.anchor.offsetFromViewportTopPx
    : input.anchor.fallbackScrollTop;
  return {
    scrollTop: Math.max(0, Math.min(input.maxScrollTop, raw)),
    source: exact ? "row" : nearest ? "nearest-row" : "fallback",
    rowKey: nearest?.key ?? null,
  };
}
