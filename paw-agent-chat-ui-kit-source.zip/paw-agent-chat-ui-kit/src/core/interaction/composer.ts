import type {
  ChatDraftSnapshot,
  ChatRuntimeSnapshot,
  ChatSemanticCommand,
} from "./runtime.js";

export type ComposerPrimaryAction =
  | "none"
  | "send"
  | "queue"
  | "answer-interaction";

export type ComposerSecondaryAction =
  | "send-next"
  | "guide-current-turn"
  | "interrupt-and-send"
  | "stop";

export type ComposerAction = ComposerPrimaryAction | ComposerSecondaryAction;

export interface ComposerActionModelInput {
  editorStatus: "editable" | "blocked";
  submissionStatus: "ready" | "queue" | "blocked";
  submissionBlockReason?: string | null;
  draftHasContent: boolean;
  hasActiveTurn: boolean;
  hasPendingInteraction: boolean;
  isSettling: boolean;
  capabilities: {
    sendNext: boolean;
    guideCurrentTurn: boolean;
    interruptAndSend: boolean;
    stopTurn: boolean;
  };
}

export interface ComposerActionModel {
  editorDisabled: boolean;
  primary: ComposerPrimaryAction;
  primaryDisabled: boolean;
  secondary: readonly ComposerSecondaryAction[];
  destructive: readonly ComposerSecondaryAction[];
  mode: "hard-blocked" | "idle" | "busy" | "interaction" | "settling";
  reason: string | null;
}

export function projectComposerActionModel(
  input: ComposerActionModelInput,
): ComposerActionModel {
  if (input.editorStatus === "blocked") {
    return {
      editorDisabled: true,
      primary: "none",
      primaryDisabled: true,
      secondary: [],
      destructive: [],
      mode: "hard-blocked",
      reason: input.submissionBlockReason ?? "editor-blocked",
    };
  }

  const secondary: ComposerSecondaryAction[] = [];
  if (input.hasActiveTurn && input.capabilities.sendNext) {
    secondary.push("send-next");
  }
  if (input.hasActiveTurn && input.capabilities.guideCurrentTurn) {
    secondary.push("guide-current-turn");
  }
  if (input.hasActiveTurn && input.capabilities.interruptAndSend) {
    secondary.push("interrupt-and-send");
  }
  if (input.hasActiveTurn && input.capabilities.stopTurn) secondary.push("stop");
  const destructive = secondary.filter(
    (action) => action === "interrupt-and-send" || action === "stop",
  );

  if (input.isSettling) {
    return {
      editorDisabled: false,
      primary: "none",
      primaryDisabled: true,
      secondary,
      destructive,
      mode: "settling",
      reason: "operation-settling",
    };
  }

  if (input.hasPendingInteraction) {
    return {
      editorDisabled: false,
      primary: input.draftHasContent ? "queue" : "answer-interaction",
      primaryDisabled:
        input.draftHasContent && input.submissionStatus !== "queue",
      secondary,
      destructive,
      mode: "interaction",
      reason:
        input.submissionStatus === "blocked"
          ? input.submissionBlockReason ?? "submission-blocked"
          : null,
    };
  }

  if (input.hasActiveTurn || input.submissionStatus === "queue") {
    return {
      editorDisabled: false,
      primary: "queue",
      primaryDisabled:
        !input.draftHasContent || input.submissionStatus === "blocked",
      secondary,
      destructive,
      mode: "busy",
      reason:
        input.submissionStatus === "blocked"
          ? input.submissionBlockReason ?? "submission-blocked"
          : null,
    };
  }

  return {
    editorDisabled: false,
    primary: "send",
    primaryDisabled:
      !input.draftHasContent || input.submissionStatus !== "ready",
    secondary,
    destructive,
    mode: "idle",
    reason:
      input.submissionStatus === "blocked"
        ? input.submissionBlockReason ?? "submission-blocked"
        : null,
  };
}

export function projectComposerFromRuntime<Draft, InteractionPayload>(
  runtime: ChatRuntimeSnapshot<Draft, InteractionPayload>,
  draftHasContent: boolean,
): ComposerActionModel {
  return projectComposerActionModel({
    editorStatus: runtime.editorStatus,
    submissionStatus: runtime.submissionStatus,
    submissionBlockReason: runtime.submissionBlockReason,
    draftHasContent,
    hasActiveTurn: runtime.activeTurn !== null,
    hasPendingInteraction: runtime.pendingInteraction !== null,
    isSettling: runtime.operationSettling,
    capabilities: {
      sendNext: runtime.capabilities.sendNext,
      guideCurrentTurn: runtime.capabilities.guideCurrentTurn,
      interruptAndSend: runtime.capabilities.interruptAndSend,
      stopTurn: runtime.capabilities.stopTurn,
    },
  });
}

export type CommandProjectionResult<Draft, Answer> =
  | { ok: true; command: ChatSemanticCommand<Draft, Answer> }
  | { ok: false; reason: string };

/**
 * Translate a visible UI action into one provider-neutral semantic command.
 * The GUI never implements cancel-then-timeout-send itself.
 */
export function buildComposerCommand<
  Attachment,
  Reference,
  Answer = unknown,
>(input: {
  action: ComposerAction;
  model: ComposerActionModel;
  runtime: ChatRuntimeSnapshot<
    ChatDraftSnapshot<Attachment, Reference>,
    unknown
  >;
  draft: ChatDraftSnapshot<Attachment, Reference>;
  clientSubmitId: string;
  interactionAnswer?: Answer;
}): CommandProjectionResult<ChatDraftSnapshot<Attachment, Reference>, Answer> {
  const { action, model, runtime, draft, clientSubmitId } = input;
  if (action === "none") return { ok: false, reason: "no-action" };
  if (action === model.primary && model.primaryDisabled) {
    return { ok: false, reason: model.reason ?? "primary-disabled" };
  }
  if (
    action !== model.primary &&
    !model.secondary.includes(action as ComposerSecondaryAction)
  ) {
    return { ok: false, reason: "action-not-exposed" };
  }

  const common = {
    conversationId: runtime.conversationId,
    lane: runtime.lane,
  } as const;

  switch (action) {
    case "send":
      return {
        ok: true,
        command: {
          ...common,
          kind: "submit",
          routing: "normal",
          clientSubmitId,
          draft,
        },
      };
    case "queue":
      return {
        ok: true,
        command: {
          ...common,
          kind: "submit",
          routing: "queue",
          clientSubmitId,
          draft,
        },
      };
    case "send-next":
      return {
        ok: true,
        command: {
          ...common,
          kind: "submit",
          routing: "send-next",
          clientSubmitId,
          draft,
        },
      };
    case "guide-current-turn":
      return runtime.activeTurn && runtime.capabilities.guideCurrentTurn
        ? {
            ok: true,
            command: {
              ...common,
              kind: "guide-current-turn",
              turnId: runtime.activeTurn.id,
              clientSubmitId,
              draft,
            },
          }
        : { ok: false, reason: "guide-not-supported" };
    case "interrupt-and-send":
      return runtime.activeTurn && runtime.capabilities.interruptAndSend
        ? {
            ok: true,
            command: {
              ...common,
              kind: "interrupt-and-submit",
              turnId: runtime.activeTurn.id,
              clientSubmitId,
              draft,
            },
          }
        : { ok: false, reason: "interrupt-not-supported" };
    case "stop":
      return runtime.activeTurn && runtime.capabilities.stopTurn
        ? {
            ok: true,
            command: {
              ...common,
              kind: "stop-turn",
              turnId: runtime.activeTurn.id,
            },
          }
        : { ok: false, reason: "stop-not-supported" };
    case "answer-interaction":
      return runtime.pendingInteraction && input.interactionAnswer !== undefined
        ? {
            ok: true,
            command: {
              ...common,
              kind: "answer-interaction",
              interactionId: runtime.pendingInteraction.id,
              answer: input.interactionAnswer,
            },
          }
        : { ok: false, reason: "interaction-answer-missing" };
  }
}
