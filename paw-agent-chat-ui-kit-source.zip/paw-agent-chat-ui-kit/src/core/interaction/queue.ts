import type { RuntimeQueueRecord } from "./runtime.js";

export interface QueuePresentationModel {
  visible: boolean;
  expandable: boolean;
  state: "active" | "paused" | "draining";
  count: number;
  preview: string;
  previewFallback: "attachment" | "empty" | null;
}

export function projectQueuePresentation<Draft>(input: {
  records: readonly RuntimeQueueRecord<Draft>[];
  queueStatus: "active" | "paused_by_user";
}): QueuePresentationModel {
  const records = input.records;
  const next = records[0];
  const preview = next?.preview.replace(/\s+/g, " ").trim() ?? "";
  const draining = records.some((record) => record.status === "draining");
  return {
    visible: records.length > 0,
    expandable:
      records.length > 1 ||
      Boolean(next && next.attachmentCount > 0) ||
      preview.length > 80,
    state: draining
      ? "draining"
      : input.queueStatus === "paused_by_user"
        ? "paused"
        : "active",
    count: records.length,
    preview,
    previewFallback: preview
      ? null
      : next && next.attachmentCount > 0
        ? "attachment"
        : "empty",
  };
}

export function moveQueueRecord<Draft>(
  records: readonly RuntimeQueueRecord<Draft>[],
  queueId: string,
  beforeQueueId: string | null,
): readonly RuntimeQueueRecord<Draft>[] {
  const moving = records.find((record) => record.id === queueId);
  if (!moving) return records;
  const rest = records.filter((record) => record.id !== queueId);
  if (beforeQueueId === null) return [...rest, moving];
  const index = rest.findIndex((record) => record.id === beforeQueueId);
  if (index < 0) return [...rest, moving];
  const next = [...rest];
  next.splice(index, 0, moving);
  return next;
}

export function reconcileOptimisticQueueRecord<Draft>(input: {
  records: readonly RuntimeQueueRecord<Draft>[];
  clientSubmitId: string;
  canonical: RuntimeQueueRecord<Draft>;
}): readonly RuntimeQueueRecord<Draft>[] {
  const index = input.records.findIndex(
    (record) => record.clientSubmitId === input.clientSubmitId,
  );
  if (index < 0) return [...input.records, input.canonical];
  const next = [...input.records];
  next[index] = input.canonical;
  return next;
}

export function queueRecordCanMutate<Draft>(
  record: RuntimeQueueRecord<Draft>,
): boolean {
  return record.status === "queued" || record.status === "failed";
}
