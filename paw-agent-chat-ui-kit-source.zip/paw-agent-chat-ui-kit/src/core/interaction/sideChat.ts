export type SideConversationStatus =
  | "closed"
  | "opening"
  | "idle"
  | "running"
  | "pending-interaction"
  | "closing"
  | "error";

export interface SideConversationProjection<Message, Draft> {
  sourceConversationId: string;
  sideConversationId: string | null;
  status: SideConversationStatus;
  messages: readonly Message[];
  draft: Draft;
  errorMessage?: string;
}

export function sideConversationMatchesSource<Message, Draft>(
  side: SideConversationProjection<Message, Draft>,
  currentConversationId: string,
): boolean {
  return side.sourceConversationId === currentConversationId;
}

export function buildIsolatedSideContext<MainContext, SideMessage>(input: {
  mainConversationContext: MainContext;
  sideMessages: readonly SideMessage[];
}): {
  mainConversationContext: MainContext;
  sideMessages: readonly SideMessage[];
  isolationInstruction: string;
} {
  return {
    mainConversationContext: input.mainConversationContext,
    sideMessages: input.sideMessages,
    isolationInstruction:
      "Use the main conversation as read-only context. Reply only in the side conversation and do not mutate the main transcript.",
  };
}
