export interface AgentChatPerformanceSample {
  name: string;
  durationMs: number;
  fields: Readonly<Record<string, string | number | boolean | null>>;
}

export type AgentChatTelemetrySink = (
  sample: AgentChatPerformanceSample,
) => void;

export function measureAgentChatOperation<T>(
  name: string,
  fields: AgentChatPerformanceSample["fields"],
  operation: () => T,
  sink: AgentChatTelemetrySink,
): T {
  const start = performance.now();
  try {
    return operation();
  } finally {
    sink({ name, durationMs: performance.now() - start, fields });
  }
}

export async function measureAgentChatOperationAsync<T>(
  name: string,
  fields: AgentChatPerformanceSample["fields"],
  operation: () => Promise<T>,
  sink: AgentChatTelemetrySink,
): Promise<T> {
  const start = performance.now();
  try {
    return await operation();
  } finally {
    sink({ name, durationMs: performance.now() - start, fields });
  }
}

export function messageLengthBucket(length: number): string {
  if (length < 1_000) return "<1k";
  if (length < 10_000) return "1k-10k";
  if (length < 50_000) return "10k-50k";
  if (length < 100_000) return "50k-100k";
  return "100k+";
}

export interface ChatPerformanceMarker {
  mark(name: string): void;
  measure(
    name: string,
    startMark: string,
    endMark: string,
    fields?: AgentChatPerformanceSample["fields"],
  ): AgentChatPerformanceSample | null;
}

export function createChatPerformanceMarker(
  sink: AgentChatTelemetrySink,
): ChatPerformanceMarker {
  return {
    mark(name) {
      if (typeof performance !== "undefined") performance.mark(name);
    },
    measure(name, startMark, endMark, fields = {}) {
      if (typeof performance === "undefined") return null;
      try {
        performance.measure(name, startMark, endMark);
        const entries = performance.getEntriesByName(name, "measure");
        const entry = entries.at(-1);
        if (!entry) return null;
        const sample = { name, durationMs: entry.duration, fields };
        sink(sample);
        return sample;
      } catch {
        return null;
      }
    },
  };
}

export interface LongTaskObserverHandle {
  disconnect(): void;
}

/** Browser-only optional diagnostic. Unsupported browsers return a no-op. */
export function observeAgentChatLongTasks(
  sink: AgentChatTelemetrySink,
  fields: AgentChatPerformanceSample["fields"] = {},
): LongTaskObserverHandle {
  if (
    typeof PerformanceObserver === "undefined" ||
    !PerformanceObserver.supportedEntryTypes.includes("longtask")
  ) {
    return { disconnect() {} };
  }
  const observer = new PerformanceObserver((list) => {
    for (const entry of list.getEntries()) {
      sink({
        name: "agent-chat.long-task",
        durationMs: entry.duration,
        fields,
      });
    }
  });
  observer.observe({ entryTypes: ["longtask"] });
  return { disconnect: () => observer.disconnect() };
}
