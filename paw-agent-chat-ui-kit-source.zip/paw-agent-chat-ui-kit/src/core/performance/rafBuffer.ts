export interface RafTextBuffer {
  push(delta: string): void;
  flush(): void;
  dispose(): void;
}

/** Coalesce transport deltas into at most one consumer update per frame. */
export function createRafTextBuffer(
  onFlush: (combinedDelta: string) => void,
): RafTextBuffer {
  let pending = "";
  let frame: number | null = null;

  const flush = (): void => {
    if (frame !== null && typeof cancelAnimationFrame === "function") {
      cancelAnimationFrame(frame);
      frame = null;
    }
    if (!pending) return;
    const value = pending;
    pending = "";
    onFlush(value);
  };

  return {
    push(delta) {
      pending += delta;
      if (frame !== null) return;
      if (typeof requestAnimationFrame !== "function") {
        flush();
        return;
      }
      frame = requestAnimationFrame(() => {
        frame = null;
        flush();
      });
    },
    flush,
    dispose() {
      if (frame !== null && typeof cancelAnimationFrame === "function") {
        cancelAnimationFrame(frame);
      }
      frame = null;
      pending = "";
    },
  };
}
