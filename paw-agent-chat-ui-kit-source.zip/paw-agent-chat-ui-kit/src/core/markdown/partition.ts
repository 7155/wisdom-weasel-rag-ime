/** Assign top-level parsed nodes back to stable chunks by absolute offsets. */
export function partitionTopLevelNodes<Node>(
  nodes: readonly Node[],
  chunkOffsets: readonly number[],
  getStartOffset: (node: Node) => number | undefined,
): Node[][] {
  const groups = chunkOffsets.map(() => [] as Node[]);
  if (groups.length === 0) return groups;

  const nextKnownStart = new Array<number | undefined>(nodes.length);
  let next: number | undefined;
  for (let index = nodes.length - 1; index >= 0; index -= 1) {
    nextKnownStart[index] = next;
    const current = getStartOffset(nodes[index]!);
    if (current !== undefined) next = current;
  }

  let chunkIndex = 0;
  for (let nodeIndex = 0; nodeIndex < nodes.length; nodeIndex += 1) {
    const node = nodes[nodeIndex]!;
    const start = getStartOffset(node);

    if (start !== undefined) {
      while (
        chunkIndex + 1 < chunkOffsets.length &&
        start >= chunkOffsets[chunkIndex + 1]!
      ) {
        chunkIndex += 1;
      }
    } else {
      // Plugins may replace nodes and drop source positions. The next positioned
      // sibling provides a conservative ownership hint.
      const nextStart = nextKnownStart[nodeIndex];
      while (
        nextStart !== undefined &&
        chunkIndex + 1 < chunkOffsets.length &&
        chunkOffsets[chunkIndex + 1]! < nextStart &&
        groups[chunkIndex]!.length > 0
      ) {
        chunkIndex += 1;
      }
    }

    groups[chunkIndex]!.push(node);
  }
  return groups;
}
