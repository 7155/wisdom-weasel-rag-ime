/** Cheap normalizations that are safe while a response is incomplete. */
export function normalizeStreamingMarkdown(markdown: string): string {
  return markdown.replace(/^(\s*)•\s+/gm, "$1- ");
}
