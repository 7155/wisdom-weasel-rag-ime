/**
 * Append-aware Markdown block scanner.
 *
 * This is not a CommonMark parser. It only finds conservative boundaries where
 * an already-rendered prefix is unlikely to be reinterpreted by later bytes.
 * The final incomplete physical line is deliberately rescanned on the next
 * append, keeping the cost proportional to the live tail rather than the full
 * answer.
 */

export interface MarkdownFenceState {
  marker: "`" | "~";
  length: number;
}

export interface MarkdownScanCursor {
  fence: MarkdownFenceState | null;
  inMathBlock: boolean;
  inList: boolean;
  listPendingBlank: boolean;
  inTable: boolean;
  inBlockquote: boolean;
  inIndentedCode: boolean;
  indentedCodePendingBlank: boolean;
  hadBlankLine: boolean;
  hadContent: boolean;
  /** UTF-16 offset of the last incomplete physical line. */
  offset: number;
}

export interface StableMarkdownChunk {
  id: number;
  start: number;
  end: number;
  content: string;
}

export interface StreamingMarkdownDocumentState {
  sourceText: string;
  committedOffset: number;
  nextChunkId: number;
  chunks: readonly StableMarkdownChunk[];
  cursor: MarkdownScanCursor;
  settled: boolean;
  /** Diagnostic counter: total UTF-16 code units scanned across updates. */
  scannedChars: number;
}

export interface RenderMarkdownChunk extends StableMarkdownChunk {
  active: boolean;
}

const BLANK = /^[\t \r]*$/;
const INDENTED_CODE = /^(?: {4}| {0,3}\t)/;
const LIST_ITEM = /^(?:[-+*]\s|\d{1,9}[.)]\s)/;
const ONLY_LIST_MARKER = /^(?:[-+*]|\d{1,9}[.)]?)$/;
const THEMATIC_BREAK = /^([-*_])(?:[ \t]*\1){2,}$/;

export function createMarkdownScanCursor(): MarkdownScanCursor {
  return {
    fence: null,
    inMathBlock: false,
    inList: false,
    listPendingBlank: false,
    inTable: false,
    inBlockquote: false,
    inIndentedCode: false,
    indentedCodePendingBlank: false,
    hadBlankLine: false,
    hadContent: false,
    offset: 0,
  };
}

export function createStreamingMarkdownDocumentState(): StreamingMarkdownDocumentState {
  return {
    sourceText: "",
    committedOffset: 0,
    nextChunkId: 0,
    chunks: [],
    cursor: createMarkdownScanCursor(),
    settled: false,
    scannedChars: 0,
  };
}

function trimChunkEnd(value: string): string {
  let end = value.length;
  while (end > 0) {
    const code = value.charCodeAt(end - 1);
    if (code !== 9 && code !== 10 && code !== 13 && code !== 32) break;
    end -= 1;
  }
  return end === value.length ? value : value.slice(0, end);
}

function isOpenBlock(input: Omit<MarkdownScanCursor, "offset">): boolean {
  return Boolean(
    input.fence ||
      input.inMathBlock ||
      input.inList ||
      input.inTable ||
      input.inBlockquote ||
      input.inIndentedCode,
  );
}

function parseFence(line: string): MarkdownFenceState | null {
  const match = line.match(/^ {0,3}(`{3,}|~{3,})/);
  if (!match) return null;
  const marker = match[1]!;
  return {
    marker: marker[0] as "`" | "~",
    length: marker.length,
  };
}

function isFenceCloser(line: string, open: MarkdownFenceState): boolean {
  const trimmed = line.trim();
  if (!trimmed || trimmed[0] !== open.marker) return false;
  let length = 0;
  while (trimmed[length] === open.marker) length += 1;
  return length >= open.length && trimmed.slice(length).trim() === "";
}

export interface MarkdownScanResult {
  boundaries: readonly number[];
  cursor: MarkdownScanCursor;
  scannedChars: number;
}

/** Scan cursor.offset..end and retain a resumable snapshot before the last line. */
export function scanAppendedMarkdown(
  text: string,
  initial: MarkdownScanCursor,
): MarkdownScanResult {
  const suffix = text.slice(initial.offset);
  const lines = suffix.split("\n");
  const lastIndex = lines.length - 1;
  const boundaries: number[] = [];

  let fence = initial.fence;
  let inMathBlock = initial.inMathBlock;
  let inList = initial.inList;
  let listPendingBlank = initial.listPendingBlank;
  let inTable = initial.inTable;
  let inBlockquote = initial.inBlockquote;
  let inIndentedCode = initial.inIndentedCode;
  let indentedCodePendingBlank = initial.indentedCodePendingBlank;
  let hadBlankLine = initial.hadBlankLine;
  let hadContent = initial.hadContent;
  let absolute = initial.offset;
  let nextCursor = initial;

  for (let index = 0; index < lines.length; index += 1) {
    // Store the state from before the incomplete final line. On the next append
    // that line is scanned again with its newly arrived suffix.
    if (index === lastIndex) {
      nextCursor = {
        fence,
        inMathBlock,
        inList,
        listPendingBlank,
        inTable,
        inBlockquote,
        inIndentedCode,
        indentedCodePendingBlank,
        hadBlankLine,
        hadContent,
        offset: absolute,
      };
    }

    const line = lines[index]!;
    const trimmed = line.trim();
    const blank = BLANK.test(line);
    const indented = INDENTED_CODE.test(line);
    const wasInside = isOpenBlock({
      fence,
      inMathBlock,
      inList,
      listPendingBlank,
      inTable,
      inBlockquote,
      inIndentedCode,
      indentedCodePendingBlank,
      hadBlankLine,
      hadContent,
    });

    let indentedBlockClosedBeforeLine = false;
    if (inIndentedCode) {
      if (blank) {
        indentedCodePendingBlank = true;
      } else if (!indented) {
        inIndentedCode = false;
        indentedBlockClosedBeforeLine = indentedCodePendingBlank;
        indentedCodePendingBlank = false;
      } else {
        indentedCodePendingBlank = false;
      }
    } else if (
      indented &&
      !blank &&
      !wasInside &&
      (hadBlankLine || !hadContent)
    ) {
      inIndentedCode = true;
      indentedCodePendingBlank = false;
    }

    if (!inIndentedCode && !inMathBlock) {
      const candidate = parseFence(line);
      if (candidate) {
        if (!fence) fence = candidate;
        else if (isFenceCloser(line, fence)) fence = null;
      }
    }

    let listClosedBeforeLine = false;
    const wasInMath = inMathBlock;
    if (!fence && !inIndentedCode) {
      if (trimmed === "$$") inMathBlock = !inMathBlock;

      if (!wasInMath) {
        const thematic = THEMATIC_BREAK.test(trimmed);
        if (!indented && !thematic && LIST_ITEM.test(trimmed)) {
          inList = true;
          listPendingBlank = false;
        } else if (inList && blank) {
          listPendingBlank = true;
        } else if (inList && listPendingBlank && !/^[\t ]/.test(line)) {
          inList = false;
          listPendingBlank = false;
          listClosedBeforeLine = true;
        } else if (inList && listPendingBlank) {
          listPendingBlank = false;
        }

        // Deliberately conservative. The full Markdown parser owns exact GFM
        // table semantics; the scanner merely avoids freezing a growing table.
        if (trimmed.includes("|")) inTable = true;
        else if (inTable && blank) inTable = false;

        if (!indented && trimmed.startsWith(">")) inBlockquote = true;
        else if (inBlockquote && blank) inBlockquote = false;
      }
    }

    const nowInside = Boolean(
      fence || inMathBlock || inList || inTable || inBlockquote || inIndentedCode,
    );

    if (blank) {
      if ((!wasInside && hadContent) || (wasInside && !nowInside)) {
        hadBlankLine = true;
      }
    } else if (indentedBlockClosedBeforeLine) {
      boundaries.push(absolute);
      hadBlankLine = false;
    } else if (
      listClosedBeforeLine &&
      !(index === lastIndex && ONLY_LIST_MARKER.test(trimmed))
    ) {
      boundaries.push(absolute);
      hadBlankLine = false;
    } else if (hadBlankLine && !wasInside) {
      boundaries.push(absolute);
      hadBlankLine = false;
    }

    if (!blank) hadContent = true;
    absolute += line.length + 1;
  }

  return {
    boundaries,
    cursor: nextCursor,
    scannedChars: suffix.length,
  };
}

function appendBoundaries(
  base: StreamingMarkdownDocumentState,
  sourceText: string,
  boundaries: readonly number[],
  cursor: MarkdownScanCursor,
  scannedChars: number,
): StreamingMarkdownDocumentState {
  const freshBoundaries = boundaries.filter(
    (boundary) => boundary > base.committedOffset,
  );
  if (freshBoundaries.length === 0) {
    return {
      ...base,
      sourceText,
      cursor,
      settled: false,
      scannedChars: base.scannedChars + scannedChars,
    };
  }

  const appended: StableMarkdownChunk[] = [];
  let start = base.committedOffset;
  let nextChunkId = base.nextChunkId;
  for (const end of freshBoundaries) {
    const content = trimChunkEnd(sourceText.slice(start, end));
    if (content) appended.push({ id: nextChunkId++, start, end, content });
    start = end;
  }

  return {
    sourceText,
    committedOffset: freshBoundaries.at(-1) ?? base.committedOffset,
    nextChunkId,
    chunks: [...base.chunks, ...appended],
    cursor,
    settled: false,
    scannedChars: base.scannedChars + scannedChars,
  };
}

function finalizeStreamingMarkdownDocument(
  base: StreamingMarkdownDocumentState,
  sourceText: string,
): StreamingMarkdownDocumentState {
  if (base.settled && base.sourceText === sourceText) return base;
  const tail = trimChunkEnd(sourceText.slice(base.committedOffset));
  if (!tail) {
    return {
      ...base,
      sourceText,
      committedOffset: sourceText.length,
      settled: true,
    };
  }
  const finalChunk: StableMarkdownChunk = {
    id: base.nextChunkId,
    start: base.committedOffset,
    end: sourceText.length,
    content: tail,
  };
  return {
    ...base,
    sourceText,
    committedOffset: sourceText.length,
    nextChunkId: base.nextChunkId + 1,
    chunks: [...base.chunks, finalChunk],
    settled: true,
  };
}

/**
 * Advance the append-only model. A non-prefix replacement is treated as retry,
 * edit, regeneration or reconciliation and safely rebuilds from zero.
 */
export function advanceStreamingMarkdownDocument(
  previous: StreamingMarkdownDocumentState,
  sourceText: string,
  streaming: boolean,
): StreamingMarkdownDocumentState {
  if (sourceText.length === 0) return createStreamingMarkdownDocumentState();
  if (sourceText === previous.sourceText) {
    return streaming
      ? previous.settled
        ? advanceStreamingMarkdownDocument(
            createStreamingMarkdownDocumentState(),
            sourceText,
            true,
          )
        : previous
      : finalizeStreamingMarkdownDocument(previous, sourceText);
  }

  const canAppend =
    !previous.settled && sourceText.startsWith(previous.sourceText);
  const base = canAppend
    ? previous
    : createStreamingMarkdownDocumentState();
  const scan = scanAppendedMarkdown(sourceText, base.cursor);
  const advanced = appendBoundaries(
    base,
    sourceText,
    scan.boundaries,
    scan.cursor,
    scan.scannedChars,
  );
  return streaming
    ? advanced
    : finalizeStreamingMarkdownDocument(advanced, sourceText);
}

export function projectStreamingMarkdownChunks(
  state: StreamingMarkdownDocumentState,
  sourceText: string,
  streaming: boolean,
): readonly RenderMarkdownChunk[] {
  const stable = state.chunks.map((chunk) => ({ ...chunk, active: false }));
  if (!streaming || state.settled) return stable;
  const tail = sourceText.slice(state.committedOffset);
  if (!tail) return stable;
  return [
    ...stable,
    {
      id: state.nextChunkId,
      start: state.committedOffset,
      end: sourceText.length,
      content: tail,
      active: true,
    },
  ];
}
