export interface OpenFenceTail {
  marker: "`" | "~";
  markerLength: number;
  language: string;
  openingOffset: number;
  contentOffset: number;
  markdownBefore: string;
  code: string;
}

function parseOpener(line: string): {
  marker: "`" | "~";
  markerLength: number;
  suffix: string;
} | null {
  const match = line.match(/^ {0,3}(`{3,}|~{3,})(.*)$/);
  if (!match) return null;
  return {
    marker: match[1]![0] as "`" | "~",
    markerLength: match[1]!.length,
    suffix: match[2]!,
  };
}

function closes(line: string, marker: "`" | "~", minimum: number): boolean {
  let cursor = 0;
  while (cursor < 3 && line[cursor] === " ") cursor += 1;
  let count = 0;
  while (line[cursor + count] === marker) count += 1;
  return count >= minimum && /^[\t ]*$/.test(line.slice(cursor + count));
}

/**
 * Locate the final unclosed fenced code block. A renderer can parse
 * markdownBefore normally and render code through a cheap live-code path.
 */
export function findOpenFenceTail(markdown: string): OpenFenceTail | null {
  // Frontmatter and unusual control inputs are left to the full parser.
  if (markdown.includes("\0") || markdown.includes("\r")) return null;
  if (markdown.startsWith("---\n") || markdown.startsWith("+++\n")) return null;

  let open:
    | {
        marker: "`" | "~";
        markerLength: number;
        language: string;
        openingOffset: number;
        contentOffset: number;
      }
    | null = null;

  let offset = 0;
  while (offset <= markdown.length) {
    const newline = markdown.indexOf("\n", offset);
    const end = newline < 0 ? markdown.length : newline;
    const line = markdown.slice(offset, end);

    if (!open) {
      const opener = parseOpener(line);
      if (opener && !(opener.marker === "`" && opener.suffix.includes("`"))) {
        open = {
          marker: opener.marker,
          markerLength: opener.markerLength,
          language: opener.suffix.trim().split(/\s+/, 1)[0] ?? "",
          openingOffset: offset,
          contentOffset: newline < 0 ? markdown.length : newline + 1,
        };
      }
    } else if (closes(line, open.marker, open.markerLength)) {
      open = null;
    }

    if (newline < 0) break;
    offset = newline + 1;
  }

  if (!open) return null;
  return {
    ...open,
    markdownBefore: markdown.slice(0, open.openingOffset),
    code: markdown.slice(open.contentOffset).replace(/\n$/, ""),
  };
}
