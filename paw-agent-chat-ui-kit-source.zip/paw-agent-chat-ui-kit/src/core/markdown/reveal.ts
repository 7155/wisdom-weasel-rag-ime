/** Safe progressive visibility for incomplete Markdown. */

const BARE_LIST = /^[\t ]*(?:[-+*]|\d{1,9}[.)]?)$/;
const BARE_HEADING = /^ {0,3}#{1,6}[\t ]*$/;
const WORD_CHAR = /[A-Za-z0-9_-]/;

function avoidLowSurrogate(text: string, offset: number): number {
  if (
    offset > 0 &&
    offset < text.length &&
    (text.charCodeAt(offset) & 0xfc00) === 0xdc00
  ) {
    return offset - 1;
  }
  return offset;
}

/**
 * Return the largest prefix that does not end inside a likely-open inline
 * Markdown construct. It intentionally favors visual stability over perfect
 * CommonMark emulation.
 */
export function findSafeMarkdownRevealOffset(
  text: string,
  requestedEnd = text.length,
): number {
  const end = Math.max(0, Math.min(requestedEnd, text.length));
  if (end === 0) return 0;

  const lineStart = text.lastIndexOf("\n", end - 1) + 1;
  const currentLine = text.slice(lineStart, end);
  if (BARE_LIST.test(currentLine) || BARE_HEADING.test(currentLine)) {
    return lineStart;
  }

  let inlineCodeStart = -1;
  let inlineCodeRun = 0;
  let linkStart = -1;
  const emphasis = new Map<string, number>();

  for (let cursor = lineStart; cursor < end; cursor += 1) {
    const char = text[cursor]!;

    if (char === "`") {
      let run = 1;
      while (cursor + run < end && text[cursor + run] === "`") run += 1;
      if (inlineCodeStart < 0) {
        inlineCodeStart = cursor;
        inlineCodeRun = run;
      } else if (run === inlineCodeRun) {
        inlineCodeStart = -1;
      }
      cursor += run - 1;
      continue;
    }
    if (inlineCodeStart >= 0) continue;

    if (char === "[" || (char === "!" && text[cursor + 1] === "[")) {
      if (linkStart < 0) linkStart = cursor;
      if (char === "!") cursor += 1;
      continue;
    }
    if (char === "]" && linkStart >= 0) {
      if (text[cursor + 1] === "(") {
        const close = text.indexOf(")", cursor + 2);
        if (close < 0 || close >= end) break;
        linkStart = -1;
        cursor = close;
      } else {
        linkStart = -1;
      }
      continue;
    }

    if (char === "*" || char === "_" || char === "~") {
      let run = 1;
      while (cursor + run < end && text[cursor + run] === char) run += 1;
      const before = cursor > lineStart ? text[cursor - 1]! : "";
      const after = cursor + run < end ? text[cursor + run]! : "";
      const canOpen = after !== "" && !/\s/.test(after);
      const canClose = before !== "" && !/\s/.test(before);
      const toggle = (key: string): void => {
        if (emphasis.has(key)) {
          if (canClose) emphasis.delete(key);
        } else if (canOpen) {
          emphasis.set(key, cursor);
        }
      };
      if (!(char === "_" && /\w/.test(before) && /\w/.test(after))) {
        if (run >= 2) toggle(char + char);
        if (char !== "~" && run % 2 === 1) toggle(char);
      }
      cursor += run - 1;
    }
  }

  let safe = end;
  if (inlineCodeStart >= 0) safe = Math.min(safe, inlineCodeStart);
  if (linkStart >= 0) safe = Math.min(safe, linkStart);
  for (const start of emphasis.values()) safe = Math.min(safe, start);

  // Hold a short unfinished Latin word. CJK text naturally advances one
  // meaningful character at a time and is not held by this rule.
  if (safe === end && WORD_CHAR.test(text[safe - 1] ?? "")) {
    const boundary = Math.max(
      text.lastIndexOf(" ", safe - 1),
      text.lastIndexOf("\n", safe - 1),
    );
    if (safe - boundary - 1 <= 24) safe = boundary + 1;
  }
  return avoidLowSurrogate(text, safe);
}

/** Never let malformed Markdown keep more than maxHoldbackChars invisible. */
export function markdownRevealCeiling(
  text: string,
  maxHoldbackChars = 600,
): number {
  return avoidLowSurrogate(
    text,
    Math.max(
      findSafeMarkdownRevealOffset(text),
      text.length - Math.max(0, maxHoldbackChars),
    ),
  );
}

export function advanceMarkdownReveal(
  text: string,
  current: number,
  ceiling: number,
  baseStep = 40,
): number {
  if (current >= ceiling) return ceiling;
  const backlog = ceiling - current;
  let probe = Math.min(
    ceiling,
    current + Math.max(baseStep, Math.ceil(backlog / 4)),
  );
  let safe = findSafeMarkdownRevealOffset(text, probe);
  while (safe <= current && probe < ceiling) {
    probe = Math.min(ceiling, probe + baseStep);
    safe = findSafeMarkdownRevealOffset(text, probe);
  }
  return avoidLowSurrogate(text, safe > current ? safe : ceiling);
}

/** Preserve the visible cursor when a retry/edit replaces part of the source. */
export function remapVisibleOffsetAfterEdit(
  previousText: string,
  nextText: string,
  previousOffset: number,
): number {
  let prefix = 0;
  const prefixLimit = Math.min(
    previousText.length,
    nextText.length,
    previousOffset,
  );
  while (
    prefix < prefixLimit &&
    previousText[prefix] === nextText[prefix]
  ) {
    prefix += 1;
  }
  if (prefix >= previousOffset) return previousOffset;

  let suffix = 0;
  const suffixLimit = Math.min(previousText.length, nextText.length) - prefix;
  while (
    suffix < suffixLimit &&
    previousText[previousText.length - 1 - suffix] ===
      nextText[nextText.length - 1 - suffix]
  ) {
    suffix += 1;
  }
  const mapped =
    previousOffset >= previousText.length - suffix
      ? nextText.length - (previousText.length - previousOffset)
      : prefix;
  return avoidLowSurrogate(nextText, Math.max(0, Math.min(mapped, nextText.length)));
}
