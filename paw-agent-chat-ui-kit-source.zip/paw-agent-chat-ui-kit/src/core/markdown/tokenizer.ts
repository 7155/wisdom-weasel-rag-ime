export interface HighlightToken {
  content: string;
  className?: string;
  style?: Readonly<Record<string, string | number>>;
}

export interface StatefulLineTokenizer<State> {
  initialState: State;
  tokenizeLine(
    line: string,
    stateBefore: State,
  ): { tokens: readonly HighlightToken[]; stateAfter: State };
  stateEquals?: (left: State, right: State) => boolean;
}

export interface CachedTokenLine<State> {
  text: string;
  stateBefore: State;
  stateAfter: State;
  tokens: readonly HighlightToken[];
}

export interface IncrementalTokenResult<State> {
  completeLines: readonly CachedTokenLine<State>[];
  partialLine: string;
  tokenizedLineCount: number;
}

export function splitCompleteLines(code: string): {
  completeLines: string[];
  partialLine: string;
} {
  const pieces = code.split("\n");
  const partialLine = pieces.pop() ?? "";
  return { completeLines: pieces, partialLine };
}

/**
 * Tokenize only the changed suffix. Once lexer state converges with a cached
 * unchanged line, later unchanged lines are reused as well.
 */
export function updateIncrementalTokenCache<State>(
  code: string,
  tokenizer: StatefulLineTokenizer<State>,
  previous: readonly CachedTokenLine<State>[] = [],
): IncrementalTokenResult<State> {
  const { completeLines, partialLine } = splitCompleteLines(code);
  const equals = tokenizer.stateEquals ?? Object.is;

  let firstChanged = 0;
  while (
    firstChanged < completeLines.length &&
    firstChanged < previous.length &&
    completeLines[firstChanged] === previous[firstChanged]!.text
  ) {
    firstChanged += 1;
  }

  const next: CachedTokenLine<State>[] = previous.slice(0, firstChanged);
  let state =
    firstChanged === 0
      ? tokenizer.initialState
      : next[firstChanged - 1]!.stateAfter;
  let tokenizedLineCount = 0;

  for (let index = firstChanged; index < completeLines.length; index += 1) {
    const line = completeLines[index]!;
    const cached = previous[index];
    if (
      cached &&
      cached.text === line &&
      equals(cached.stateBefore, state)
    ) {
      next.push(cached);
      state = cached.stateAfter;
      continue;
    }

    const tokenized = tokenizer.tokenizeLine(line, state);
    tokenizedLineCount += 1;
    const entry: CachedTokenLine<State> = {
      text: line,
      stateBefore: state,
      stateAfter: tokenized.stateAfter,
      tokens: tokenized.tokens,
    };
    next.push(entry);
    state = entry.stateAfter;
  }

  return { completeLines: next, partialLine, tokenizedLineCount };
}

export const plainTextLineTokenizer: StatefulLineTokenizer<null> = {
  initialState: null,
  tokenizeLine(line) {
    return { tokens: [{ content: line }], stateAfter: null };
  },
};
