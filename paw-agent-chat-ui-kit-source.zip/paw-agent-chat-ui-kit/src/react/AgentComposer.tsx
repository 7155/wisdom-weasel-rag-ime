import { useRef, type ReactNode } from "react";
import type {
  ComposerAction,
  ComposerActionModel,
} from "../core/interaction/composer.js";
import {
  ComposerActionBar,
  type ComposerActionBarProps,
  type ComposerActionLabels,
} from "./ComposerActionBar.js";

export interface AgentComposerProps {
  value: string;
  onChange(value: string): void;
  model: ComposerActionModel;
  labels: ComposerActionLabels;
  placeholder: string;
  ariaLabel: string;
  onAction(action: Exclude<ComposerAction, "none">): void | Promise<void>;
  confirmDestructive?: ComposerActionBarProps["confirmDestructive"];
  leading?: ReactNode;
  attachments?: ReactNode;
  footer?: ReactNode;
  minRows?: number;
  maxLength?: number;
}

/**
 * A small reference composer. PAW can keep its rich editor and consume the same
 * action model/keyboard semantics instead of replacing the editor wholesale.
 */
export function AgentComposer({
  value,
  onChange,
  model,
  labels,
  placeholder,
  ariaLabel,
  onAction,
  confirmDestructive,
  leading,
  attachments,
  footer,
  minRows = 2,
  maxLength,
}: AgentComposerProps): ReactNode {
  const composingRef = useRef(false);
  const primary = model.primary;

  return (
    <div className="paw-agent-composer" data-composer-mode={model.mode}>
      {leading ? <div className="paw-composer-leading">{leading}</div> : null}
      {attachments ? (
        <div className="paw-composer-attachments">{attachments}</div>
      ) : null}
      <textarea
        className="paw-composer-editor"
        value={value}
        rows={minRows}
        maxLength={maxLength}
        disabled={model.editorDisabled}
        placeholder={placeholder}
        aria-label={ariaLabel}
        onChange={(event: any) => onChange(event.currentTarget.value)}
        onCompositionStart={() => {
          composingRef.current = true;
        }}
        onCompositionEnd={() => {
          composingRef.current = false;
        }}
        onKeyDown={(event: any) => {
          if (event.key !== "Enter" || event.shiftKey || composingRef.current) return;
          // Destructive interrupt is never a default Enter action. The primary
          // model contains only send/queue/answer and may still be disabled.
          if (
            primary === "none" ||
            primary === "answer-interaction" ||
            model.primaryDisabled
          ) {
            return;
          }
          event.preventDefault();
          void onAction(primary);
        }}
      />
      <div className="paw-composer-footer-row">
        <div className="paw-composer-footer-content">{footer}</div>
        <ComposerActionBar
          model={model}
          labels={labels}
          onAction={onAction}
          confirmDestructive={confirmDestructive}
        />
      </div>
    </div>
  );
}
