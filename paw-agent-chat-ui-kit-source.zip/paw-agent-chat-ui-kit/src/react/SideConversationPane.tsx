import type { ReactNode } from "react";
import type { SideConversationStatus } from "../core/interaction/sideChat.js";

export function SideConversationPane({
  open,
  status,
  title,
  isolationDescription,
  closeLabel,
  onClose,
  children,
  footer,
  width,
}: {
  open: boolean;
  status: SideConversationStatus;
  title: string;
  isolationDescription: string;
  closeLabel: string;
  onClose(): void | Promise<void>;
  children: ReactNode;
  footer?: ReactNode;
  width?: string | number;
}): ReactNode {
  if (!open) return null;
  return (
    <aside
      className="paw-side-conversation"
      data-side-status={status}
      style={width !== undefined ? { width } : undefined}
      aria-label={title}
    >
      <header className="paw-side-header">
        <div>
          <h2>{title}</h2>
          <p>{isolationDescription}</p>
        </div>
        <button type="button" aria-label={closeLabel} onClick={() => void onClose()}>
          ×
        </button>
      </header>
      <div className="paw-side-content">{children}</div>
      {footer ? <footer className="paw-side-footer">{footer}</footer> : null}
    </aside>
  );
}
