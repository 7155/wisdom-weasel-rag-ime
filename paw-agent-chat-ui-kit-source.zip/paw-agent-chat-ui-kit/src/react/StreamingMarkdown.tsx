import {
  Fragment,
  memo,
  useDeferredValue,
  useEffect,
  useMemo,
  useRef,
  type MutableRefObject,
  type ReactNode,
} from "react";
import { findOpenFenceTail } from "../core/markdown/openFence.js";
import { normalizeStreamingMarkdown } from "../core/markdown/normalization.js";
import type { RenderMarkdownChunk } from "../core/markdown/scanner.js";
import { useSafeVisibleText } from "./useSafeVisibleText.js";
import { useStreamingMarkdownDocument } from "./useStreamingMarkdownDocument.js";

export interface MarkdownRenderContext {
  active: boolean;
  settled: boolean;
  start: number;
  end: number;
  chunkId: number;
}

export interface LiveCodeRenderContext {
  language: string;
  start: number;
  streaming: true;
}

export interface StreamingMarkdownProps {
  canonicalText: string;
  streaming: boolean;
  renderMarkdown(markdown: string, context: MarkdownRenderContext): ReactNode;
  renderLiveCode?(code: string, context: LiveCodeRenderContext): ReactNode;
  className?: string;
  normalize?: (markdown: string) => string;
  progressiveReveal?: boolean;
  openFenceFastPath?: boolean;
  maxHoldbackChars?: number;
  /** Increment to intentionally rerender frozen chunks after theme/plugin changes. */
  renderVersion?: string | number;
  onFirstVisibleText?(): void;
  onFirstStableChunk?(): void;
  onSettled?(): void;
}

type MarkdownRenderer = StreamingMarkdownProps["renderMarkdown"];
type LiveCodeRenderer = StreamingMarkdownProps["renderLiveCode"];

interface ChunkViewProps {
  chunk: RenderMarkdownChunk;
  settled: boolean;
  renderVersion: string | number;
  openFenceFastPath: boolean;
  markdownRendererRef: MutableRefObject<MarkdownRenderer>;
  liveCodeRendererRef: MutableRefObject<LiveCodeRenderer>;
}

const MarkdownChunkView = memo(
  function MarkdownChunkView({
    chunk,
    settled,
    openFenceFastPath,
    markdownRendererRef,
    liveCodeRendererRef,
  }: ChunkViewProps): ReactNode {
    const context: MarkdownRenderContext = {
      active: chunk.active,
      settled,
      start: chunk.start,
      end: chunk.end,
      chunkId: chunk.id,
    };
    const openFence =
      chunk.active && openFenceFastPath
        ? findOpenFenceTail(chunk.content)
        : null;
    if (!openFence) {
      return markdownRendererRef.current(chunk.content, context);
    }
    return (
      <Fragment>
        {openFence.markdownBefore
          ? markdownRendererRef.current(openFence.markdownBefore, context)
          : null}
        {liveCodeRendererRef.current ? (
          liveCodeRendererRef.current(openFence.code, {
            language: openFence.language,
            start: chunk.start + openFence.contentOffset,
            streaming: true,
          })
        ) : (
          <pre className="paw-live-code-block">
            <code
              className={
                openFence.language
                  ? `language-${openFence.language}`
                  : undefined
              }
            >
              {openFence.code}
            </code>
          </pre>
        )}
      </Fragment>
    );
  },
  (previous, next) =>
    previous.chunk.id === next.chunk.id &&
    previous.chunk.content === next.chunk.content &&
    previous.chunk.active === next.chunk.active &&
    previous.chunk.start === next.chunk.start &&
    previous.chunk.end === next.chunk.end &&
    previous.settled === next.settled &&
    previous.renderVersion === next.renderVersion &&
    previous.openFenceFastPath === next.openFenceFastPath,
);

/**
 * Stable completed chunks + one mutable tail. Canonical full text is never
 * replaced by the visible prefix and remains the source for copy/search.
 */
export function StreamingMarkdown({
  canonicalText,
  streaming,
  renderMarkdown,
  renderLiveCode,
  className,
  normalize = normalizeStreamingMarkdown,
  progressiveReveal = true,
  openFenceFastPath = true,
  maxHoldbackChars = 600,
  renderVersion = 0,
  onFirstVisibleText,
  onFirstStableChunk,
  onSettled,
}: StreamingMarkdownProps): ReactNode {
  const normalized = useMemo(
    () => normalize(canonicalText),
    [canonicalText, normalize],
  );
  const visibleText = useSafeVisibleText(normalized, {
    enabled: streaming && progressiveReveal,
    maxHoldbackChars,
  });
  const deferredStreaming = useDeferredValue(streaming);
  const { state, chunks } = useStreamingMarkdownDocument(
    visibleText,
    deferredStreaming,
  );

  const markdownRendererRef = useRef(renderMarkdown);
  const liveCodeRendererRef = useRef(renderLiveCode);
  markdownRendererRef.current = renderMarkdown;
  liveCodeRendererRef.current = renderLiveCode;

  const firstVisibleSent = useRef(false);
  const firstStableSent = useRef(false);
  const wasStreaming = useRef(streaming);

  useEffect(() => {
    if (!firstVisibleSent.current && visibleText.length > 0) {
      firstVisibleSent.current = true;
      onFirstVisibleText?.();
    }
  }, [onFirstVisibleText, visibleText.length]);

  useEffect(() => {
    if (!firstStableSent.current && state.chunks.length > 0) {
      firstStableSent.current = true;
      onFirstStableChunk?.();
    }
  }, [onFirstStableChunk, state.chunks.length]);

  useEffect(() => {
    if (wasStreaming.current && !streaming) onSettled?.();
    wasStreaming.current = streaming;
  }, [onSettled, streaming]);

  return (
    <div
      className={className}
      data-streaming={deferredStreaming || undefined}
      data-stable-chunks={state.chunks.length}
    >
      {chunks.map((chunk) => (
        <MarkdownChunkView
          key={chunk.id}
          chunk={chunk}
          settled={!deferredStreaming}
          renderVersion={renderVersion}
          openFenceFastPath={openFenceFastPath}
          markdownRendererRef={markdownRendererRef}
          liveCodeRendererRef={liveCodeRendererRef}
        />
      ))}
    </div>
  );
}
