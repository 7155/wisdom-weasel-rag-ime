import { useId, useState, type ReactNode } from "react";
import type {
  ComposerAction,
  ComposerActionModel,
  ComposerSecondaryAction,
} from "../core/interaction/composer.js";

export interface ComposerActionLabels {
  send: string;
  queue: string;
  "answer-interaction": string;
  "send-next": string;
  "guide-current-turn": string;
  "interrupt-and-send": string;
  stop: string;
  moreActions: string;
  settling: string;
}

export interface ComposerActionBarProps {
  model: ComposerActionModel;
  labels: ComposerActionLabels;
  onAction(action: Exclude<ComposerAction, "none">): void | Promise<void>;
  confirmDestructive?(action: ComposerSecondaryAction): boolean | Promise<boolean>;
  className?: string;
}

export function ComposerActionBar({
  model,
  labels,
  onAction,
  confirmDestructive,
  className,
}: ComposerActionBarProps): ReactNode {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuId = useId();

  const invoke = async (
    action: Exclude<ComposerAction, "none">,
  ): Promise<void> => {
    if (
      model.destructive.includes(action as ComposerSecondaryAction) &&
      confirmDestructive
    ) {
      const confirmed = await confirmDestructive(
        action as ComposerSecondaryAction,
      );
      if (!confirmed) return;
    }
    setMenuOpen(false);
    await onAction(action);
  };

  if (model.primary === "none" && model.secondary.length === 0) {
    return model.mode === "settling" ? (
      <span className="paw-composer-settling" role="status">
        {labels.settling}
      </span>
    ) : null;
  }

  return (
    <div
      className={className ?? "paw-composer-actions"}
      data-composer-mode={model.mode}
    >
      {model.primary !== "none" ? (
        <button
          type="button"
          className="paw-composer-primary"
          disabled={model.primaryDisabled}
          title={model.reason ?? undefined}
          onClick={() => void invoke(model.primary as Exclude<ComposerAction, "none">)}
        >
          {labels[model.primary]}
          <span aria-hidden="true">↗</span>
        </button>
      ) : (
        <span className="paw-composer-settling" role="status">
          {labels.settling}
        </span>
      )}

      {model.secondary.length > 0 ? (
        <div className="paw-composer-menu-wrap">
          <button
            type="button"
            className="paw-composer-menu-trigger"
            aria-label={labels.moreActions}
            aria-haspopup="menu"
            aria-expanded={menuOpen}
            aria-controls={menuId}
            onClick={() => setMenuOpen((value) => !value)}
          >
            <span aria-hidden="true">⌄</span>
          </button>
          {menuOpen ? (
            <div id={menuId} className="paw-composer-menu" role="menu">
              {model.secondary.map((action) => (
                <button
                  key={action}
                  type="button"
                  role="menuitem"
                  className="paw-composer-menu-item"
                  data-destructive={
                    model.destructive.includes(action) || undefined
                  }
                  onClick={() => void invoke(action)}
                >
                  {labels[action]}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
