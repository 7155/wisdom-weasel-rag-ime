import {
  useCallback,
  useEffect,
  useRef,
  useState,
  type RefObject,
} from "react";
import {
  captureTranscriptMessageAnchor,
  restoreTranscriptMessageAnchor,
  type TranscriptMessageAnchor,
  type TranscriptRowGeometry,
} from "../core/interaction/messageAnchor.js";
import {
  createFollowEndState,
  reduceFollowEndState,
  type FollowEndEvent,
  type FollowEndState,
} from "../core/interaction/followEnd.js";

export interface TranscriptScrollControllerOptions {
  conversationId: string;
  scrollerRef: RefObject<HTMLElement | null>;
  getRows(): readonly TranscriptRowGeometry[];
  layoutRevision: number;
  viewportTopInset?: number;
  bottomThresholdPx?: number;
}

export interface TranscriptScrollController {
  state: FollowEndState;
  scrollToLatest(behavior?: "auto" | "smooth"): void;
  notifyContentAppended(updateCount?: number): void;
  notifyLayoutChanged(): void;
  captureBeforeConversationChange(): TranscriptMessageAnchor | null;
  restoreConversation(): void;
  detachForSelection(): void;
}

/**
 * One scroll owner for both virtual and non-virtual transcripts. The caller
 * supplies row geometry from its existing virtualizer; this hook does not
 * install a second virtualization system.
 */
export function useTranscriptScrollController({
  conversationId,
  scrollerRef,
  getRows,
  layoutRevision,
  viewportTopInset = 0,
  bottomThresholdPx = 24,
}: TranscriptScrollControllerOptions): TranscriptScrollController {
  const [state, setState] = useState<FollowEndState>(() =>
    createFollowEndState("following"),
  );
  const stateRef = useRef(state);
  stateRef.current = state;
  const anchorMemoryRef = useRef(new Map<string, TranscriptMessageAnchor>());
  const programmaticUntilRef = useRef(0);
  const userIntentUntilRef = useRef(0);
  const scheduledFrameRef = useRef(0);

  const dispatch = useCallback((event: FollowEndEvent): FollowEndState => {
    const next = reduceFollowEndState(stateRef.current, event);
    stateRef.current = next;
    setState(next);
    return next;
  }, []);

  const capture = useCallback((): TranscriptMessageAnchor | null => {
    const scroller = scrollerRef.current;
    if (!scroller) return null;
    const anchor = captureTranscriptMessageAnchor({
      conversationId,
      rows: getRows(),
      scrollTop: scroller.scrollTop,
      viewportTopInset,
      layoutRevision,
    });
    if (anchor) anchorMemoryRef.current.set(conversationId, anchor);
    return anchor;
  }, [
    conversationId,
    getRows,
    layoutRevision,
    scrollerRef,
    viewportTopInset,
  ]);

  const restoreAnchor = useCallback(
    (anchor: TranscriptMessageAnchor): void => {
      const scroller = scrollerRef.current;
      if (!scroller) return;
      const restored = restoreTranscriptMessageAnchor({
        anchor,
        rows: getRows(),
        maxScrollTop: Math.max(0, scroller.scrollHeight - scroller.clientHeight),
      });
      programmaticUntilRef.current = performance.now() + 100;
      scroller.scrollTop = restored.scrollTop;
      const updated = captureTranscriptMessageAnchor({
        conversationId,
        rows: getRows(),
        scrollTop: scroller.scrollTop,
        viewportTopInset,
        layoutRevision,
      });
      if (updated) anchorMemoryRef.current.set(conversationId, updated);
    },
    [
      conversationId,
      getRows,
      layoutRevision,
      scrollerRef,
      viewportTopInset,
    ],
  );

  const schedule = useCallback((work: () => void): void => {
    if (typeof requestAnimationFrame !== "function") {
      work();
      return;
    }
    if (scheduledFrameRef.current) cancelAnimationFrame(scheduledFrameRef.current);
    scheduledFrameRef.current = requestAnimationFrame(() => {
      scheduledFrameRef.current = 0;
      work();
    });
  }, []);

  const scrollToLatest = useCallback(
    (behavior: "auto" | "smooth" = "auto"): void => {
      const scroller = scrollerRef.current;
      if (!scroller) return;
      programmaticUntilRef.current =
        performance.now() + (behavior === "smooth" ? 1_000 : 120);
      scroller.scrollTo({
        top: Math.max(0, scroller.scrollHeight - scroller.clientHeight),
        behavior,
      });
      anchorMemoryRef.current.delete(conversationId);
      dispatch({ type: "jump-to-latest" });
    },
    [conversationId, dispatch, scrollerRef],
  );

  const notifyContentAppended = useCallback(
    (updateCount = 1): void => {
      const before = stateRef.current;
      dispatch({ type: "content-appended", updateCount });
      schedule(() => {
        if (before.mode === "following") {
          scrollToLatest("auto");
          return;
        }
        const anchor =
          anchorMemoryRef.current.get(conversationId) ?? before.anchor;
        if (anchor) restoreAnchor(anchor);
      });
    },
    [conversationId, dispatch, restoreAnchor, schedule, scrollToLatest],
  );

  const notifyLayoutChanged = useCallback((): void => {
    const current = stateRef.current;
    dispatch({ type: "layout-changed" });
    schedule(() => {
      if (current.mode === "following") scrollToLatest("auto");
      else {
        const anchor =
          anchorMemoryRef.current.get(conversationId) ?? current.anchor;
        if (anchor) restoreAnchor(anchor);
      }
    });
  }, [conversationId, dispatch, restoreAnchor, schedule, scrollToLatest]);

  const restoreConversation = useCallback((): void => {
    const anchor = anchorMemoryRef.current.get(conversationId);
    if (!anchor) {
      dispatch({ type: "conversation-restored", mode: "following" });
      schedule(() => scrollToLatest("auto"));
      return;
    }
    dispatch({
      type: "conversation-restored",
      mode: "detached",
      anchor,
    });
    schedule(() => restoreAnchor(anchor));
  }, [conversationId, dispatch, restoreAnchor, schedule, scrollToLatest]);

  useEffect(() => {
    const scroller = scrollerRef.current;
    if (!scroller) return;

    const noteUserIntent = (): void => {
      userIntentUntilRef.current = performance.now() + 250;
    };
    const onKeyDown = (event: KeyboardEvent): void => {
      if (
        [
          "ArrowUp",
          "ArrowDown",
          "PageUp",
          "PageDown",
          "Home",
          "End",
          " ",
        ].includes(event.key)
      ) {
        noteUserIntent();
      }
    };
    const onScroll = (): void => {
      const now = performance.now();
      if (now < programmaticUntilRef.current) return;
      const gap =
        scroller.scrollHeight - scroller.clientHeight - scroller.scrollTop;
      if (gap <= bottomThresholdPx) {
        anchorMemoryRef.current.delete(conversationId);
        dispatch({ type: "jump-to-latest" });
        return;
      }
      if (now <= userIntentUntilRef.current || stateRef.current.mode === "detached") {
        const anchor = capture();
        dispatch({ type: "user-detached", anchor, reason: "user-scroll" });
      }
    };

    scroller.addEventListener("wheel", noteUserIntent, { passive: true });
    scroller.addEventListener("touchstart", noteUserIntent, { passive: true });
    scroller.addEventListener("pointerdown", noteUserIntent, { passive: true });
    scroller.addEventListener("keydown", onKeyDown);
    scroller.addEventListener("scroll", onScroll, { passive: true });

    return () => {
      scroller.removeEventListener("wheel", noteUserIntent);
      scroller.removeEventListener("touchstart", noteUserIntent);
      scroller.removeEventListener("pointerdown", noteUserIntent);
      scroller.removeEventListener("keydown", onKeyDown);
      scroller.removeEventListener("scroll", onScroll);
    };
  }, [bottomThresholdPx, capture, conversationId, dispatch, scrollerRef]);

  useEffect(() => {
    restoreConversation();
  }, [conversationId, restoreConversation]);

  useEffect(() => {
    const scroller = scrollerRef.current;
    if (!scroller || typeof ResizeObserver === "undefined") return;
    const observer = new ResizeObserver(() => notifyLayoutChanged());
    observer.observe(scroller);
    const content = scroller.firstElementChild;
    if (content instanceof Element) observer.observe(content);
    return () => observer.disconnect();
  }, [notifyLayoutChanged, scrollerRef]);

  useEffect(
    () => () => {
      if (scheduledFrameRef.current) {
        cancelAnimationFrame(scheduledFrameRef.current);
      }
    },
    [],
  );

  return {
    state,
    scrollToLatest,
    notifyContentAppended,
    notifyLayoutChanged,
    captureBeforeConversationChange: capture,
    restoreConversation,
    detachForSelection() {
      const anchor = capture();
      dispatch({ type: "user-detached", anchor, reason: "selection" });
    },
  };
}
