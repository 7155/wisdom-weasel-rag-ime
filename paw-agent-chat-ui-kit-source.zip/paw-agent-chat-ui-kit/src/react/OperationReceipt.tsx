import type { ReactNode } from "react";
import {
  projectOperationReceipt,
  type ChatOperationState,
  type OperationReceiptModel,
} from "../core/interaction/operation.js";

export type OperationReceiptLabels = Record<
  OperationReceiptModel["labelKey"],
  string
> & {
  retry: string;
  cancelAndEdit: string;
};

export function OperationReceipt({
  operation,
  labels,
  onRetry,
  onCancelAndEdit,
}: {
  operation: ChatOperationState;
  labels: OperationReceiptLabels;
  onRetry?(operation: ChatOperationState): void | Promise<void>;
  onCancelAndEdit?(operation: ChatOperationState): void | Promise<void>;
}): ReactNode {
  const model = projectOperationReceipt(operation);
  if (!model.visible) return null;
  return (
    <div
      className="paw-operation-receipt"
      data-tone={model.tone}
      data-operation-kind={operation.kind}
      data-operation-status={operation.status}
      role="status"
    >
      <span className="paw-operation-dot" aria-hidden="true" />
      <span>{labels[model.labelKey]}</span>
      {model.canRetry && onRetry ? (
        <button type="button" onClick={() => void onRetry(operation)}>
          {labels.retry}
        </button>
      ) : null}
      {model.canCancelAndEdit && onCancelAndEdit ? (
        <button
          type="button"
          onClick={() => void onCancelAndEdit(operation)}
        >
          {labels.cancelAndEdit}
        </button>
      ) : null}
    </div>
  );
}
