import { useEffect, useRef, useState, type ReactNode } from "react";

/** Announce only after settle, never once per token. */
export function SettledMessageAnnouncer({
  canonicalText,
  streaming,
  maxCharacters = 320,
}: {
  canonicalText: string;
  streaming: boolean;
  maxCharacters?: number;
}): ReactNode {
  const wasStreaming = useRef(streaming);
  const [announcement, setAnnouncement] = useState("");
  useEffect(() => {
    if (wasStreaming.current && !streaming) {
      const compact = canonicalText.replace(/\s+/g, " ").trim();
      setAnnouncement(compact.slice(-maxCharacters));
    }
    wasStreaming.current = streaming;
  }, [canonicalText, maxCharacters, streaming]);
  return (
    <div className="paw-sr-only" aria-live="polite" aria-atomic="true">
      {announcement}
    </div>
  );
}
