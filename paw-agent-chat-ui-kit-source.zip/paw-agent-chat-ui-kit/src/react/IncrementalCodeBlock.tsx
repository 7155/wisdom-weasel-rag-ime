import {
  memo,
  useLayoutEffect,
  useMemo,
  useRef,
  type CSSProperties,
  type ReactNode,
} from "react";
import {
  plainTextLineTokenizer,
  updateIncrementalTokenCache,
  type CachedTokenLine,
  type HighlightToken,
  type StatefulLineTokenizer,
} from "../core/markdown/tokenizer.js";

export interface IncrementalCodeBlockProps<State = null> {
  code: string;
  language?: string;
  streaming?: boolean;
  tokenizer?: StatefulLineTokenizer<State>;
  className?: string;
  style?: CSSProperties;
  maxHighlightBytes?: number;
  renderToken?(token: HighlightToken, key: string): ReactNode;
}

const CodeLine = memo(function CodeLine({
  tokens,
  line,
  renderToken,
}: {
  tokens: readonly HighlightToken[];
  line: number;
  renderToken?: (token: HighlightToken, key: string) => ReactNode;
}): ReactNode {
  return (
    <>
      {tokens.map((token, tokenIndex) => {
        const key = `${line}:${tokenIndex}`;
        return renderToken ? (
          renderToken(token, key)
        ) : (
          <span key={key} className={token.className} style={token.style}>
            {token.content}
          </span>
        );
      })}
    </>
  );
});

function approximateUtf8Bytes(value: string): number {
  let bytes = 0;
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code < 0x80) bytes += 1;
    else if (code < 0x800) bytes += 2;
    else if (code >= 0xd800 && code <= 0xdbff) {
      bytes += 4;
      index += 1;
    } else bytes += 3;
  }
  return bytes;
}

/** Complete lines are cached; the unfinished live line stays cheap. */
export function IncrementalCodeBlock<State = null>({
  code,
  language,
  streaming = false,
  tokenizer,
  className,
  style,
  maxHighlightBytes = 204_800,
  renderToken,
}: IncrementalCodeBlockProps<State>): ReactNode {
  const shouldHighlight = approximateUtf8Bytes(code) <= maxHighlightBytes;
  const activeTokenizer = shouldHighlight
    ? tokenizer ??
      (plainTextLineTokenizer as unknown as StatefulLineTokenizer<State>)
    : (plainTextLineTokenizer as unknown as StatefulLineTokenizer<State>);
  const cacheRef = useRef<readonly CachedTokenLine<State>[]>([]);
  const result = useMemo(
    () => updateIncrementalTokenCache(code, activeTokenizer, cacheRef.current),
    [activeTokenizer, code],
  );
  useLayoutEffect(() => {
    cacheRef.current = result.completeLines;
  }, [result.completeLines]);

  const finalPartialTokens = useMemo(() => {
    if (streaming || !result.partialLine || !shouldHighlight) return undefined;
    const previous = result.completeLines.at(-1);
    const stateBefore = previous
      ? previous.stateAfter
      : activeTokenizer.initialState;
    return activeTokenizer.tokenizeLine(result.partialLine, stateBefore).tokens;
  }, [
    activeTokenizer,
    result.completeLines,
    result.partialLine,
    shouldHighlight,
    streaming,
  ]);

  return (
    <pre
      className={className ?? "paw-live-code-block"}
      style={style}
      data-language={language}
      data-highlight-degraded={!shouldHighlight || undefined}
    >
      <code className={language ? `language-${language}` : undefined}>
        {result.completeLines.map((line, index) => (
          <span key={index} data-code-line={index + 1}>
            <CodeLine
              tokens={line.tokens}
              line={index}
              renderToken={renderToken}
            />
            {"\n"}
          </span>
        ))}
        {result.partialLine ? (
          <span data-code-line={result.completeLines.length + 1}>
            {finalPartialTokens ? (
              <CodeLine
                tokens={finalPartialTokens}
                line={result.completeLines.length}
                renderToken={renderToken}
              />
            ) : (
              result.partialLine
            )}
          </span>
        ) : null}
      </code>
    </pre>
  );
}
