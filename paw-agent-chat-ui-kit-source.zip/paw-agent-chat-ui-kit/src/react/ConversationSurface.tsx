import type { ReactNode } from "react";

/** Layout shell only; runtime ownership remains outside this component. */
export function ConversationSurface({
  transcript,
  bottomDock,
  sideConversation,
  overlay,
  className,
}: {
  transcript: ReactNode;
  bottomDock: ReactNode;
  sideConversation?: ReactNode;
  overlay?: ReactNode;
  className?: string;
}): ReactNode {
  return (
    <div className={className ?? "paw-chat-surface"}>
      <main className="paw-chat-main">
        <section className="paw-chat-transcript">{transcript}</section>
        {overlay ? <div className="paw-chat-overlay">{overlay}</div> : null}
        <div className="paw-chat-bottom-dock">{bottomDock}</div>
      </main>
      {sideConversation}
    </div>
  );
}

export function ConversationBottomDock({
  interaction,
  queue,
  composer,
}: {
  interaction?: ReactNode;
  queue?: ReactNode;
  composer: ReactNode;
}): ReactNode {
  return (
    <div className="paw-bottom-dock-stack">
      {interaction ? (
        <div className="paw-pending-interaction">{interaction}</div>
      ) : null}
      {queue}
      <div className="paw-composer-shell">{composer}</div>
    </div>
  );
}
