import { useSyncExternalStore } from "react";
import type { ChatRuntimeAdapter } from "../core/interaction/runtime.js";

export function useChatRuntimeSnapshot<Snapshot, Command>(
  runtime: ChatRuntimeAdapter<Snapshot, Command>,
): Snapshot {
  return useSyncExternalStore(
    runtime.subscribe,
    runtime.getSnapshot,
    runtime.getServerSnapshot ?? runtime.getSnapshot,
  );
}
