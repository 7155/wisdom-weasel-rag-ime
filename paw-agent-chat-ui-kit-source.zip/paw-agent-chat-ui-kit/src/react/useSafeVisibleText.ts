import {
  startTransition,
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
} from "react";
import {
  advanceMarkdownReveal,
  markdownRevealCeiling,
  remapVisibleOffsetAfterEdit,
} from "../core/markdown/reveal.js";

export interface SafeVisibleTextOptions {
  enabled: boolean;
  maxHoldbackChars?: number;
  baseStep?: number;
}

/**
 * Reveal a Markdown stream at safe boundaries. The animation frame loop controls
 * visual release; canonical text remains available separately for copy/search.
 */
export function useSafeVisibleText(
  sourceText: string,
  options: SafeVisibleTextOptions,
): string {
  const { enabled, maxHoldbackChars = 600, baseStep = 40 } = options;
  const sourceRef = useRef(sourceText);
  const visibleLengthRef = useRef(enabled ? 0 : sourceText.length);
  const [visibleLength, setVisibleLength] = useState(visibleLengthRef.current);

  useLayoutEffect(() => {
    const previous = sourceRef.current;
    sourceRef.current = sourceText;
    if (!sourceText.startsWith(previous)) {
      const mapped = remapVisibleOffsetAfterEdit(
        previous,
        sourceText,
        visibleLengthRef.current,
      );
      visibleLengthRef.current = mapped;
      setVisibleLength(mapped);
    }
    if (!enabled) {
      visibleLengthRef.current = sourceText.length;
      setVisibleLength(sourceText.length);
    }
  }, [enabled, sourceText]);

  useEffect(() => {
    if (!enabled) return;
    if (
      typeof requestAnimationFrame !== "function" ||
      typeof performance === "undefined"
    ) {
      visibleLengthRef.current = sourceText.length;
      setVisibleLength(sourceText.length);
      return;
    }

    let frame = 0;
    let nextAllowedAt = performance.now();
    const tick = (now: number): void => {
      frame = requestAnimationFrame(tick);
      if (typeof document !== "undefined" && document.hidden) return;
      if (now < nextAllowedAt) return;

      const source = sourceRef.current;
      const ceiling = markdownRevealCeiling(source, maxHoldbackChars);
      const current = visibleLengthRef.current;
      if (current >= ceiling) return;

      const next = advanceMarkdownReveal(source, current, ceiling, baseStep);
      visibleLengthRef.current = next;
      const backlog = ceiling - next;
      nextAllowedAt =
        now + Math.max(25, Math.min(150, 12_000 / Math.max(1, backlog)));
      startTransition(() => setVisibleLength(next));
    };

    frame = requestAnimationFrame(tick);
    const onVisibilityChange = (): void => {
      if (typeof document === "undefined" || document.hidden) return;
      const ceiling = markdownRevealCeiling(
        sourceRef.current,
        maxHoldbackChars,
      );
      visibleLengthRef.current = ceiling;
      setVisibleLength(ceiling);
    };
    document?.addEventListener("visibilitychange", onVisibilityChange);
    return () => {
      cancelAnimationFrame(frame);
      document?.removeEventListener("visibilitychange", onVisibilityChange);
    };
  }, [baseStep, enabled, maxHoldbackChars, sourceText.length]);

  return enabled ? sourceText.slice(0, visibleLength) : sourceText;
}
