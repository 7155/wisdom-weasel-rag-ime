import type { ReactNode } from "react";

export function JumpToLatestButton({
  unseenUpdates,
  label,
  onClick,
}: {
  unseenUpdates: number;
  label(count: number): string;
  onClick(): void;
}): ReactNode {
  if (unseenUpdates <= 0) return null;
  return (
    <button
      type="button"
      className="paw-jump-latest"
      onClick={onClick}
      aria-live="polite"
    >
      <span aria-hidden="true">↓</span>
      {label(unseenUpdates)}
    </button>
  );
}
