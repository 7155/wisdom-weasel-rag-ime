import { useId, useState, type ReactNode } from "react";
import {
  projectQueuePresentation,
  queueRecordCanMutate,
} from "../core/interaction/queue.js";
import type { RuntimeQueueRecord } from "../core/interaction/runtime.js";

export interface QueuePanelLabels {
  queued(count: number): string;
  paused(count: number): string;
  draining(count: number): string;
  next: string;
  attachment: string;
  empty: string;
  expand: string;
  collapse: string;
  sendNow: string;
  edit: string;
  remove: string;
  clear: string;
  moveUp: string;
  moveDown: string;
  failed: string;
}

export interface QueuePanelProps<Draft> {
  records: readonly RuntimeQueueRecord<Draft>[];
  queueStatus: "active" | "paused_by_user";
  labels: QueuePanelLabels;
  expanded?: boolean;
  defaultExpanded?: boolean;
  onExpandedChange?(expanded: boolean): void;
  onSendNow(queueId: string): void | Promise<void>;
  onEdit(record: RuntimeQueueRecord<Draft>): void | Promise<void>;
  onRemove(queueId: string): void | Promise<void>;
  onClear?(): void | Promise<void>;
  onMove?(queueId: string, beforeQueueId: string | null): void | Promise<void>;
  renderDraftDetails?(record: RuntimeQueueRecord<Draft>): ReactNode;
}

export function QueuePanel<Draft>({
  records,
  queueStatus,
  labels,
  expanded,
  defaultExpanded = false,
  onExpandedChange,
  onSendNow,
  onEdit,
  onRemove,
  onClear,
  onMove,
  renderDraftDetails,
}: QueuePanelProps<Draft>): ReactNode {
  const model = projectQueuePresentation({ records, queueStatus });
  const [internalExpanded, setInternalExpanded] = useState(defaultExpanded);
  const isExpanded = expanded ?? internalExpanded;
  const contentId = useId();
  if (!model.visible) return null;

  const setExpanded = (next: boolean): void => {
    if (expanded === undefined) setInternalExpanded(next);
    onExpandedChange?.(next);
  };
  const summary =
    model.state === "paused"
      ? labels.paused(model.count)
      : model.state === "draining"
        ? labels.draining(model.count)
        : labels.queued(model.count);
  const preview =
    model.preview ||
    (model.previewFallback === "attachment"
      ? labels.attachment
      : labels.empty);

  const move = (index: number, direction: -1 | 1): void => {
    const record = records[index];
    if (!record || !onMove) return;
    if (direction < 0 && index > 0) {
      void onMove(record.id, records[index - 1]!.id);
      return;
    }
    if (direction > 0 && index + 1 < records.length) {
      const afterNext = records[index + 2];
      void onMove(record.id, afterNext?.id ?? null);
    }
  };

  return (
    <section className="paw-queue-panel" data-queue-state={model.state}>
      <button
        type="button"
        className="paw-queue-summary"
        aria-expanded={isExpanded}
        aria-controls={contentId}
        onClick={() => setExpanded(!isExpanded)}
      >
        <span className="paw-queue-count">{summary}</span>
        <span className="paw-queue-preview">
          <span className="paw-queue-next-label">{labels.next}</span>
          {preview}
        </span>
        <span aria-hidden="true">{isExpanded ? "⌃" : "⌄"}</span>
        <span className="paw-sr-only">
          {isExpanded ? labels.collapse : labels.expand}
        </span>
      </button>

      {isExpanded ? (
        <div id={contentId} className="paw-queue-list-wrap">
          <ol className="paw-queue-list">
            {records.map((record, index) => {
              const mutable = queueRecordCanMutate(record);
              return (
                <li
                  key={record.id}
                  className="paw-queue-item"
                  data-queue-item-status={record.status}
                >
                  <div className="paw-queue-item-index">{index + 1}</div>
                  <div className="paw-queue-item-body">
                    <div className="paw-queue-item-preview">
                      {record.preview ||
                        (record.attachmentCount > 0
                          ? labels.attachment
                          : labels.empty)}
                    </div>
                    {record.status === "failed" ? (
                      <div className="paw-queue-item-error" role="status">
                        {labels.failed}
                        {record.error ? ` · ${record.error}` : ""}
                      </div>
                    ) : null}
                    {renderDraftDetails?.(record)}
                    <div className="paw-queue-item-actions">
                      <button
                        type="button"
                        disabled={!mutable}
                        onClick={() => void onSendNow(record.id)}
                      >
                        {labels.sendNow}
                      </button>
                      <button
                        type="button"
                        disabled={!mutable}
                        onClick={() => void onEdit(record)}
                      >
                        {labels.edit}
                      </button>
                      <button
                        type="button"
                        disabled={!mutable}
                        onClick={() => void onRemove(record.id)}
                      >
                        {labels.remove}
                      </button>
                      {onMove ? (
                        <>
                          <button
                            type="button"
                            disabled={!mutable || index === 0}
                            aria-label={labels.moveUp}
                            onClick={() => move(index, -1)}
                          >
                            ↑
                          </button>
                          <button
                            type="button"
                            disabled={!mutable || index === records.length - 1}
                            aria-label={labels.moveDown}
                            onClick={() => move(index, 1)}
                          >
                            ↓
                          </button>
                        </>
                      ) : null}
                    </div>
                  </div>
                </li>
              );
            })}
          </ol>
          {onClear ? (
            <footer className="paw-queue-footer">
              <button
                type="button"
                className="paw-queue-clear"
                onClick={() => void onClear()}
              >
                {labels.clear}
              </button>
            </footer>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
