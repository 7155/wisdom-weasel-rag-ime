import { useLayoutEffect, useMemo, useRef } from "react";
import {
  advanceStreamingMarkdownDocument,
  createStreamingMarkdownDocumentState,
  projectStreamingMarkdownChunks,
  type RenderMarkdownChunk,
  type StreamingMarkdownDocumentState,
} from "../core/markdown/scanner.js";

export interface StreamingMarkdownModel {
  state: StreamingMarkdownDocumentState;
  chunks: readonly RenderMarkdownChunk[];
}

/** Commit scanner state only after React commits, preserving concurrent safety. */
export function useStreamingMarkdownDocument(
  text: string,
  streaming: boolean,
): StreamingMarkdownModel {
  const committedRef = useRef(createStreamingMarkdownDocumentState());
  const nextState = useMemo(
    () =>
      advanceStreamingMarkdownDocument(
        committedRef.current,
        text,
        streaming,
      ),
    [streaming, text],
  );
  useLayoutEffect(() => {
    committedRef.current = nextState;
  }, [nextState]);
  const chunks = useMemo(
    () => projectStreamingMarkdownChunks(nextState, text, streaming),
    [nextState, streaming, text],
  );
  return { state: nextState, chunks };
}
