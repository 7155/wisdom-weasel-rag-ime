import { memo, useDeferredValue, useMemo, type ReactNode } from "react";
import { normalizeStreamingMarkdown } from "../core/markdown/normalization.js";
import { partitionTopLevelNodes } from "../core/markdown/partition.js";
import { useSafeVisibleText } from "./useSafeVisibleText.js";
import { useStreamingMarkdownDocument } from "./useStreamingMarkdownDocument.js";

export interface AstMarkdownAdapter<Node> {
  parse(markdown: string): readonly Node[];
  render(
    nodes: readonly Node[],
    context: {
      active: boolean;
      settled: boolean;
      start: number;
      chunkId: number;
    },
  ): ReactNode;
  getStartOffset(node: Node): number | undefined;
}

export interface AstStreamingMarkdownProps {
  canonicalText: string;
  streaming: boolean;
  className?: string;
  progressiveReveal?: boolean;
  maxHoldbackChars?: number;
  renderVersion?: string | number;
}

/**
 * Factory for parsers exposing top-level source positions. Streaming chunks are
 * parsed independently; settle performs one whole-document parse and partitions
 * nodes back into the existing stable chunk containers.
 */
export function createAstStreamingMarkdown<Node>(
  adapter: AstMarkdownAdapter<Node>,
) {
  interface AstChunkProps {
    id: number;
    content: string;
    start: number;
    active: boolean;
    settled: boolean;
    settledNodes?: readonly Node[];
    renderVersion: string | number;
  }

  const AstChunk = memo(
    function AstChunk({
      id,
      content,
      start,
      active,
      settled,
      settledNodes,
    }: AstChunkProps): ReactNode {
      const nodes = useMemo(
        () => settledNodes ?? adapter.parse(content),
        [content, settledNodes],
      );
      return adapter.render(nodes, { active, settled, start, chunkId: id });
    },
    (previous, next) =>
      previous.id === next.id &&
      previous.content === next.content &&
      previous.start === next.start &&
      previous.active === next.active &&
      previous.settled === next.settled &&
      previous.settledNodes === next.settledNodes &&
      previous.renderVersion === next.renderVersion,
  );

  return function AstStreamingMarkdown({
    canonicalText,
    streaming,
    className,
    progressiveReveal = true,
    maxHoldbackChars = 600,
    renderVersion = 0,
  }: AstStreamingMarkdownProps): ReactNode {
    const normalized = useMemo(
      () => normalizeStreamingMarkdown(canonicalText),
      [canonicalText],
    );
    const visibleText = useSafeVisibleText(normalized, {
      enabled: streaming && progressiveReveal,
      maxHoldbackChars,
    });
    const deferredStreaming = useDeferredValue(streaming);
    const { chunks } = useStreamingMarkdownDocument(
      visibleText,
      deferredStreaming,
    );
    const settled = !deferredStreaming;
    const fullDocumentNodes = useMemo(
      () => (settled ? adapter.parse(visibleText) : undefined),
      [settled, visibleText],
    );
    const partitions = useMemo(
      () =>
        fullDocumentNodes
          ? partitionTopLevelNodes(
              fullDocumentNodes,
              chunks.map((chunk) => chunk.start),
              adapter.getStartOffset,
            )
          : undefined,
      [chunks, fullDocumentNodes],
    );

    return (
      <div className={className} data-streaming={deferredStreaming || undefined}>
        {chunks.map((chunk, index) => (
          <AstChunk
            key={chunk.id}
            id={chunk.id}
            content={chunk.content}
            start={chunk.start}
            active={chunk.active}
            settled={settled}
            settledNodes={partitions?.[index]}
            renderVersion={renderVersion}
          />
        ))}
      </div>
    );
  };
}
